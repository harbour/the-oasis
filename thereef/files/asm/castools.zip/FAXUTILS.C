

/*
   FAXUTILS.C  Utilities used by the FAX Toolkit Library.
*/

/*
   SubmitSingleOk(ECS *task);

   This function examines an Event Control Structure to determine if it is
   'OK' to use the low-level CASSubmitSingleFileToSend function.  It is "OK"
   to use that function if all of the fields that it ignores are set to
   NULL values.  If any of those fields are set to non-NULL values, using
   SubmitSingle would lose that information, and would be not "OK".

   INPUT:  The Event Control Structure for the task under consideration.

   OUTPUT: 1 or 0.
*/

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <malloc.h>
#include <cas.h>
#include <FAX.h>

int pascal SubmitSingleOk(ECS *task)
{

  WORD FileCount;
  FTRLIST *CurrFTRL;

  if (task->EventControlFile.SenderName[0] ||
      task->EventControlFile.LogoFilePath[0]) {
    return(0);
  }
  if (task->EventControlFile.TransferType != FILE_TRANSFER) {
    if (task->FirstFTR->OneFTR.PageLength) {
      return(0);
    }
  }
  return(1);
}

/*
   ECSOkToSubmit(ECS *ecs);

   This function checks an Event Control Structure for errors.  It follows the
   specifications for Control Files documented in CAS 1.0.  It returns 1 if the
   ECS is valid for a task event.

   Reserved fields are tested for being zero; if not, they are zeroed and a
   warning is set.  Likewise other fields used by the Resident Manager that
   should be set to zero by the application are tested.  It they are not zero,
   they are set to zero, and a warning is set.

   INPUT:  The Event Control Structure for the task under consideration.

   OUTPUT: 1 or 0.
*/

typedef struct {
  unsigned day: 5;
  unsigned month: 4;
  unsigned year: 7;
} DOS_fdate;

typedef struct {
  unsigned twosecs: 5;
  unsigned minute: 6;
  unsigned hour: 5;
} DOS_ftime;

static int days_in_month[2][13] = {
  {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
  {0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
};

int pascal ECSOkToSubmit(ECS *ecs)
{

  DOS_fdate *date;
  DOS_ftime *time;
  int i, leap, year;
  unsigned month, day,
           hour, minute, twosec;
  FTRLIST *CurrFTRL;
  struct stat fstatbuf;

  /* EventType check */
  if ((ecs->EventControlFile.EventType != SEND) &&
      (ecs->EventControlFile.EventType != POLLED_SEND) &&
      (ecs->EventControlFile.EventType != POLLED_RECEIVE)) {
    FAXerrno = BADEVENTTYPE;
    return(0);
  }

  /* TransferType check */
  if ((ecs->EventControlFile.TransferType < FAX_200) ||
      (ecs->EventControlFile.TransferType > FILE_TRANSFER)) {
    FAXerrno = BADTRANSFERTYPE;
    return(0);
  }

  /* EventStatus check (non-reserved Resident Manager field) */
  if (ecs->EventControlFile.EventStatus) {
    ecs->EventControlFile.EventStatus = 0;
    FAXerrno = FIELDZEROED;
  }

  /* EventTime  check */
  time = (DOS_ftime *)&ecs->EventControlFile.EventTime;
  twosec = time->twosecs;
  minute = time->minute;
  hour = time->hour;
  if ((twosec < 0) || (twosec > 29) ||
      (minute < 0) || (minute > 59) ||
      (hour < 0) || (hour > 23)) {
    FAXerrno = BADEVENTTIME;
    return(0);
  }

  /* EventDate check, only if date is not NULL (NULL is OK) */
  if (ecs->EventControlFile.EventDate) {
    date = (DOS_fdate *)&ecs->EventControlFile.EventDate;
    year = date->year;
    month = date->month;
    day = date->day;
    if ((month < 1) || (month > 12) ||
        (year < 0) || (year > 119)) {
      FAXerrno = BADEVENTDATE;
      return(0);
    }
    year = year + 1980;
    leap = (year % 4 == 0) &&
           (year % 100 != 0) ||
           (year % 400 == 0);
    if ((day < 1) || (day > days_in_month[leap][month])) {
      FAXerrno = BADEVENTDATE;
      return(0);
    }
  }

  /* FileCount  check */
  if ((ecs->EventControlFile.FileCount < 0) ||
      (ecs->EventControlFile.FileCount > 32766)) {
    FAXerrno = FILECOUNTOUTOFRANGE;
    return(0);
  }

  /* FTROffset  check ?? how to check?*/

  /* Phone[]  check, only if NOT a POLLED_SEND, first for length...  */
  if (ecs->EventControlFile.EventType != POLLED_SEND) {
    for (i=0; i<PHONENUMLENGTH; i++) {
      if (!ecs->EventControlFile.Phone[i]) {
        break;
      }
    }
    if (i == PHONENUMLENGTH) {
      FAXerrno = STRINGTOOLONG;
      ecs->EventControlFile.Phone[i - 1] = '\0';
    }
    if (i == 0) {
      FAXerrno = BADPHONENUMBER;
      return(0);
    }

    /* ...then for validity */
    /* (if first character is 'm' or 'M', rest is ok) */
    if (tolower(ecs->EventControlFile.Phone[0]) != 'm') {
      for (i=0; ecs->EventControlFile.Phone[i] && (i < PHONENUMLENGTH); i++) {
        if ((ecs->EventControlFile.Phone[i] >= '0') &&
            (ecs->EventControlFile.Phone[i] <= '9')) {
          break;
        }
      }
      if (!ecs->EventControlFile.Phone[i]) {
        FAXerrno = BADPHONENUMBER;
        return(0);
      }
    }
  }

  /* ApplicationTag[]  check */
  for (i=0; i<APPTAGLENGTH; i++) {
    if (!ecs->EventControlFile.ApplicationTag[i]) {
      break;
    }
    if (!(isascii(ecs->EventControlFile.ApplicationTag[i]))) {
      FAXerrno = NONASCIISTRING;
      return(0);
    }
  }
  if (i == APPTAGLENGTH) {
    FAXerrno = STRINGTOOLONG;
    ecs->EventControlFile.ApplicationTag[i - 1] = '\0';
  }

  /* RESERVED1  check */
  if (ecs->EventControlFile.RESERVED1) {
    FAXerrno = RESERVEDFIELDZEROED;
    ecs->EventControlFile.RESERVED1 = 0;
  }

  /* Some Resident manager (non-reserved) fields */
  for (i=0; i<13; i++) {
    if ((&ecs->EventControlFile.ConnectSeconds)[i]) {
      FAXerrno = FIELDZEROED;
      (&ecs->EventControlFile.ConnectSeconds)[i] = 0;
    }
  }

  /* SendCover  check */
  if ((ecs->EventControlFile.SendCover != 0) &&
      (ecs->EventControlFile.SendCover != 1)) {
    FAXerrno = BADSENDCOVER;
    return(0);
  }

  /* Transmission errors (non-reserved) */
  if (ecs->EventControlFile.ErrorCount) {
    FAXerrno = FIELDZEROED;
    ecs->EventControlFile.ErrorCount = 0;
  }

  /* RESERVED2[]  check */
  for (i=0; i<RESERVED2LENGTH; i++) {
    if (ecs->EventControlFile.RESERVED2[i]) {
      ecs->EventControlFile.RESERVED2[i] = 0;
      FAXerrno = RESERVEDFIELDZEROED;
    }
  }

  /* RemoteCSID[]  check */
  for (i=0; i<CSIDLENGTH; i++) {
    if (ecs->EventControlFile.RemoteCSID[i]) {
      FAXerrno = FIELDZEROED;
      ecs->EventControlFile.RemoteCSID[i] = 0;
    }
  }

  /* DestinationName[]  check */
  for (i=0; i<NAMELENGTH; i++) {
    if (!ecs->EventControlFile.DestinationName[i]) {
      break;
    }
    if (!(isascii(ecs->EventControlFile.DestinationName[i]))) {
      FAXerrno = NONASCIISTRING;
      return(0);
    }
  }
  if (i == NAMELENGTH) {
    FAXerrno = STRINGTOOLONG;
    ecs->EventControlFile.DestinationName[i - 1] = '\0';
  }

  /* SenderName[]  check first that it's a valid string ... */
  for (i=0; i<NAMELENGTH; i++) {
    if (!ecs->EventControlFile.SenderName[i]) {
      break;
    }
    if (!(isascii(ecs->EventControlFile.SenderName[i]))) {
      FAXerrno = NONASCIISTRING;
      return(0);
    }
  }

  /* ...then that it's not too long (none is ok, the Toolkit will set it) */
  if (i) {
    if (i == NAMELENGTH) {
      FAXerrno = STRINGTOOLONG;
      ecs->EventControlFile.SenderName[i - 1] = '\0';
    }
  }

  /* LogoFilePath[]  check: first that it's valid, ..... */
  for (i=0; i<FULLFNAMELENGTH; i++) {
    if (!ecs->EventControlFile.LogoFilePath[i]) {
      break;
    }
    if (!(isascii(ecs->EventControlFile.LogoFilePath[i]))) {
      FAXerrno = NONASCIISTRING;
      return(0);
    }
  }
  if (i == FULLFNAMELENGTH) {
    FAXerrno = STRINGTOOLONG;
    ecs->EventControlFile.LogoFilePath[i - 1] = '\0';
  }

  /* ... then, if named at all (Toolkit will set if not), that it's there */
  if (i) {
    if (stat(ecs->EventControlFile.LogoFilePath, &fstatbuf)) {
      FAXerrno = LOGOFILENOTFOUND;
      return(0);
    }
  }

  /* Checks of the coverpage text */
  for (i=0; i<ecs->EventControlFile.FTROffset - 383; i++) {
    if (!(isascii(ecs->CoverPageText[i]))) {
      FAXerrno = NONASCIISTRING;
      return(0);
    }
  }

  /* Check each of the FTR's, if any */
  CurrFTRL = ecs->FirstFTR;
  for (i=0; i<ecs->EventControlFile.FileCount; i++) {
    if (!CurrFTRL) {
      FAXerrno = BADFILECOUNT;
      return(0);
    }
    else if (!(FTRLOkToSend(ecs, CurrFTRL))) {
      return(0);                        /* FTRLOk sets FAXerrno */
    }
    CurrFTRL = CurrFTRL->next;
  }
  if (CurrFTRL->next) {
    FAXerrno = MOREFTRSTHANFC;
  }

  /*  If we got this far, all is ok! */
  return(1);
}

/*
   SFTROkToSubmit(SFTR *SFTR);

   This function checks an Single File Transfer Record Structure for errors.
   It applies the same tests as the ECSOkToSubmit function, but on a subset
   of the Event Control File fields.  This subset is defined by CAS under the
   function "Submit a Single File To Send" (15H).

   Reserved fields are tested for being zero; if not, they are zeroed and a
   warning is set.  Likewise other fields used by the Resident Manager that
   should be set to zero by the application are tested.  It they are not zero,
   they are set to zero, and a warning is set.

   INPUT:  The SFTR structure for the task under consideration.

   OUTPUT: 1 or 0.
*/

int pascal SFTROkToSubmit(SFTR *sftr)
{
  DOS_ftime *time;
  DOS_fdate *date;
  unsigned twosec, minute, hour,
           year, month, day;
  struct stat fstatbuf;
  int i, leap;

  /* TransferType check */
  if ((sftr->TransferType < FAX_200) ||
      (sftr->TransferType > FILE_TRANSFER)) {
    FAXerrno = BADTRANSFERTYPE;
    return(0);
  }

  /* TextSize check, applies only to FAX's */
  if (sftr->TransferType != FILE_TRANSFER) {
    if ((sftr->TextSize < 0) ||
        (sftr->TextSize > 1)) {
      FAXerrno = FTRBADTEXTSIZE;
      return(0);
    }
  }

  /* EventTime  check */
  time = (DOS_ftime *)&sftr->EventTime;
  twosec = time->twosecs;
  minute = time->minute;
  hour = time->hour;
  if ((twosec < 0) || (twosec > 29) ||
      (minute < 0) || (minute > 59) ||
      (hour < 0) || (hour > 23)) {
    FAXerrno = BADEVENTTIME;
    return(0);
  }

  /* EventDate  check, only if date is not NULL (NULL is OK) */
  if (sftr->EventDate) {
    date = (DOS_fdate *)&sftr->EventDate;
    year = date->year;
    month = date->month;
    day = date->day;
    if ((month < 1) || (month > 12) ||
        (year < 0) || (year > 119)) {
      FAXerrno = BADEVENTDATE;
      return(0);
    }
    year = year + 1980;
    leap = (year % 4 == 0) &&
           (year % 100 != 0) ||
           (year % 400 == 0);
    if ((day < 1) || (day > days_in_month[leap][month])) {
      FAXerrno = BADEVENTDATE;
      return(0);
    }
  }

  /* DestinationName[]  check */
  for (i=0; i<NAMELENGTH; i++) {
    if (!sftr->DestinationName[i]) {
      break;
    }
    if (!(isascii(sftr->DestinationName[i]))) {
      FAXerrno = NONASCIISTRING;
      return(0);
    }
  }
  if (i == NAMELENGTH) {
    FAXerrno = STRINGTOOLONG;
    sftr->DestinationName[i - 1] = '\0';
  }

  /* The filename must be valid... */
  for (i=0; i<FULLFNAMELENGTH; i++) {
    if (!(sftr->FileName[i])) {
      break;
    }
    if (!(isascii(sftr->FileName[i]))) {
      FAXerrno = FTRNONASCIISTRING;
      return(0);
    }
  }
  if (i == FULLFNAMELENGTH) {
    FAXerrno = STRINGTOOLONG;
    sftr->FileName[i - 1] = '\0';
  }

  /* ... and present */
  if (stat(sftr->FileName, &fstatbuf)) {
    FAXerrno = FILETOSENDNOTFOUND;
    return(0);
  }

  /* Phone[]  check, first for length...  */
  for (i=0; i<PHONENUMLENGTH; i++) {
    if (!sftr->Phone[i]) {
      break;
    }
  }
  if (i == PHONENUMLENGTH) {
    FAXerrno = STRINGTOOLONG;
    sftr->Phone[i - 1] = '\0';
  }
  if (i == 0) {
    FAXerrno = BADPHONENUMBER;
    return(0);
  }

  /* ...then for validity */
  /* (if first character is 'm' or 'M', rest is ok) */
  if (tolower(sftr->Phone[0]) != 'm') {
    for (i=0; sftr->Phone[i] && (i < PHONENUMLENGTH); i++) {
      if ((sftr->Phone[i] >= '0') &&
          (sftr->Phone[i] <= '9')) {
        break;
      }
    }
    if (!sftr->Phone[i]) {
      FAXerrno = BADPHONENUMBER;
      return(0);
    }
  }

  /* ApplicationTag[]  check */
  for (i=0; i<APPTAGLENGTH; i++) {
    if (!sftr->ApplicationTag[i]) {
      break;
    }
    if (!(isascii(sftr->ApplicationTag[i]))) {
      FAXerrno = NONASCIISTRING;
      return(0);
    }
  }
  if (i == APPTAGLENGTH) {
    FAXerrno = STRINGTOOLONG;
    sftr->ApplicationTag[i - 1] = '\0';
  }

  /* RESERVED1  check */
  if (sftr->RESERVED1) {
    FAXerrno = RESERVEDFIELDZEROED;
    sftr->RESERVED1 = 0;
  }

  /* SendCover  check */
  if ((sftr->SendCover != 0) &&
      (sftr->SendCover != 1)) {
    FAXerrno = BADSENDCOVER;
    return(0);
  }

  /* RESERVED2[]  check */
  for (i=0; i<23; i++) {
    if (sftr->RESERVED2[i]) {
      sftr->RESERVED2[i] = 0;
      FAXerrno = RESERVEDFIELDZEROED;
    }
  }

  /* Checks of the coverpage text (pretty dangerous: we don't know how long!) */
  for (i=0; (&sftr->CoverTextDummy)[i]; i++) {
    if (!(isascii((&sftr->CoverTextDummy)[i]))) {
      FAXerrno = NONASCIISTRING;
      return(0);
    }
  }

  /* If reached all the way here, must be ok! */
  return(1);
}

/*
   FTRLOkToSend(ECS *ecs, FTRLIST *ftrl);

   This function checks a File Transfer Record List Structure for errors.  It
   follows the specifications for File Transfer Records documented in CAS 1.0.
   It returns 1 if the FTRL is valid for a task event.

   Reserved fields are tested for being zero; if not, they are zeroed and a
   warning is set.  Likewise other fields used by the Resident Manager that
   should be set to zero by the application are tested.  It they are not zero,
   they are set to zero, and a warning is set.

   INPUT:  The event control structure for the event sending the file, and the
   File Transfer Record List Structure to be tested.

   OUTPUT: 1 or 0.
*/

int pascal FTRLOkToSend(ECS *ecs, FTRLIST *ftrl)
{
  int i;
  struct stat fstatbuf;

  /* First, the file transfer: only the filename should be set */
  if (ecs->EventControlFile.TransferType == FILE_TRANSFER) {

    /* All the bytes before the filename should be zero ... */
    for (i=0; i<15; i++) {
      if ((&ftrl->OneFTR.FileType)[i]) {
        FAXerrno = FTRFIELDZEROED;
        (&ftrl->OneFTR.FileType)[i] = 0;
      }
    }

    /* ... and all the bytes after the filename should be also zero */
    for (i=95; i<97; i++) {
      if ((&ftrl->OneFTR.FileType)[i]) {
        FAXerrno = FTRFIELDZEROED;
        (&ftrl->OneFTR.FileType)[i] = 0;
      }
    }
  }

  /* Now, if TransferType is one of the fax types */
  else {

    /* FileType check */
    if ((ftrl->OneFTR.FileType < 0) ||
        (ftrl->OneFTR.FileType > 2)) {
      FAXerrno = FTRBADFILETYPE;
      return(0);
    }

    /* TextSize check */
    if ((ftrl->OneFTR.TextSize < 0) ||
        (ftrl->OneFTR.TextSize > 1)) {
      FAXerrno = FTRBADTEXTSIZE;
      return(0);
    }

    /* Fields FileStatus through PageCount should be 0 */
    for (i=2; i<15; i++) {
      if ((&ftrl->OneFTR.FileType)[i]) {
        FAXerrno = FTRFIELDZEROED;
        (&ftrl->OneFTR.FileType)[i] = 0;
      }
    }

    /* AddPageIncrements check: warning only, out-of-range values are ignored */
/*  if ((ftrl->OneFTR.AddPageIncrements < 0) ||
        (ftrl->OneFTR.AddPageIncrements > 7)) {
      FAXerrno = FTRBADPAGEINCREMENTS;
    }     (Actually, values from 0 to 127 are accepted and used.) */

    /* PageLength check */
    if ((ftrl->OneFTR.PageLength < -1) ||
        (ftrl->OneFTR.PageLength > 127)) {
      FAXerrno = FTRBADPAGELENGTH;
      return(0);
    }
  }

  /* In any case, the filename must be valid... */
  for (i=0; i<FULLFNAMELENGTH; i++) {
    if (!(ftrl->OneFTR.FileName[i])) {
      break;
    }
    if (!(isascii(ftrl->OneFTR.FileName[i]))) {
      FAXerrno = FTRNONASCIISTRING;
      return(0);
    }
  }
  if (i == FULLFNAMELENGTH) {
    FAXerrno = STRINGTOOLONG;
    ftrl->OneFTR.FileName[i - 1] = '\0';
  }

  /* ... and present */
  if (stat(ftrl->OneFTR.FileName, &fstatbuf)) {
    FAXerrno = FILETOSENDNOTFOUND;
    return(0);
  }

  /* ...and the last field is completely reserved */
  for (i=0; i<FTRRESERVED; i++) {
    if (ftrl->OneFTR.RESERVED[i]) {
      FAXerrno = FTRRESERVEDZEROED;
      ftrl->OneFTR.RESERVED[i] = 0;
    }
  }

  /* If we passed all that, must be ok! */
  return(1);
}

void pascal free_FTRLIST(FTRLIST *ftrl)
{
  FTRLIST *CurrFTRL, *LastFTRL;
  int i;

  LastFTRL = ftrl;
  for (i=1; LastFTRL->next; i++) {  /* find last */
    LastFTRL = LastFTRL->next;
  }

  /* Free them, from last backwards, until only the first is left */
  while(LastFTRL != ftrl) {
    CurrFTRL = ftrl;                      /* reset to beginning of list */
    while (CurrFTRL->next != LastFTRL) {  /* and go to next-to-last */
      CurrFTRL = CurrFTRL->next;
    }
    free(LastFTRL);                /* free the last one, */
    LastFTRL = CurrFTRL;           /* and name the next-to-last the last */
  }                    /* loop ends when last is the first */
  free(LastFTRL);      /* so free it, and we're done.  */
}

void pascal freeup(ECS *ecs)
{
  FTRLIST *CurrFTRL, *LastFTRL;
  size_t CoverLength = ecs->EventControlFile.FTROffset - 383;
  int i,
      FileCount = ecs->EventControlFile.FileCount;

  /* If cover, free it */
  if (CoverLength) {
    free(ecs->CoverPageText);
  }

  /* If there is an FTRLIST,  free FTRL's, up to FileCount or last FTRL */
  if (ecs->FirstFTR) {
    LastFTRL = ecs->FirstFTR;
    for (i=1; ((LastFTRL->next) && (i < FileCount)) ; i++) {  /* find last */
      LastFTRL = LastFTRL->next;
    }

    /* Free them, from last backwards, until only the first is left */
    while(LastFTRL != ecs->FirstFTR) {
      CurrFTRL = ecs->FirstFTR;             /* reset to beginning of list */
      while (CurrFTRL->next != LastFTRL) {  /* and go to next-to-last */
        CurrFTRL = CurrFTRL->next;
      }
      free(LastFTRL);                /* free the last one, */
      LastFTRL = CurrFTRL;           /* and name the next-to-last the last */
    }                    /* loop ends when last is the first */
    free(LastFTRL);      /* so free it, and we're done.  */
  }

  /* Finally, the event structure itself */
  free(ecs);
}

int pascal ValidTime(CAS_TIME *time)
{
  if ((time->Hour < 0) || (time->Hour > 23)) {
    return(0);
  }
  if ((time->Minute < 0) || (time->Minute > 59)) {
    return(0);
  }
  if ((time->Second < 0) || (time->Second > 59)) {
    return(0);
  }
  return(1);
}

int pascal ValidDate(CAS_DATE *date)
{
  int leap;

  if ((date->Month < 1) || (date->Month > 12) ||
      (date->Year < 1980) || (date->Year > 2099)) {
    return(0);
  }
  leap = (date->Year % 4 == 0) &&
         (date->Year % 100 != 0) ||
         (date->Year % 400 == 0);
  if ((date->Day < 1) ||
      (date->Day > days_in_month[leap][date->Month])) {
    return(0);
  }
  return(1);
}
