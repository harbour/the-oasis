

/*
   FAXFREEE.C  A high-level CAS Toolkit function.

   This function frees all the memory used by it's parameter, an Event
   Control Structure.

   INPUT:  A complete Event Control Structure.

   OUTPUT: SUCCESS or FAIL.
*/

#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <cas.h>
#include <fax.h>

int pascal FAXFreeECS(ECS *SourceECS)
{
  int CoverLength = SourceECS->EventControlFile.FTROffset - 383;
  FTRLIST *CurrFTRL, *LastFTRL;
  int i,
      FileCount = SourceECS->EventControlFile.FileCount;

  FAXerrno = CASerrorcode = 0;      /* They keep it if nothing goes wrong */

  if (!SourceECS) {
    FAXerrno = INVALIDPTR;
    return(FAIL);
  }
  /* If there is an FTRLIST,  free FTRL's, up to FileCount or last FTRL */
  if (SourceECS->FirstFTR) {
    if (!FileCount) {
      FAXerrno = MOREFTRSTHANFC;
    }
    LastFTRL = SourceECS->FirstFTR;
    for (i=1; ((LastFTRL->next) && (i < FileCount)) ; i++) {  /* find last */
      LastFTRL = LastFTRL->next;
    }

    /* Following errors are warnings only: go ahead and free what's possible */
    if (LastFTRL->next) {
      FAXerrno = MOREFTRSTHANFC;           /* last FTRL doesn't point to NULL */
      LastFTRL->next = NULL;
    }
    if (i < FileCount) {
      FAXerrno = BADFILECOUNT;             /* FileCount exceeds FTRL's */
    }

    /* Free them, from last backwards, until only the first is left */
    free_FTRLIST(SourceECS->FirstFTR);
  }
  else {
    if (FileCount) {
      FAXerrno = BADFILECOUNT;
    }
  }

  /* Next, the coverpage text.  */
  if (CoverLength) {
    free(SourceECS->CoverPageText);
  }

  /* Finally, the Event Control Structure itself */
  free (SourceECS);
  return(SUCCESS);
}
