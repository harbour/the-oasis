

/*
   FAXGETE3.C  A high-level CAS Toolkit function.

   This function gets one or more File Transfer Records (FTR's) of an event.

   INPUT:  Required: An event handle, the number of the first FTR to retrieve,
                     and the number of FTR's to retrieve.
           Optional: A queue number and a pointer to a list of FTR structures.

   OUTPUT: Pointer to a list of File Transfer Record structures, the
           queue in which the event was found, and the number of FTR's
           actually retrieved.
*/

#include <stdlib.h>
#include <io.h>
#include <stdio.h>
#include <malloc.h>
#include <cas.h>
#include <fax.h>

FTRLIST * pascal FAXGetEventFileInfo(int EventHandle,
                                     BYTE *queue,
                                     FTRLIST *FTRs,
                                     int WhichFTRFirst,
                                     int *HowManyFTRs)
{
  int FileHandle,                 /* returned from CASFind functions */
      retval,                     /* for return value of CAS calls */
      red;                        /* bytes or FTR's read with the read() */
  int i;                          /* just for counting */
  long sought;                    /* an honest woman... */
  ECF ControlInfo;                /* need FTROffset to find FTRs */
  FTRLIST *CurrFTRL,              /* for stepping down the linked list */
          *FTRLhead;              /* pointer to head of list */
  CECS CurrentEventInfo;

  FAXerrno = CASerrorcode = 0;      /* They keep it if nothing goes wrong */

  /* If the event is currently executing, can't get just any file info, */
  /*   but can get the info for the currently transmitting file.  For that, */
  /*   use the function CASGetCurrentEventStatus function directly. */
  if (EventHandle == CASGetCurrentEventStatus(&CurrentEventInfo)) {
    FAXerrno = EVENTISCURRENT;
    return(NULL);
  }

  /* If no queue specified, search all the queues for the given Event Handle */
  if (*queue == UNKNOWN_QUEUE) {
    for (*queue = TASK_QUEUE; *queue <= LOG_QUEUE; (*queue)++) {
      retval = CASFindFirst(ANY_STATUS, SEARCH_FORWARD, *queue);
      while (retval && (retval != EventHandle)) {
        if (retval > 0) {           /* found an event, but not the one sought */
          retval = CASFindNext(*queue);       /* so find next one */
        }
        else break;                 /* end of queue, or other error */
      }
      if (retval == EventHandle) break;           /* else go to next queue */
    }                                             /* Done with all the queues */
    if (retval != EventHandle) {       /* after all that, just give up! */
      *queue = UNKNOWN_QUEUE;
      FAXerrno = EVENTNOTFOUND;
      CASerrorcode = -retval;
      return(NULL);
    }
  }

  /* To get to here, the queue was given, or we found it anyway */
  retval = CASOpenFile(EventHandle, 0, *queue);
  if (retval < 0) {                            /* CAS error, get out */
    FAXerrno = OPENFILE;
    CASerrorcode = -retval;
    return(NULL);
  }
  FileHandle = retval;

  /* First, read the Event Control File to know the number of FTR's */
  red = read(FileHandle, (char *)&ControlInfo, sizeof(ECF));
  if (red != sizeof(ECF)) {
    FAXerrno = CANTREADFILE;
    return(NULL);
  }

  /* Next, seek to beginning of FTR's */
  sought = lseek(FileHandle, (long)ControlInfo.FTROffset, SEEK_SET);
  if (sought == -1L) {
    FAXerrno = LSEEKERROR;
    return(NULL);
  }

  /* Check that starting point is within range */
  if (WhichFTRFirst >= ControlInfo.FileCount) {
    FAXerrno = NOTTHATMANYFILES;
    return(NULL);
  }

  /* "0" means get ALL of them, from WhichFTRFirst on... */
  if (*HowManyFTRs == 0) {
    *HowManyFTRs = ControlInfo.FileCount - WhichFTRFirst;
  }

  /* Advance to FTR indicated by parameter WhichFTRFirst */
  if ((WhichFTRFirst + *HowManyFTRs) > ControlInfo.FileCount) {
    FAXerrno = NOTTHATMANYFILES;
    return(NULL);
  }
  else {
    sought = lseek(FileHandle, (long)WhichFTRFirst * sizeof(FTR), SEEK_CUR);
    if (sought == -1L) {
      FAXerrno = LSEEKERROR;
      return(NULL);
    }
  }

  /* Decide whether to allocate the linked list or use the caller's */
  if (FTRs) {
    CurrFTRL = FTRLhead = FTRs;
  }
  else {
    CurrFTRL = FTRLhead = (FTRLIST *)calloc(1, sizeof(FTRLIST));
    if (!CurrFTRL) {
      FAXerrno = OUTOFMEMORY;
      *HowManyFTRs = 0;
      return(NULL);
    }
    for (i=1; i<*HowManyFTRs; i++) {
      CurrFTRL->next = (FTRLIST *)calloc(1, sizeof(FTRLIST));
      if (!CurrFTRL->next) {
        FAXerrno = OUTOFMEMORY;
        *HowManyFTRs = 0;
        free_FTRLIST(FTRLhead);
        return(NULL);
      }
      CurrFTRL = CurrFTRL->next;
    }
    CurrFTRL = FTRLhead;
  }

  /* Having reached WhichFTRFirst, read in the number of FTR's requested */
  for (i = 0;
       i < *HowManyFTRs;
       CurrFTRL = CurrFTRL->next, i++) {

    if (eof(FileHandle)) {
      FAXerrno = UNEXPECTEDEOF; /* EOF, but there should have been more FTR's */
      close(FileHandle);
      *HowManyFTRs = i;
      if (!FTRs) {
        free_FTRLIST(CurrFTRL);
      }
      return(FTRLhead);
    }
    red = read(FileHandle, (char *)&CurrFTRL->OneFTR, sizeof(FTR));
    if (red != sizeof(FTR)) {
      FAXerrno = CANTREADFILE;
      *HowManyFTRs = i;
      if (!FTRs) {
        free_FTRLIST(CurrFTRL);
      }
      return(FTRLhead);
    }
    memset(CurrFTRL->OneFTR.RESERVED, 0, FTRRESERVED);
  }
  if (close(FileHandle) == -1) {
    FAXerrno = CANTCLOSEFILE;          /* Warning only, we got what we wanted */
  }
  *HowManyFTRs = i;
  return(FTRLhead);
}
