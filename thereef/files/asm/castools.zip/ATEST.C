int test[] = {1};
main()
{
*test = 5;
}
