

/*
   GETENTRY.C  Function PbLookUpEntry: Gets a phonebook entry (individual
      or group) based on its name (exact) or record ID.

   INPUT:  Phonebook structure, possibly memory space to hold the entry, and
      an exact name or record ID.

   OUTPUT: If successful, a pointer to a phonebook entry structure holding the
      requested entry.
*/

#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <phonebk.h>

PBE * pascal PbGetEntry(PB *pb, PBE *entry, char *name, int RecordID)
{
  PBE *pbe;
  PBEFIXED *result;              /* return for GetFixedPart */
  int red;                       /* return value for fread() */
  PBEFIXED fixed_part;           /* for the known-length part of entry */
  char *vbl_part = NULL;         /* for the variable-length part of entry */
  size_t vbl_length;             /* length of variable-length part of entry */
  int i, j, k;                   /* loop counters */
  int temperrno = 0;             /* for saving aside Pberrno */

  Pberrno = 0;                    /* Initially, always reset */

  /* First, check params */
  if ((pb == NULL) ||
      ((name == NULL) && (RecordID == -1))) {
    Pberrno = INVALIDPARAMETER;
    return(NULL);
  }
  if ((RecordID < -1) ||
      (RecordID > 999)) {
    Pberrno = INVALIDPARAMETER;
    return(NULL);
  }

  if (RecordID == -1) {
    for (RecordID = 0; RecordID < MAXENTRIES; RecordID++) {
      result = GetFixedPart(pb, &fixed_part, RecordID);
      if (result) {
        if (!(strnicmp(fixed_part.name, name, NAMELENGTH))) {
          break;
        }
      }
      else {
        if (Pberrno) {              /* GetFixedPart encountered an error */
          return(NULL);
        }
      }
    }
    if (RecordID == MAXENTRIES) {
      Pberrno = NOENTRYFOUND;
      return(NULL);
    }
  }

  /* ELSE:  The record id is given: ignore name, if any */
  else {
    result = GetFixedPart(pb, &fixed_part, RecordID);
    if (!result) {
      Pberrno = NOENTRYPRESENT;
      return(NULL);
    }
  }

  /* Now the fixed part is gotten: prepare final destination, and fill it in */
  if (!entry) {
    pbe = (PBE *)calloc(1, sizeof(PBE));
    if (!pbe) {
      Pberrno = OUTOFMEM;
      return(NULL);
    }
    if (fixed_part.type == PERSONENTRY) {
      if (!(pbe->fields = (char **)calloc(pb->header.fields,
                                          sizeof(char *)))) {
        Pberrno = OUTOFMEM;
        goto error_out;
      }
      for (i=0; i<pb->header.fields; i++) {
        if (!(pbe->fields[i] = (char *)calloc(60, sizeof(char)))) {
          Pberrno = OUTOFMEM;
          goto error_out;
        }
      }
    }
    if (!(pbe->MemberList = (int *)malloc(fixed_part.members * sizeof(int)))) {
      Pberrno = OUTOFMEM;
      goto error_out;
    }
  }
  else {
    pbe = entry;
  }
  memcpy(pbe, &fixed_part, sizeof(PBEFIXED));

  /* Read the rest of the entry into the complete entry structure */
  if (vbl_length = pbe->length - sizeof(PBEFIXED)) {
    if (!(vbl_part = (char *)malloc(vbl_length))) {
      Pberrno = OUTOFMEM;
      goto error_out;
    }
    red = fread(vbl_part, 1, vbl_length, pb->fp);
    if (red != vbl_length) {
      Pberrno = CANTREAD;
      goto error_out;
    }

    /* if read successful, fill in entry's variable fields */
    if (pbe->type == PERSONENTRY) {
      for (i=0, j=0; i<pb->header.fields; i++, j++) {
        for (k=0; k<MAXFIELDSIZE; k++, j++) {
          if (!(pbe->fields[i][k] = vbl_part[j])) {
            break;
          }
        }
      }
    }
    else {
      j = 0;
    }
    for (i=0; i<pbe->members; i++) {
      pbe->MemberList[i] = ((int *)(vbl_part + j))[i];
    }
    free(vbl_part);
  }

  /* If we got here, all went well! */
  return(pbe);

error_out:
  if (vbl_part) {
    free(vbl_part);
  }
  if (Pberrno) {
    temperrno = Pberrno;
  }
  if (!entry) {
    PbFreePBE(pb, pbe);
  }
  if (temperrno) {
    Pberrno = temperrno;
  }
  return(NULL);
}
