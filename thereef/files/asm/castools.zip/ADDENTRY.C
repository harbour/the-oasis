

/*
   ADDENTRY.C Function PbAddEntry:  Adds an entry (individual or group) to an
      open phonebook.

   INPUT:  Phonebook structure and filled phonebook entry structure.

   OUTPUT: If successful, updates the entries field of the phonebook
      structure, and sets the ID field of the entry structure.
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <phonebk.h>

int pascal PbAddEntry(PB *pb, PBE *entry)
{
  int i;
  PBEFIXED fixed_part;
  char *entry_buffer = NULL;    /* entry that actually gets written to file */
  int filenum;                  /* for call to fileno() */
  long PbSize;
  long offset;
  int buffed_rids;
  int rid;
  int writ;                /* for return from fwrite() */
  int members = entry->members;

  /* Error checks */

  Pberrno = 0;                               /* Initially, always reset */

  /* First, check params */
  if ((pb == NULL) ||
      (entry == NULL)) {
    Pberrno = INVALIDPARAMETER;
    goto error_out;
  }

  /* Find the first RID in the offsets array that is NULL, and save that */
  /* If no free RID is found, the phonebook is full */
  for (i=0; i<MAXENTRIES; i++) {
    if (!OffsetOfEntry(pb, i)) {
      break;
    }
  }
  if ((rid = i) == MAXENTRIES) {
    Pberrno = PHONEBOOKFULL;
    goto error_out;
  }

  /* Now that we know the phonebook is NOT full, check the #of entries field */
  if (pb->header.entries >= MAXENTRIES) {
    Pberrno = INCONSISTENTPBH;              /* this is warning only */
  }

  /* one part of the entry that must be set is the RID field */
  entry->id = rid;

  /* Check the proposed new entry for correctness, returning a formatted */
  /*   data area for an entry to add.  note: membership is nulled */
  if (!(entry_buffer = EntryOkToAdd(pb, entry))) {
    Pberrno = INVALIDENTRY;
    goto error_out;
  }

  /* Next, find the offset of the end-of-file , and set a vbl offset to it */
  filenum = fileno(pb->fp);
  PbSize = filelength(filenum);
  if (PbSize == -1L) {
    Pberrno = FILELENGTHERROR;
    goto error_out;
  }
  offset = PbSize;

  /* Write the new entry to the end of the file, quitting if an error occurred*/
  if (fseek(pb->fp, 0L, SEEK_END)) {
    Pberrno = FSEEKERROR;
    goto error_out;
  }
  writ = fwrite(entry_buffer, entry->length, 1, pb->fp);
  if (writ != 1) {
    Pberrno = CANTWRITE;
    goto error_out;
  }

  /* Update entries field in pb->header and write that int to disk */
  if (Pberrno != INCONSISTENTPBH) {
    pb->header.entries++;
    if (fseek(pb->fp,
              4L,
              SEEK_SET)) {
      Pberrno = FSEEKERROR;
      goto error_out;
    }
    writ = fwrite(&pb->header.entries, sizeof(WORD), 1, pb->fp);
    if (writ != 1) {
      Pberrno = CANTWRITE;
      goto error_out;
    }
  }

  /* Update the Obuffer, if there is one, and write that info to disk */
  if (pb->OBuffer) {

    /* We can be sure that the rid IS in the buffer, from using OffsetOfEntry */
    pb->OBuffer[rid - pb->FirstOBufferRID] = offset;
  }
  if (fseek(pb->fp, 160L + rid*sizeof(LONGWORD), SEEK_SET)) {
    Pberrno = FSEEKERROR;
    goto error_out;
  }
  writ = fwrite(&offset, sizeof(LONGWORD), 1, pb->fp);
  if (writ != 1) {
    Pberrno = CANTWRITE;
    goto error_out;
  }

  /* If group has members already, add them now */
  for (i=0; i<members; i++) {
    if (!(PbAddToGroup(pb, rid, entry->MemberList[i]))) {
      goto error_out;           /* Pberrno should be set by PbAddToGroup() */
    }
  }

  /* If we got here w/o falling out, all was well! */
  free(entry_buffer);
  return(SUCCESS);

error_out:
  if (entry_buffer) {
    free(entry_buffer);
  }
  return(FAIL);
}
