

/*
   OPENPHONE.C  Function PbOpenPhonebook:  opens an existing phonebook.

   This function opens an existing phonebook for queries or modification.

   INPUT:  Name of phonebook file, and optionally a pointer to a
   phonebook structure.

   OUTPUT: If a phonebook structure was provided on input, it is filled with
   the new phonebook's data.
*/

#include <stdlib.h>
#include <malloc.h>
#include <stdio.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <memory.h>
#include <phonebk.h>

PB * pascal PbOpenPhonebook(PB *pb,
                            char *name)
{
  PB *phonebook;
  struct stat filestat;
  size_t red;                /* for return from fread() */
  int result;             /* for return from stat() */

  Pberrno = 0;            /* Initially, always reset */

  /* First, check params */
  if (name == NULL) {
    Pberrno = INVALIDPARAMETER;
    return(NULL);
  }

  /* First, check that the file named for the phonebook exists */
  result = stat(name, &filestat);
  if (result) {
    Pberrno = FILEDOESNTEXIST;
    return(NULL);
  }

  /* If a phonebook structure provided, use it; otherwise allocate one */
  if (!pb) {
    phonebook = (PB *)malloc(sizeof(PB));
    if (!phonebook) {
      Pberrno = OUTOFMEM;
      return(NULL);
    }
  }
  else {
    phonebook = pb;
  }

  /* The file exists; open it for reading and writing, and read its header */
  phonebook->fp = fopen(name, "r+b");
  if (!phonebook->fp) {
    Pberrno = CANTOPEN;
    if (!pb) {
      free(phonebook);
    }
    return(NULL);
  }
  red = fread((char *)&phonebook->header, sizeof(PBH), 1, phonebook->fp);
  if (red != 1) {
    Pberrno = CANTREAD;
    fclose(phonebook->fp);
    if (!pb) {
      free(phonebook);
    }
    return(NULL);
  }
  phonebook->OBufferSize = 0;
  phonebook->OBuffer = NULL;
  phonebook->FirstOBufferRID = 0;

  return(phonebook);      /* And that's all! */
}
