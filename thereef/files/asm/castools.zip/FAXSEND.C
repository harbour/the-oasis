/*
   FAXSEND.C  The first high-level CAS Toolkit function.

   This function submits a send task to the Resident Manager of the
   communications hardware.  It sets communications options using its own
   parameters in combination with the global variable DefaultsECS.

   INPUT:  The global Event Control structure DefaultsECS and parameters for
           "who, what, and when" that override the defaults.

   OUTPUT: The Event handle if successful, otherwise 0.
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <cas.h>
#include <fax.h>

extern int pascal FAXSend(char *to,
                   char *PhoneNumber,
                   FILELIST *files,
                   CAS_DATE *date,
                   CAS_TIME *time)
{
  FILELIST *CurrFile = NULL;          /* temp for caller's list of files  */
  FTRLIST *CurrFTRLIST = NULL,
          *NextFTRLIST = NULL,        /* for building the events list of FTR's*/
          *LastFTRLIST;               /* for freeing the FTR list */
  int FileCount;                      /* number of files to send for TCF */
  SFTR *SingleFileSend;               /* In case there is only one file */
  int retval = 0;                     /* default, if anything goes wrong */
  EDB *EDBbuffer;                     /* for CAS call GetExternalData */
  char *TCFfilename = NULL;           /* tmpnam() allocates space for this */
  FILE *fptr;                         /* Stream pointer for TCF */
  WORD CallerTime, CallerDate;        /* Intermediate holders */
  int writ;                           /* To catch errors: # of items written */
  int i;

  /* Event attributes saved, just in case they're needed. */
  int CoverLength = DefaultsECS.EventControlFile.FTROffset - 383;
                                    /* to understand '383', see Intel/DCA CAS */

  FTRLIST *SaveFileList = DefaultsECS.FirstFTR;
  WORD SaveDate = DefaultsECS.EventControlFile.EventDate;
  WORD SaveTime = DefaultsECS.EventControlFile.EventTime;
  int SaveFileCount = DefaultsECS.EventControlFile.FileCount;
  char SaveDestName[32],
       SaveDestPhone[47];             /* These saved ONLY if necessary */

  FAXerrno = CASerrorcode = 0;      /* They keep it if nothing goes wrong */

  /* Check the defaults structure, whether we use it or not */
  if (!(ECSOkToSubmit(&DefaultsECS))) {
    FAXerrno = INVALIDDEFAULTS;              /* For now, it's a warning only */
  }

  /* convert to DOS file time and date format */
  if (time) {
    if (ValidTime(time)) {
      CallerTime = ((int)time->Second / 2) |
                   ((int)time->Minute << 5) |
                   ((int)time->Hour << 11);
    }
    else {
      FAXerrno = BADEVENTTIME;
      return(retval);
    }
  }
  if (date) {

    /* If not all 0's, check for validity before converting */
    if (date->Day || date->Month || date->Year) {
      if (ValidDate(date)) {
        CallerDate = (int)date->Day |
                     ((int)date->Month << 5) |
                     (((int)date->Year - 1980) << 9);
      }
      else {
        FAXerrno = BADEVENTDATE;
        return(retval);
      }
    }
    else {
      CallerDate = 0;
    }
  }

  /* If only one file, and none of the fields ignored by the SubmitSingleFile
     function are set, use SubmitSingleFile. */
  if (
      SubmitSingleOk(&DefaultsECS) &&
      (
       (files)? files->next == NULL :
                DefaultsECS.EventControlFile.FileCount == 1
      )
     ) {

    if (!DefaultsECS.FirstFTR) {
      FAXerrno = BADFILECOUNT;
      return(retval);
    }

    SingleFileSend = (SFTR *)calloc(sizeof(SFTR) + CoverLength, 1);
    if (!SingleFileSend) {
      FAXerrno = OUTOFMEMORY;
      return(retval);
    }

    /* Set SFTR fields from the Defaults and the parameters */
    SingleFileSend->TransferType = DefaultsECS.EventControlFile.TransferType;
    if (SingleFileSend->TransferType != FILE_TRANSFER) { /* it's a fax type */
      SingleFileSend->TextSize =  DefaultsECS.FirstFTR->OneFTR.TextSize;
    }

    /* Now do the date and time fields, converting to DOS file format */
    SingleFileSend->EventTime = (time)? CallerTime :
                                        DefaultsECS.EventControlFile.EventTime;
    SingleFileSend->EventDate = (date)? CallerDate :
                                        DefaultsECS.EventControlFile.EventDate;
    strncpy(SingleFileSend->DestinationName,
            (to)? to :
                  DefaultsECS.EventControlFile.DestinationName,
            NAMELENGTH);
    if (SingleFileSend->DestinationName[NAMELENGTH-1]) {
      FAXerrno = STRINGTOOLONG;
      SingleFileSend->DestinationName[NAMELENGTH-1] = '\0';
    }
    strncpy(SingleFileSend->FileName,
            (files)? files->FileName :
                     DefaultsECS.FirstFTR->OneFTR.FileName,
            FULLFNAMELENGTH);
    if (SingleFileSend->FileName[FULLFNAMELENGTH-1]) {
      FAXerrno = STRINGTOOLONG;
      SingleFileSend->FileName[FULLFNAMELENGTH-1];
    }
    if (DefaultsECS.FirstFTR->next) {
      FAXerrno = MOREFTRSTHANFC;
    }
    strncpy(SingleFileSend->Phone,
            (PhoneNumber)? PhoneNumber :
                           DefaultsECS.EventControlFile.Phone,
            PHONENUMLENGTH);
    if (SingleFileSend->Phone[PHONENUMLENGTH-1]) {
      FAXerrno = STRINGTOOLONG;
      SingleFileSend->Phone[PHONENUMLENGTH-1] = '\0';
    }
    strncpy(SingleFileSend->ApplicationTag,
            DefaultsECS.EventControlFile.ApplicationTag,
            APPTAGLENGTH);
    if (SingleFileSend->ApplicationTag[APPTAGLENGTH-1]) {
      FAXerrno = STRINGTOOLONG;
      SingleFileSend->ApplicationTag[APPTAGLENGTH-1] = '\0';
    }
    SingleFileSend->SendCover = DefaultsECS.EventControlFile.SendCover;
    if (CoverLength && DefaultsECS.CoverPageText) {
      strncpy(&SingleFileSend->CoverTextDummy,
              DefaultsECS.CoverPageText,
              CoverLength);
      if ((&SingleFileSend->CoverTextDummy)[CoverLength-1]) {
        FAXerrno = STRINGTOOLONG;
        (&SingleFileSend->CoverTextDummy)[CoverLength-1] = '\0';
      }
    }

    /* All done setting up, nothing left but to check and ship it! */
    if (SFTROkToSubmit(SingleFileSend)) {
      retval = CASSubmitSingleFile(SingleFileSend);
      free(SingleFileSend);
      if (retval < 0) {
        FAXerrno = SUBMITSINGLE;
        CASerrorcode = -retval;
        return(0);
      }
    }
    else {
      free(SingleFileSend);
      return(retval);
    }
  }
  /* If NOT doing a SubmitSingle, write Task Control File, submit the event, */
  /*    and restore the original values of the Defaults. */
  else {

    /* First, save and assign the destination name and phone, if necessary */
    if (to) {
      strncpy(SaveDestName,
              DefaultsECS.EventControlFile.DestinationName,
              NAMELENGTH);
      if (SaveDestName[NAMELENGTH-1]) {
        FAXerrno = STRINGTOOLONG;
        SaveDestName[NAMELENGTH-1] = '\0';
      }
      strncpy(DefaultsECS.EventControlFile.DestinationName,
              to,
              NAMELENGTH);
      if (DefaultsECS.EventControlFile.DestinationName[NAMELENGTH-1]) {
        FAXerrno = STRINGTOOLONG;
        DefaultsECS.EventControlFile.DestinationName[NAMELENGTH-1] = '\0';
      }
    }
    if (PhoneNumber) {
      strncpy(SaveDestPhone,
              DefaultsECS.EventControlFile.Phone,
              PHONENUMLENGTH);
      if (SaveDestPhone[PHONENUMLENGTH-1]) {
        FAXerrno = STRINGTOOLONG;
        SaveDestPhone[PHONENUMLENGTH-1] = '\0';
      }
      strncpy(DefaultsECS.EventControlFile.Phone,
              PhoneNumber,
              PHONENUMLENGTH);
      if (DefaultsECS.EventControlFile.Phone[PHONENUMLENGTH-1]) {
        FAXerrno = STRINGTOOLONG;
        DefaultsECS.EventControlFile.Phone[PHONENUMLENGTH-1] = '\0';
      }
    }
    if (time)
        DefaultsECS.EventControlFile.EventTime = CallerTime;
    if (date)
        DefaultsECS.EventControlFile.EventDate = CallerDate;

    /* Next, if files specified, build new FTRs and attach to DefaultsECS */
    if (files) {
      for (CurrFile = files, FileCount = 0;
           CurrFile;                                /* while more files */
           CurrFile = CurrFile->next, FileCount++) {

        NextFTRLIST = (FTRLIST *)calloc(sizeof(FTRLIST), 1); /* make an FTR */
        if (!NextFTRLIST) {
          FAXerrno = OUTOFMEMORY;
          goto restore;
        }
        if (!CurrFTRLIST) {           /* If the first, make it so */
          CurrFTRLIST = DefaultsECS.FirstFTR = NextFTRLIST;
        }
        else {          /* otherwise connect it up to the last one allocated */
          CurrFTRLIST = CurrFTRLIST->next = NextFTRLIST;
        }

        strncpy(CurrFTRLIST->OneFTR.FileName,
                CurrFile->FileName,
                FULLFNAMELENGTH);
        if (CurrFTRLIST->OneFTR.FileName[FULLFNAMELENGTH-1]) {
          FAXerrno = STRINGTOOLONG;
          CurrFTRLIST->OneFTR.FileName[FULLFNAMELENGTH-1] = '\0';
        }
        CurrFTRLIST->next = NULL;

        /* IF FAXing, set fax-specific fields from CurrFile AND Defaults FTR */
        if (DefaultsECS.EventControlFile.TransferType != FILE_TRANSFER) {
          CurrFTRLIST->OneFTR.FileType = CurrFile->FileType;
          CurrFTRLIST->OneFTR.TextSize = DefaultsFTRL.OneFTR.TextSize;
          CurrFTRLIST->OneFTR.AddPageIncrements = DefaultsFTRL.OneFTR.AddPageIncrements;
          CurrFTRLIST->OneFTR.PageLength = DefaultsFTRL.OneFTR.PageLength;
        }  /* no else: just leaving them all 0's is correct for file transfers */

      }                                /* end of while (more files) */
      DefaultsECS.EventControlFile.FileCount = FileCount;
    }   /* end of if (files); no else:  FirstFTR already points to an FTRLIST */

    /* If any of the fields common with the External Data Block are not       */
    /*    initialized, get the EDB. */
    if ((DefaultsECS.EventControlFile.SenderName[0] == '\0') ||
        (DefaultsECS.EventControlFile.LogoFilePath[0] == '\0')) {
      EDBbuffer = (EDB *)malloc(sizeof(EDB));
      if (!EDBbuffer) {
        FAXerrno = OUTOFMEMORY;
        goto restore;
      }
      if (CASGetExternalData(EDBbuffer)) {
        FAXerrno = GETEDB;  /* Warning only: too bad, but we can still go on. */
        free(EDBbuffer);
      }
      else {
        if (DefaultsECS.EventControlFile.SenderName[0] == '\0') {
          strncpy(DefaultsECS.EventControlFile.SenderName,
                  EDBbuffer->DefaultSender,
                  NAMELENGTH);
          if (DefaultsECS.EventControlFile.SenderName[NAMELENGTH-1]) {
            FAXerrno = STRINGTOOLONG;
            DefaultsECS.EventControlFile.SenderName[NAMELENGTH-1] = '\0';
          }
        }
        if (DefaultsECS.EventControlFile.LogoFilePath[0] == '\0') {
          strncpy(DefaultsECS.EventControlFile.LogoFilePath,
                  EDBbuffer->DefaultDir,
                  FULLFNAMELENGTH);    /* This pads out full field to '\0's */
          if (DefaultsECS.EventControlFile.LogoFilePath[DIRPATHLENGTH-1]) {
            FAXerrno = STRINGTOOLONG;
            DefaultsECS.EventControlFile.LogoFilePath[DIRPATHLENGTH-1] = '\0';
          }
          strncat(DefaultsECS.EventControlFile.LogoFilePath,
                  EDBbuffer->DefaultLogo,
                  FNAMELENGTH);
          if (DefaultsECS.EventControlFile.LogoFilePath[FULLFNAMELENGTH-1]) {
            FAXerrno = STRINGTOOLONG;
            DefaultsECS.EventControlFile.LogoFilePath[FULLFNAMELENGTH-1] = '\0';
          }
        }
        free(EDBbuffer);
      }
    }

    /* The Event Control Structure is complete:  Check it and BUILD the TCF! */

    if (ECSOkToSubmit(&DefaultsECS)) {

      /* Get the file ready:  name, open and write to it. */
      TCFfilename = tmpnam(NULL);

      if((fptr = fopen(TCFfilename, "wb")) == NULL) {
         FAXerrno = CANTOPENFILE;
         goto restore;
      }
      /* Write the TCF data to disk, starting with the Event control structure. */
      writ = fwrite(&DefaultsECS.EventControlFile, sizeof(ECF), 1, fptr);
      if (writ < 1) {
        FAXerrno = CANTWRITEFILE;
        fclose(fptr);
        goto restore;
      }

      /* Whether to write cover text depends only on CoverLength, not SendCover*/
      if (CoverLength) {
        writ = fwrite(DefaultsECS.CoverPageText, CoverLength, 1, fptr);
        if (writ < 1) {
          FAXerrno = CANTWRITEFILE;
          fclose(fptr);
          goto restore;
        }
      }

      /* Finally, write the File Transfer Records */
      for (FileCount = 0, CurrFTRLIST = DefaultsECS.FirstFTR;
           FileCount < DefaultsECS.EventControlFile.FileCount;
           FileCount++, CurrFTRLIST = CurrFTRLIST->next) {

        if (!CurrFTRLIST) {
          FAXerrno = BADFILECOUNT;
          fclose(fptr);
          goto restore;
        }
        writ = fwrite(&CurrFTRLIST->OneFTR, sizeof(FTR), 1, fptr);
        if (writ < 1) {
          FAXerrno = CANTWRITEFILE;
          fclose(fptr);
          goto restore;
        }
      }
      if (CurrFTRLIST) {
        FAXerrno = MOREFTRSTHANFC;            /* warning only */
      }

      if (fclose(fptr)) {
        FAXerrno = CANTCLOSEFILE;
        goto restore;
      }

      /* Finally, submit! */
      retval = CASSubmitTask(TCFfilename);
      if (retval < 0) {
        FAXerrno = SUBMITTASK;
        CASerrorcode = -retval;
        retval = 0;
        goto restore;
      }
    }
restore:
    /* Restore defaults to Defaults structure */
    if (TCFfilename) {
        remove(TCFfilename);
    }
    if (to) {
      strncpy(DefaultsECS.EventControlFile.DestinationName,
              SaveDestName,
              NAMELENGTH);
      if (DefaultsECS.EventControlFile.DestinationName[NAMELENGTH-1]) {
        FAXerrno = STRINGTOOLONG;
        DefaultsECS.EventControlFile.DestinationName[NAMELENGTH-1] = '\0';
      }
    }
    if (PhoneNumber) {
      strncpy(DefaultsECS.EventControlFile.Phone,
              SaveDestPhone,
              PHONENUMLENGTH);
      if (DefaultsECS.EventControlFile.Phone[PHONENUMLENGTH-1]) {
        FAXerrno = STRINGTOOLONG;
        DefaultsECS.EventControlFile.Phone[PHONENUMLENGTH-1] = '\0';
      }
    }
    if (time) {
      DefaultsECS.EventControlFile.EventTime = SaveTime;
    }
    if (date) {
      DefaultsECS.EventControlFile.EventDate = SaveDate;
    }
    if (DefaultsECS.FirstFTR != SaveFileList) {

      /* First, free up the FTR list we created, from the end backwards */
      free_FTRLIST(DefaultsECS.FirstFTR);

      /* Finally, restore originals */
      DefaultsECS.FirstFTR = SaveFileList;
      DefaultsECS.EventControlFile.FileCount = SaveFileCount;
    }

  }  /* end of else: there were multiple files, so use a TCF */
  return(retval);   /* And we're ATTA-HERE!! */
}
