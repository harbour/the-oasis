

/*
   FAXCANCE.C  A high-level CAS Toolkit function.

   This function cancels or aborts a Task Event.

   INPUT:  An event handle.

   OUTPUT: Returns the event handle if successful, otherwise 0.
*/

#include <stdlib.h>
#include <stdio.h>
#include <cas.h>
#include <fax.h>

int pascal FAXCancelTask(int EventHandle)
{
  int retval = 0;                 /* for return value of CAS calls */
  CECS CurrentEventInfo;          /* for call to CASGetCurrentEventStatus */

  FAXerrno = CASerrorcode = 0;      /* They keep it if nothing goes wrong */

  /* If the event is currently executing, abort it */
  if (EventHandle == CASGetCurrentEventStatus(&CurrentEventInfo)) {
    retval = CASAbortCurrentEvent(); /* Changes Task Control File to a Log */
    if (retval < 0) {                /* Control File of an aborted event */
      FAXerrno = ABORTCURRENT;
      goto finish;
    }
    else {
      FAXerrno = EVENTWASCURRENT;    /* Warning only */
      goto finish;
    }
  }
  else {
    retval = CASDeleteFile(EventHandle, 0, TASK_QUEUE);
    if (retval) {
      FAXerrno = DELETEFILE;
      goto finish;
    }
    else {
      retval = EventHandle;
    }
  }

finish:
  if (retval < 0) {
    CASerrorcode = -retval;
    return(0);
  }
  else {
    return(retval);
  }
}
