

/*
   FAXSPECI.C  The second high-level CAS Toolkit function.

   This function submits a send task to the Resident Manager of the
   communications hardware.  It sets all communications options using its own
   parameters.

   INPUT:  A complete Event Control structure plus optional
           "who, what, and when" parameters to override some fields
           in the structure.

   OUTPUT: The Event handle if successful, otherwise 0.
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <cas.h>
#include <fax.h>

int pascal FAXSubmitTask(ECS *TaskSettings,
                          char *to,
                          char *PhoneNumber,
                          FILELIST *files,
                          CAS_DATE *date,
                          CAS_TIME *time)
{
  ECS SaveECS;                        /* to be copy of original for restoring */
  FILELIST *CurrFile = NULL;          /* temp for caller's list of files  */
  FTRLIST *CurrFTRL = NULL,
          *NextFTRL = NULL,
          *LastFTRL;                  /* for building or freeing list of FTR's*/
  int FileCount;                      /* number of files to send for TCF */
  SFTR *SingleFileSend = NULL;        /* In case there is only one file */
  int retval = 0;                     /* for CAS function return */
  EDB *EDBbuffer = NULL;              /* for CAS call GetExternalData */
  char *TCFfilename = NULL;           /* tmpnam allocates the space  */
  FILE *fptr = NULL;                  /* Stream pointer for TCF */
  int writ;                           /* To catch errors: # of items written */
  int i;                              /* just a loop counter */
  int CoverLength = TaskSettings->EventControlFile.FTROffset - 383;
                     /* (If no cover, FTROffset equals 383, see DCA/Intel CAS */

  FAXerrno = CASerrorcode = 0;      /* They keep it if nothing goes wrong */

  /* Whether we use all it's fields or not, check the ECS parameter anyway */
  if (!(ECSOkToSubmit(TaskSettings))) {
    FAXerrno = INVALIDECS;            /* But only a warning at this point */
  }

  /* In case of error after changing TaskSettings fields, to restore it */
  memcpy(&SaveECS, TaskSettings, sizeof(ECS));

  /* First, assign whatever Event fields the caller specified */
  if (to) {
    strncpy(TaskSettings->EventControlFile.DestinationName, to, NAMELENGTH);
    if (TaskSettings->EventControlFile.DestinationName[NAMELENGTH-1]) {
      FAXerrno = STRINGTOOLONG;
      TaskSettings->EventControlFile.DestinationName[NAMELENGTH-1] = '\0';
    }
  }
  if (PhoneNumber) {
      strncpy(TaskSettings->EventControlFile.Phone,
              PhoneNumber,
              PHONENUMLENGTH);
      if (TaskSettings->EventControlFile.Phone[PHONENUMLENGTH-1]) {
        FAXerrno = STRINGTOOLONG;
        TaskSettings->EventControlFile.Phone[PHONENUMLENGTH-1] = '\0';
      }
  }
  if (time) {
    if (ValidTime(time)) {
      TaskSettings->EventControlFile.EventTime = ((int)time->Second / 2) |
                                                 ((int)time->Minute << 5) |
                                                 ((int)time->Hour << 11);
    }
    else {
      FAXerrno = BADEVENTTIME;
      goto closeup;
    }
  }
  if (date) {

    /* Check date for validity only if it's non-zero */
    if (date->Day || date->Month || date->Year) {
      if (ValidDate(date)) {
        TaskSettings->EventControlFile.EventDate = (int)date->Day |
                                                   ((int)date->Month << 5) |
                                                   (((int)date->Year - 1980) << 9);
      }
      else {
        FAXerrno = BADEVENTDATE;
        goto closeup;
      }
    }
    else {
      TaskSettings->EventControlFile.EventDate = 0;
    }
  }

  /* Next, if files specified, build and connect up list of FTR structures */
  if (files) {

    /* If the given Event Control structure already has an FTRL list, it will */
    /* be lost, but go ahead and replace it with caller's list */
    if (TaskSettings->FirstFTR) {
      FAXerrno = LOSTFTRS;                /* warning only */
    }

    /* Build a list of File Transfer Records using the caller's file list */
    CurrFile = files;
    for (FileCount = 0;
         CurrFile;                                    /* while more files */
         FileCount++, CurrFile = CurrFile->next) {

      NextFTRL = (FTRLIST *)calloc(sizeof(FTRLIST), 1);
      if (!NextFTRL) {
        FAXerrno = OUTOFMEMORY;

        /* If first time through, prevent freeing the caller's FTRLIST */
        if (!FileCount) {
          memcpy(TaskSettings, &SaveECS, sizeof(ECS));
          return(0);
        }
        else goto closeup;
      }
      if (!FileCount) {                       /* if the first */
        TaskSettings->FirstFTR = NextFTRL;    /* point ECS to it */
      }
      else {
        CurrFTRL->next = NextFTRL;    /* Otherwise connect it to the latest */
      }
      CurrFTRL = NextFTRL;          /* in any case, make latest the current */
      strncpy(CurrFTRL->OneFTR.FileName, CurrFile->FileName, FULLFNAMELENGTH);
      if (CurrFTRL->OneFTR.FileName[FULLFNAMELENGTH-1]) {
        FAXerrno = STRINGTOOLONG;
        CurrFTRL->OneFTR.FileName[FULLFNAMELENGTH-1] = '\0';
      }

      /* IF faxing, set the fax-specific fields from the DefaultsFTRL */
      if (TaskSettings->EventControlFile.TransferType != FILE_TRANSFER) {
        CurrFTRL->OneFTR.FileType = CurrFile->FileType;
        CurrFTRL->OneFTR.TextSize = DefaultsFTRL.OneFTR.TextSize;
        CurrFTRL->OneFTR.AddPageIncrements = DefaultsFTRL.OneFTR.AddPageIncrements;
        CurrFTRL->OneFTR.PageLength = DefaultsFTRL.OneFTR.PageLength;
      }  /* no else: just leaving them all 0's is correct for file transfers */

      CurrFTRL->next = NULL;
    }                                /* end of for (all caller files) loop */
    TaskSettings->EventControlFile.FileCount = FileCount;

  }   /* end of if (files); no else:  FirstFTR already points to an FTRLIST */
      /*  and whether the FileCount field is correct will be checked below */

  /* If only one file, and none of the fields ignored by the SubmitSingleFile
     function are set, use SubmitSingleFile. */
  if (SubmitSingleOk(TaskSettings) &&
      TaskSettings->EventControlFile.FileCount == 1) {

    if (!TaskSettings->FirstFTR) {
      FAXerrno = BADFILECOUNT;
      goto closeup;
    }

    SingleFileSend = (SFTR *)calloc(sizeof(SFTR) + CoverLength, 1);
    if (!SingleFileSend) {
      FAXerrno = OUTOFMEMORY;
      goto closeup;
    }

    /* Set SFTR fields from the TaskSettings */
    SingleFileSend->TransferType = TaskSettings->EventControlFile.TransferType;

    if (SingleFileSend->TransferType != FILE_TRANSFER) {  /* then it's a fax */
      SingleFileSend->TextSize = TaskSettings->FirstFTR->OneFTR.TextSize;
    }

    /* Set the date and time fields */
    SingleFileSend->EventTime = TaskSettings->EventControlFile.EventTime;
    SingleFileSend->EventDate = TaskSettings->EventControlFile.EventDate;
    strncpy(SingleFileSend->DestinationName,
            TaskSettings->EventControlFile.DestinationName,
            NAMELENGTH);
    if (SingleFileSend->DestinationName[NAMELENGTH-1]) {
      FAXerrno = STRINGTOOLONG;
      SingleFileSend->DestinationName[NAMELENGTH-1] = '\0';
    }
    strncpy(SingleFileSend->FileName,
            TaskSettings->FirstFTR->OneFTR.FileName,
            FULLFNAMELENGTH);
    if (SingleFileSend->FileName[FULLFNAMELENGTH-1]) {
      FAXerrno = STRINGTOOLONG;
      SingleFileSend->FileName[FULLFNAMELENGTH-1] = '\0';
    }
    if (TaskSettings->FirstFTR->next) {
      FAXerrno = MOREFTRSTHANFC;
    }
    strncpy(SingleFileSend->Phone,
            TaskSettings->EventControlFile.Phone,
            PHONENUMLENGTH);
    if (SingleFileSend->Phone[PHONENUMLENGTH-1]) {
      FAXerrno = STRINGTOOLONG;
      SingleFileSend->Phone[PHONENUMLENGTH-1] = '\0';
    }
    strncpy(SingleFileSend->ApplicationTag,
            TaskSettings->EventControlFile.ApplicationTag,
            APPTAGLENGTH);
    if (SingleFileSend->ApplicationTag[APPTAGLENGTH-1]) {
      FAXerrno = STRINGTOOLONG;
      SingleFileSend->ApplicationTag[APPTAGLENGTH-1] = '\0';
    }

    /* Finally, copy in the coverpage text.  Enough memory is guaranteed by */
    /*   how the SingleFileSend structure was allocated. */
    SingleFileSend->SendCover = TaskSettings->EventControlFile.SendCover;
    if (CoverLength && TaskSettings->CoverPageText) {
      strncpy(&SingleFileSend->CoverTextDummy,
              TaskSettings->CoverPageText,
              CoverLength);
      if ((&SingleFileSend->CoverTextDummy)[CoverLength-1]) {
        FAXerrno = STRINGTOOLONG;
        (&SingleFileSend->CoverTextDummy)[CoverLength-1] = '\0';
      }
    }

    /* All done setting up, nothing left but to check and ship it! */
    if (SFTROkToSubmit(SingleFileSend)) {
      retval = CASSubmitSingleFile(SingleFileSend);
      if (retval < 0) {
        FAXerrno = SUBMITSINGLE;
      }
      goto closeup;
    }
    else {
      retval = 0;
      goto closeup;
    }
  }
  else {

    /* If any of the fields common with the External Data Block are not       */
    /*    initialized, get the EDB and use it */
    if ((TaskSettings->EventControlFile.SenderName[0] == '\0') ||
        (TaskSettings->EventControlFile.LogoFilePath[0] == '\0')) {
      EDBbuffer = (EDB *)malloc(sizeof(EDB));
      if (!EDBbuffer) {
        FAXerrno = OUTOFMEMORY;
        goto closeup;
      }
      retval = CASGetExternalData(EDBbuffer);
      if (retval) {
        FAXerrno = GETEDB;
        goto closeup;
      }
      else {
        if (TaskSettings->EventControlFile.SenderName[0] == '\0') {
          strncpy(TaskSettings->EventControlFile.SenderName,
                  EDBbuffer->DefaultSender,
                  NAMELENGTH);
          if (TaskSettings->EventControlFile.SenderName[NAMELENGTH-1]) {
            FAXerrno = STRINGTOOLONG;
            TaskSettings->EventControlFile.SenderName[NAMELENGTH-1] = '\0';
          }
        }
        if (TaskSettings->EventControlFile.LogoFilePath[0] == '\0') {
          strncpy(TaskSettings->EventControlFile.LogoFilePath,
                  EDBbuffer->DefaultDir,
                  FULLFNAMELENGTH);   /* this pads out whole field with '\0's */
          if (TaskSettings->EventControlFile.LogoFilePath[DIRPATHLENGTH-1]) {
            FAXerrno = STRINGTOOLONG;
            TaskSettings->EventControlFile.LogoFilePath[DIRPATHLENGTH-1] = '\0';
          }
          strncat(TaskSettings->EventControlFile.LogoFilePath,
                  EDBbuffer->DefaultLogo,
                  FNAMELENGTH);
          if (TaskSettings->EventControlFile.LogoFilePath[FULLFNAMELENGTH-1]) {
            FAXerrno = STRINGTOOLONG;
            TaskSettings->EventControlFile.LogoFilePath[FULLFNAMELENGTH-1] = '\0';
          }
        }
        free(EDBbuffer);
      }
    }

    /* The Event Control Structure is complete: test and ship it! */
    if (ECSOkToSubmit(TaskSettings)) {

      /* Write the Task Control File and submit it*/
      TCFfilename = tmpnam(NULL);

      if((fptr = fopen(TCFfilename, "wb")) == NULL) {
         FAXerrno = CANTOPENFILE;
         goto closeup;
      }

      /* Write the TCF data to disk. */
      writ = fwrite(&TaskSettings->EventControlFile, sizeof(ECF), 1, fptr);
      if (writ < 1) {
        FAXerrno = CANTWRITEFILE;
        goto closeup;
      }

      /* Whether to write cover text depends only on CoverLength, not SendCover*/
      if (CoverLength) {
        writ = fwrite(TaskSettings->CoverPageText, CoverLength, 1, fptr);
        if (writ < 1) {
          FAXerrno = CANTWRITEFILE;
          goto closeup;
        }
      }

      /* Now write the FTR's */
      for (CurrFTRL = TaskSettings->FirstFTR, FileCount = 0;
           FileCount < TaskSettings->EventControlFile.FileCount;
           CurrFTRL = CurrFTRL->next, FileCount++) {

        if (!CurrFTRL) {
          FAXerrno = BADFILECOUNT;
          goto closeup;
        }
        writ = fwrite(&CurrFTRL->OneFTR, sizeof(FTR), 1, fptr);/* all the FTR's */
        if (writ < 1) {
          FAXerrno = CANTWRITEFILE;
          goto closeup;
        }
      }

      if (CurrFTRL) {
        FAXerrno = MOREFTRSTHANFC;            /* warning only */
      }

      if (fclose(fptr)) {
        FAXerrno = CANTCLOSEFILE;
        goto closeup;
      }
      else {
        fptr = NULL;              /* prevents trying to close it again */
      }

      /* Finally, submit! */
      retval = CASSubmitTask(TCFfilename);
      if (retval < 0) {
        FAXerrno = SUBMITTASK;
      }
    }
    else {              /* ECS was not Ok, FAXerrno was set */
      retval = 0;
    }
  }  /* end of else: there were multiple files, so use a TCF */

closeup:
  if (SingleFileSend) {
    free(SingleFileSend);
  }
  if (TaskSettings->FirstFTR != SaveECS.FirstFTR) {
    free_FTRLIST(TaskSettings->FirstFTR);
  }
  if (EDBbuffer) {
    free(EDBbuffer);
  }
  if (fptr) {
    fclose(fptr);
  }
  if (TCFfilename) {
    remove(TCFfilename);
  }
  if (retval <= 0) {
    CASerrorcode = -retval;
    memcpy(TaskSettings, &SaveECS, sizeof(ECS));
    return(0);
  }
  else {
    return(retval);
  }
}
