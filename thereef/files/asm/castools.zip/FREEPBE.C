

/*
   FREEPBE.C  Function PbFreePBE: Frees the conventional memory used by
      a phonebook entry function.

   INPUT:  Phonebook entry structure.  This structure must be in
      conventional memory obtained from using the MSC functions malloc,
      calloc, or realloc.

   OUTPUT: None, except if any of the pointers it should free are NULL, it
            sets Pberrno to a warning.
*/

#include <stdio.h>
#include <malloc.h>
#include <phonebk.h>

void pascal PbFreePBE(PB *pb, PBE *entry)
{
  int i;

  Pberrno = 0;

  if (!entry || !pb) {
    Pberrno = INVALIDPARAMETER;
  }
  else {
    if (entry->type == PERSONENTRY) {
      if (entry->fields) {
        for (i=0; i<pb->header.fields; i++) {
          if (entry->fields[i]) {
            free(entry->fields[i]);
          }
          else {
            Pberrno = NULLPOINTER;
          }
        }
        free(entry->fields);
      }
      else {
        Pberrno = NULLPOINTER;
      }
    }
    if (entry->members) {
      if (entry->MemberList) {
        free(entry->MemberList);
      }
      else {
        Pberrno = NULLPOINTER;
      }
    }
    free(entry);
  }
}
