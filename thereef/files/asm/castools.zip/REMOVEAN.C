

/*
   REMOVEAN.C Function PbRemoverEntry:  Removes an entry (individual or group)
      from an open phonebook.

   INPUT:  Phonebook structure, and the record id of the entry to remove.

   OUTPUT: If successful, removes the entry, and updates the phonebook's
      FreeBytes and entries fields.
*/

#include <stdio.h>
#include <phonebk.h>

int pascal PbRemoveEntry(PB *pb, int RecordID)
{
  int retval = FAIL;        /* Default if anything goes wrong */
  PBE *entry = NULL;
  int i;
  int writ;                 /* for return value from fwrite() */
  int *members;             /* to point to membership list */
  long offset = NULL;       /* for nulling out RecordID */
  int temperrno = 0;        /* for saving aside Pberrno */

  Pberrno = 0;                               /* Initially, always reset */

  /* First, check params */
  if (pb == NULL) {
    Pberrno = INVALIDPARAMETER;
    return(NULL);
  }
  if ((RecordID < 0) ||
      (RecordID > 999)) {
    Pberrno = INVALIDPARAMETER;
    return(NULL);
  }

  /* First, fetch entry record */
  if (!(entry = PbGetEntry(pb, NULL, NULL, RecordID))) {
    Pberrno = OUTOFMEM;
    goto getout;
  }

  /* Check if removing entry will put the 'unused bytes' over the limit */
  if ((entry->length +
       pb->header.FreeBytes +
       entry->members * sizeof(int)) > MAXUNUSEDBYTES) {
    Pberrno = TOOMANYFREEBYTES;
    goto getout;
  }

  /* Remove the group ID from its members, or the member ID from its groups */
  if (entry->members) {
    if (entry->type == GROUPENTRY) {
      for (i=0; i<entry->members; i++) {
        if (!(PbRemoveFromGroup(pb, RecordID, entry->MemberList[i]))) {
          goto getout;            /* Pberrno set by -Remove- function */
        }
      }
    }
    else {
      for (i=0; i<entry->members; i++) {
        if (!(PbRemoveFromGroup(pb, entry->MemberList[i], RecordID))) {
          goto getout;            /* Pberrno set by -Remove- function */
        }
      }
    }

    /* RemoveFromGroup doesn't update the structure we're using, so we have to*/
    entry->length -= entry->members * sizeof(int);
  }

  /* Update phonebook fields, set offset at RecordID to null */
  pb->header.FreeBytes += entry->length;
  if (fseek(pb->fp, 6L,  SEEK_SET)) {
    Pberrno = FSEEKERROR;
    goto getout;
  }
  writ = fwrite(&pb->header.FreeBytes, sizeof(int), 1, pb->fp);
  if (writ != 1) {
    Pberrno = CANTWRITE;
    goto getout;
  }
  pb->header.entries--;
  if (fseek(pb->fp, 4L,  SEEK_SET)) {
    Pberrno = FSEEKERROR;
    goto getout;
  }
  writ = fwrite(&pb->header.entries, sizeof(int), 1, pb->fp);
  if (writ != 1) {
    Pberrno = CANTWRITE;
    goto getout;
  }
  if (fseek(pb->fp, 160L + RecordID * sizeof(LONGWORD), SEEK_SET)) {
    Pberrno = FSEEKERROR;
    goto getout;
  }
  writ = fwrite(&offset, sizeof(LONGWORD), 1, pb->fp);
  if (writ != 1) {
    Pberrno = CANTWRITE;
    goto getout;
  }

  /* And finally, the OBuffer */
  if (pb->OBuffer) {
    if ((RecordID >= pb->FirstOBufferRID) &&
        ((RecordID - pb->FirstOBufferRID) * sizeof(LONGWORD) < pb->OBufferSize)) {
      pb->OBuffer[RecordID - pb->FirstOBufferRID] = offset;
    }
  }

  /* If we got here, all went well */
  retval = SUCCESS;

getout:
  if (Pberrno) {
    temperrno = Pberrno;
  }
  if (entry) {
    PbFreePBE(pb, entry);
  }
  if (temperrno) {
    Pberrno = temperrno;
  }
  return(retval);
}
