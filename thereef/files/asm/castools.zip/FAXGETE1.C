

/*
   FAXGETE1.C  A high-level CAS Toolkit function.

   This function gets the Event Control information for an event.  This
   is all the data about the event except the cover page and the files
   transmitted.

   INPUT:  An event handle, possibly a queue number, and possibly a pointer to
            a structure to return information in.

   OUTPUT: Returns a pointer to an Event Control File structure.
           Also returns the queue that the event was found in.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <cas.h>
#include <fax.h>

ECF * pascal FAXGetEventControlInfo(int EventHandle,
                                    BYTE *queue,
                                    ECF *EventInfo)

{
  int FileHandle,                 /* returned from CASFind functions */
      retval,                     /* for return value of CAS calls */
      red;                        /* bytes read with the read() */
  ECF *ECFp;                      /* Event Control File structure */
  CECS CurrentEventInfo;

  FAXerrno = CASerrorcode = 0;      /* They keep it if nothing goes wrong */

  /* Choose whether to use the callers structure, or allocate our own. */
  if (EventInfo) {
    ECFp = EventInfo;
  }
  else {
    ECFp = malloc(sizeof(ECF));
    if (!ECFp) {
      FAXerrno = OUTOFMEMORY;
      return(NULL);
    }
  }

  /* If the event is currently executing, just get its control info */
  if (EventHandle == CASGetCurrentEventStatus(&CurrentEventInfo)) {
    memcpy(ECFp, &CurrentEventInfo.ControlFile, sizeof(ECF));
    FAXerrno = EVENTISCURRENT;
    *queue = UNKNOWN_QUEUE;
    return(ECFp);
  }

  /* If no queue specified, search all the queues for the given Event Handle */
  if (*queue == UNKNOWN_QUEUE) {
    for (*queue = TASK_QUEUE; *queue <= LOG_QUEUE; (*queue)++) {
      retval = CASFindFirst(ANY_STATUS, SEARCH_FORWARD, *queue);
      while (retval && (retval != EventHandle)) {
        if (retval > 0) {           /* found an event, but not the one sought */
          retval = CASFindNext(*queue);       /* so find next one */
        }
        else break;                           /* end of queue, or other error */
      }
      if (retval == EventHandle) break;        /* else go to next queue */
    }                                          /* Done with all the queues */
    if (retval != EventHandle) {       /* after all that, just give up! */
      *queue = UNKNOWN_QUEUE;
      FAXerrno = EVENTNOTFOUND;
      CASerrorcode = -retval;
      return(NULL);
    }
  }

  /* To get to here, the queue was given, or we found it anyway */
  retval = CASOpenFile(EventHandle, 0, *queue);
  if (retval < 0) {                            /* CAS error, get out */
    FAXerrno = OPENFILE;
    CASerrorcode = -retval;
    return(NULL);
  }
  FileHandle = retval;

  red = read(FileHandle, ECFp, sizeof(ECF));        /* Finally, read it in! */
  if (red != sizeof(ECF)) {
    FAXerrno = CANTREADFILE;
    return(NULL);
  }
  if (close(FileHandle) == -1) {
    FAXerrno = CANTCLOSEFILE;          /* Warning only, we got what we wanted */
  }
  ECFp->RESERVED1 = 0;
  memset(ECFp->RESERVED2, 0, RESERVED2LENGTH);
  return(ECFp);
}
