

/*
   FAXCOPYE.C  A high-level CAS Toolkit function.

   This function allocates an Event Control structure, fills its fields with
   those of the source structure, and returns a pointer to the copy.  All
   the memory used by the copy is separate from that used by the source.

   INPUT:  A complete Event Control Structure as source for copy, and possibly
            one for the copy as well.

   OUTPUT: A pointer to the copy of the source structure.
*/

#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <cas.h>
#include <fax.h>

ECS * pascal FAXCopyECS(ECS *SourceECS, ECS *CopyECS)
{
  ECS *Copy;
  size_t CoverLength = SourceECS->EventControlFile.FTROffset - 383;
  int FileCount;
  FTRLIST *CurrFTRL, *DestFTRL;

  FAXerrno = 0;             /* If it keeps it, all went well. */

  /* If caller provides Copy structure, check that it's all initialized */
  if (CopyECS) {
    if (CoverLength) {
      if (!CopyECS->CoverPageText) {
        FAXerrno = INVALIDPTR;
        return(NULL);
      }
    }
    for (FileCount = 0, CurrFTRL = CopyECS->FirstFTR;
         FileCount < SourceECS->EventControlFile.FileCount;
         FileCount++, CurrFTRL = CurrFTRL->next) {
      if (!CurrFTRL) {
        FAXerrno = INVALIDPTR;
        return(NULL);
      }
    }
    Copy = CopyECS;
  }
  else {
    Copy = (ECS *)calloc(1, sizeof(ECS));
    if (!Copy) {
      FAXerrno = OUTOFMEMORY;
      return(NULL);
    }
  }

  /*  Start with Event Control File fields */
  Copy->EventControlFile.EventType = SourceECS->EventControlFile.EventType;
  Copy->EventControlFile.TransferType = SourceECS->EventControlFile.TransferType;
  Copy->EventControlFile.EventStatus = SourceECS->EventControlFile.EventStatus;
  Copy->EventControlFile.EventTime = SourceECS->EventControlFile.EventTime;
  Copy->EventControlFile.EventDate = SourceECS->EventControlFile.EventDate;
  Copy->EventControlFile.FileCount = SourceECS->EventControlFile.FileCount;
  Copy->EventControlFile.FTROffset = SourceECS->EventControlFile.FTROffset;
  strncpy(Copy->EventControlFile.Phone,
          SourceECS->EventControlFile.Phone,
          PHONENUMLENGTH);
  if (Copy->EventControlFile.Phone[PHONENUMLENGTH-1]) {
    FAXerrno = STRINGTOOLONG;
    Copy->EventControlFile.Phone[PHONENUMLENGTH-1] = '\0';
  }
  strncpy(Copy->EventControlFile.ApplicationTag,
          SourceECS->EventControlFile.ApplicationTag,
          APPTAGLENGTH);
  if (Copy->EventControlFile.ApplicationTag[APPTAGLENGTH-1]) {
    FAXerrno = STRINGTOOLONG;
    Copy->EventControlFile.ApplicationTag[APPTAGLENGTH-1] = '\0';
  }
  Copy->EventControlFile.RESERVED1 = SourceECS->EventControlFile.RESERVED1;
  Copy->EventControlFile.ConnectSeconds = SourceECS->EventControlFile.ConnectSeconds;
  Copy->EventControlFile.ConnectMinutes = SourceECS->EventControlFile.ConnectMinutes;
  Copy->EventControlFile.ConnectHours = SourceECS->EventControlFile.ConnectHours;
  Copy->EventControlFile.TotalPages = SourceECS->EventControlFile.TotalPages;
  Copy->EventControlFile.PagesSent = SourceECS->EventControlFile.PagesSent;
  Copy->EventControlFile.FilesSent = SourceECS->EventControlFile.FilesSent;
  Copy->EventControlFile.SendCover = SourceECS->EventControlFile.SendCover;
  Copy->EventControlFile.ErrorCount = SourceECS->EventControlFile.ErrorCount;
  memcpy(Copy->EventControlFile.RESERVED2,
         SourceECS->EventControlFile.RESERVED2,
         78);
  strncpy(Copy->EventControlFile.RemoteCSID,
          SourceECS->EventControlFile.RemoteCSID,
          CSIDLENGTH);
  if (Copy->EventControlFile.RemoteCSID[CSIDLENGTH-1]) {
    FAXerrno = STRINGTOOLONG;
    Copy->EventControlFile.RemoteCSID[CSIDLENGTH-1] = '\0';
  }
  strncpy(Copy->EventControlFile.DestinationName,
          SourceECS->EventControlFile.DestinationName,
          NAMELENGTH);
  if (Copy->EventControlFile.DestinationName[NAMELENGTH-1]) {
    FAXerrno = STRINGTOOLONG;
    Copy->EventControlFile.DestinationName[NAMELENGTH-1] = '\0';
  }
  strncpy(Copy->EventControlFile.SenderName,
          SourceECS->EventControlFile.SenderName,
          NAMELENGTH);
  if (Copy->EventControlFile.SenderName[NAMELENGTH-1]) {
    FAXerrno = STRINGTOOLONG;
    Copy->EventControlFile.SenderName[NAMELENGTH-1] = '\0';
  }
  strncpy(Copy->EventControlFile.LogoFilePath,
          SourceECS->EventControlFile.LogoFilePath,
          FULLFNAMELENGTH);
  if (Copy->EventControlFile.LogoFilePath[FULLFNAMELENGTH-1]) {
    FAXerrno = STRINGTOOLONG;
    Copy->EventControlFile.LogoFilePath[FULLFNAMELENGTH-1] = '\0';
  }

  /*  Now the coverpage text */
  if (CoverLength) {
    if (!CopyECS) {                                       /* we're allocating */
      Copy->CoverPageText = (char *)calloc(CoverLength, sizeof(char));
      if (!Copy->CoverPageText) {
        FAXerrno = OUTOFMEMORY;
        if (!CopyECS) {
          freeup(Copy);
        }
        return(NULL);
      }
    }
    strncpy(Copy->CoverPageText, SourceECS->CoverPageText, CoverLength);
    if (SourceECS->CoverPageText[CoverLength-1]) {
      FAXerrno = STRINGTOOLONG;
      Copy->CoverPageText[CoverLength-1] = '\0';
    }
  }
  else Copy->CoverPageText = NULL;

  /* Then the File Transfer Records list */
  if (SourceECS->FirstFTR) {     /* There is at least one file */
    if (!CopyECS) {
      Copy->FirstFTR = (FTRLIST *)calloc(1, sizeof(FTRLIST));
      if (!Copy->FirstFTR) {
        FAXerrno = OUTOFMEMORY;
        if (!CopyECS) {
          freeup(Copy);
        }
        return(NULL);
      }
    }
    CurrFTRL = SourceECS->FirstFTR;
    DestFTRL = Copy->FirstFTR;
    for (FileCount = 0;
         FileCount < SourceECS->EventControlFile.FileCount;
         FileCount++, CurrFTRL = CurrFTRL->next) {

      if (!CurrFTRL) {             /* Before FileCount says we're done, we */
        FAXerrno = BADFILECOUNT;   /*    are out of pointers to new FTRs */
        if (!CopyECS) {
          freeup(Copy);
        }
        return(NULL);
      }

      /* Except for first time through, advance dest FTRL, malloc'ing if nec. */
      if (FileCount) {
        if (!CopyECS) {
          DestFTRL->next = (FTRLIST *)calloc(1, sizeof(FTRLIST));
          if (!DestFTRL->next) {
            FAXerrno = OUTOFMEMORY;
            freeup(Copy);
            return(NULL);
          }
        }
        DestFTRL = DestFTRL->next;
      }
      DestFTRL->OneFTR.FileType          =  CurrFTRL->OneFTR.FileType;
      DestFTRL->OneFTR.TextSize          =  CurrFTRL->OneFTR.TextSize;
      DestFTRL->OneFTR.FileStatus        =  CurrFTRL->OneFTR.FileStatus;
      DestFTRL->OneFTR.BytesSent         =  CurrFTRL->OneFTR.BytesSent;
      DestFTRL->OneFTR.FileSize          =  CurrFTRL->OneFTR.FileSize;
      DestFTRL->OneFTR.PagesSent         =  CurrFTRL->OneFTR.PagesSent;
      DestFTRL->OneFTR.PageCount         =  CurrFTRL->OneFTR.PageCount;
      strncpy(DestFTRL->OneFTR.FileName,
              CurrFTRL->OneFTR.FileName,
              FULLFNAMELENGTH);
      if (DestFTRL->OneFTR.FileName[FULLFNAMELENGTH-1]) {
        FAXerrno = STRINGTOOLONG;
        DestFTRL->OneFTR.FileName[FULLFNAMELENGTH-1] = '\0';
      }
      DestFTRL->OneFTR.AddPageIncrements =  CurrFTRL->OneFTR.AddPageIncrements;
      DestFTRL->OneFTR.PageLength        =  CurrFTRL->OneFTR.PageLength;
      memcpy(DestFTRL->OneFTR.RESERVED,     CurrFTRL->OneFTR.RESERVED, 31);
      if (!CopyECS) {
        DestFTRL->next = NULL;
      }
    }                   /* done reading FileCount FTR's */

    /* If, after FileCount FTR's, there are still more in source, warning */
    if (CurrFTRL) {
      FAXerrno = MOREFTRSTHANFC;
    }
  }
  else {
    if (SourceECS->EventControlFile.FileCount) {
      FAXerrno = BADFILECOUNT;
      if (!CopyECS) {
        freeup(Copy);
      }
      return(NULL);
    }
  }

  /* Just to be exact, if the source points to another, let the dest also */
  return(Copy);
}
