

/*
   LOOKUP.C  Function PbLookUpSendInfo:  Fetches the phone number, comm
      hardware type, and possible the name of a phone book entry.

   INPUT:  Phonebook structure and either the name or the record ID of an
      entry to look up.

   OUTPUT: If successful, the phone number, hw type, and name of entry.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <phonebk.h>

int pascal PbLookUpSendInfo(PB *pb,
                            char *name,
                            int *recordID,
                            char *PhoneNumber,
                            BYTE *CommHardware)
{
  PBEFIXED fixed_part, *retval;
  int rid;

  Pberrno = 0;            /* Initially, always reset */

  /* First, check params */
  if ((pb == NULL) ||
      (name == NULL) ||
      (recordID == NULL) ||
      (PhoneNumber == NULL) ||
      (CommHardware == NULL)) {
    Pberrno = INVALIDPARAMETER;
    return(FAIL);
  }
  if ((*recordID < -1) ||
      (*recordID > 999)) {
    Pberrno = INVALIDPARAMETER;
    return(FAIL);
  }

  /* If the record id is given, find the record at offset at that record id */
  if (*recordID != -1) {
    retval = GetFixedPart(pb, &fixed_part, *recordID);
    if (!retval) {
      if (!Pberrno) {
        Pberrno = NOENTRYPRESENT;          /* No offset at that record id */
      }
      return(FAIL);
    }
    strncpy(name, fixed_part.name, NAMELENGTH);
    strncpy(PhoneNumber, fixed_part.PhoneNumber, PHONENUMLENGTH);
    *CommHardware = fixed_part.HardwareType;
    *recordID = fixed_part.id;
    return(SUCCESS);
  }

  /* Otherwise, use the string as a search key through all rid's, until found */
  else {
    for (rid=0; rid<1000; rid++) {
      retval = GetFixedPart(pb, &fixed_part, rid);
      if (!retval) {
        if (Pberrno) { /* Not just that no entry there, but an error occurred */
          return(FAIL);
        }
      }
      else {               /* an entry was fetched; check its name */
        if (!(strnicmp(name,
                       fixed_part.name,
                       NAMELENGTH))) {         /* if a case-insensitive match */

          strncpy(name, fixed_part.name, NAMELENGTH);   /* just in cAsE (sic) */
          strncpy(PhoneNumber, fixed_part.PhoneNumber, PHONENUMLENGTH);
          *CommHardware = fixed_part.HardwareType;
          *recordID = fixed_part.id;
          return(SUCCESS);
        }
      }
    }
    /* If we've gotten here, no matching entries were found */
    Pberrno = NOENTRYFOUND;
    return(FAIL);
  }
}
