

/*
   BUFFEROF.C  Function PbBufferOffsets:  prepares a phonebook for buffering
      access to its offset array.

   INPUT:  Phonebook structure, size of buffer, and optionally space for the
      buffer.

   OUTPUT: If successful, a phonebook structure with buffer fields initialized.
*/

#include <stdlib.h>
#include <malloc.h>
#include <stdio.h>
#include <phonebk.h>

PB * pascal PbBufferOffsets(PB *pb, LONGWORD *OBuffer, WORD OBufferSize)
{
  PB *retval = NULL;            /* default error return */
  int red;                      /* for return value of fread() */

  Pberrno = 0;            /* Initially, always reset */

  /* First, check params */
  if ((pb == NULL) ||
      (OBufferSize < 4) ||
      (OBufferSize > 4000)) {
    Pberrno = INVALIDPARAMETER;
    return(NULL);
  }

  /* Round down OBufferSize, if it isn't a multiple of the buffered item size */
  if (OBufferSize % sizeof(LONGWORD)) {
    OBufferSize -= OBufferSize % sizeof(LONGWORD);
  }

  if (!OBuffer) {
    pb->OBuffer = (LONGWORD *)malloc(OBufferSize);
    if (!pb->OBuffer) {
      Pberrno = OUTOFMEM;
      return(NULL);
    }
  }
  else {
    pb->OBuffer = OBuffer;
  }

  if (fseek(pb->fp, 160L, SEEK_SET)) {
    Pberrno =  FSEEKERROR;
    goto closeup;
  }
  red = fread(pb->OBuffer,
              sizeof(LONGWORD),
              OBufferSize/sizeof(LONGWORD),
              pb->fp);
  if (red != OBufferSize/sizeof(LONGWORD)) {
    Pberrno = CANTREAD;
    goto closeup;
  }
  pb->OBufferSize = OBufferSize;
  pb->FirstOBufferRID = 0;
  return(pb);
closeup:
  if (!OBuffer) {
    free(pb->OBuffer);
  }
  return(retval);
}
