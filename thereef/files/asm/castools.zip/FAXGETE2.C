

/*
   FAXGETE2.C  A high-level CAS Toolkit function.

   This function gets the Cover page text of an event.

   INPUT:  An event handle and possibly a queue number, and possibly a buffer
            to return the cover page text into.

   OUTPUT: A pointer to the cover page text.
*/

#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <cas.h>
#include <fax.h>

char * pascal FAXGetEventCover(int EventHandle,
                               BYTE *queue,
                               char *CoverPtr)
{
  int FileHandle,                 /* returned from CASFind functions */
      retval,                     /* for return value of CAS calls */
      red,                        /* bytes read with the read() */
      CoverSize;
  ECF ControlInfo;                /* need FTROffset to determine coversize */
  char *buffer;                   /* to hold the cover page text */
  CECS CurrentEventInfo;

  FAXerrno = CASerrorcode = 0;      /* They keep it if nothing goes wrong */

  /* If the event is currently executing, can't get its cover page text */
  if (EventHandle == CASGetCurrentEventStatus(&CurrentEventInfo)) {
    FAXerrno = EVENTISCURRENT;
    return(NULL);
  }

  /* If no queue specified, search all the queues for the given Event Handle */
  if (*queue == UNKNOWN_QUEUE) {
    for (*queue = TASK_QUEUE; *queue <= LOG_QUEUE; (*queue)++) {
      retval = CASFindFirst(ANY_STATUS, SEARCH_FORWARD, *queue);
      while (retval && (retval != EventHandle)) {
        if (retval > 0) {           /* found an event, but not the one sought */
          retval = CASFindNext(*queue);    /* so find next one */
        }
        else break;                 /* end of queue, or other error */
      }
      if (retval == EventHandle) break;           /* else go to next queue */
    }                                             /* Done with all the queues */
    if (retval != EventHandle) {       /* after all that, just give up! */
      *queue = UNKNOWN_QUEUE;
      FAXerrno = EVENTNOTFOUND;
      CASerrorcode = -retval;
      return(NULL);
    }
  }

  /* To get to here, the queue was given, or we found it anyway */
  retval = CASOpenFile(EventHandle, 0, *queue);
  if (retval < 0) {                            /* CAS error, get out */
    FAXerrno = OPENFILE;
    CASerrorcode = -retval;
    return(NULL);
  }
  FileHandle = retval;

  red = read(FileHandle, &ControlInfo, sizeof(ECF));
  if (red != sizeof(ECF)) {
    FAXerrno = CANTREADFILE;
    return(NULL);
  }

  /* If the event is a received FAX, the cover text has already been
      integrated into the first fax page; this function can't retrieve it */
  if ((ControlInfo.EventType == RECEIVE) &&
      (ControlInfo.TransferType != FILE_TRANSFER)) {
    FAXerrno = RECEIVEDFAXNOCOVER;
    return(NULL);
  }

  /* Otherwise, find out the cover size, and fetch it */
  CoverSize = ControlInfo.FTROffset - 383;

  /* Fetch only if cover IS there (if size 1, it's only the terminating NULL) */
  if (!(CoverSize > 1)) {
    FAXerrno = NOCOVERTEXT;
    return(NULL);
  }

  if (CoverPtr) {                    /* It had better be big enough */
    buffer = CoverPtr;
  }
  else {
    buffer = (char *)malloc(CoverSize);
    if (!buffer) {
      FAXerrno = OUTOFMEMORY;
      return(NULL);
    }
  }
  red = read(FileHandle, buffer, CoverSize);
  if (red != CoverSize) {
    FAXerrno = CANTREADFILE;
    return(NULL);
  }
  if (close(FileHandle) == -1) {
    FAXerrno = CANTCLOSEFILE;          /* Warning only, we got what we wanted */
  }
  return(buffer);
}
