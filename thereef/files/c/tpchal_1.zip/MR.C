#include <stdio.h>

int main (void)
{
      long Number;
      int Digit, Used, Bit, Position;
#ifdef TEST
      int I;

      for (I = 0; I < 1000; ++I)
      {
#endif
            Number = 0L;
            Digit = Used = 0;
            Bit = Position = 1;
            while (1)
            {
                  while (Digit++ < 9)
                  {
                        if ((Used & (Bit <<= 1)) == 0)
                              break;
                  }
                  if (Digit > 9)
                  {
                        Used &= ~(Bit = 1
                              << (Digit = (int) ((Number /= 10) % 10)));
                        Number -= Digit;
                        Position--;
                        continue;
                  }
                  if (((Number += Digit) % Position) != 0)
                  {
                        Number -= Digit;
                        continue;
                  }
                  if (++Position > 9)
                        break;
                  Number *= 10;
                  Used |= Bit;
                  Digit = 0;
                  Bit = 1;
            }
#ifdef TEST
      }
#endif
      printf ("\nNumber = %li\n", Number);
      return 0;
}
