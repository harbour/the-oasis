/*
**  Rhys Wong (1:203/52, Rhys.Wong@24stex.com)
*/

#include <stdio.h>

void printnum(int *d)
{
    int i;

    printf("Number found:  ");
    for (i = 1; i <= 9; i++)
        putchar(d[i]+'0');
    putchar('\n');
}

main(void)
{
    int d[10], match, i, sum;
#ifdef TEST
    int I;

    for (I = 0; I < 1000; ++I)
    {
#endif

    d[5] = 5;       /* The fifth digit has to be 5 */

    d[1] = 1;
    do
    {
        if(d[1] == d[5])  continue;
        d[2] = 2;
        do
        {
            if(d[2]==d[5] || d[2]==d[1])  continue;
            d[3] = 3 - (d[1]+d[2]) % 3;
            do
            {
                if(d[3]==d[5] || d[3]==d[1] || d[3]==d[2])  continue;
                d[4] = 4 - d[3] % 2 * 2;
                do
                {
                    if(d[4]==d[5] || d[4]==d[1] || d[4]==d[2] || d[4]==d[3])
                        continue;
                    d[6] = 3 - (d[1]+d[2]+d[3]+d[4]+d[5]) % 3;
                    do
                    {
                        if(d[6] % 2)  continue;
                        for (i = 1, match = 0; i < 6 && !match; i++)
                        {
                            if (d[6] == d[i])
                                match = 1;
                        }
                        if (match)
                            continue;
                        d[7] = 7- (((d[5]-d[2])*10+d[6]-d[3])*10+d[1]-d[4]) %7;

                        do
                        {
                            for (i = 1, match = 0; i < 7 && !match; i++)
                            {
                                if (d[7] == d[i])
                                    match = 1;
                            }
                            if (match)
                                continue;
                            d[8] = 8 - (d[6]*10+d[7]) % 4 * 2;
                            do
                            {
                                for (i=1, match=sum=0; i < 8 && !match; i++)
                                {
                                    if(d[8] == d[i])
                                        match = 1;
                                    else
                                        sum += d[i];
                                }
                                if (match)
                                    continue;
                                d[9] = 9 - (sum+d[8]) % 9;
                                {
                                    for (i=1, match=0; i < 9 && !match; i++)
                                    {
                                        if(d[9] == d[i])
                                            match = 1;
                                    }
                                    if(match)
                                        continue;
#ifdef TEST
                                    if (999 == I)    /* a number is found */
#endif
                                        printnum(d);
                                }
                            } while((d[8]+=8) <= 9);
                        } while((d[7]+=7) <= 9);
                    } while((d[6]+=3) <= 9);
                } while((d[4]+=4) <= 9);
            } while((d[3]+=3) <= 9);
        } while((d[2]+=2) <= 9);
    } while(++d[1] <= 9);
#ifdef TEST
    }
#endif
    return 0;
}
