#include <stdio.h>

main()
{
      unsigned posn, avail;
      unsigned long n;
      unsigned long pow10[] = {
            1L, 10L, 100L, 1000L, 10000L, 100000L,
            1000000L, 10000000L, 100000000L};
      unsigned long fill[] = {
            123456789L, 12354678L, 1253467L, 152346L,
            51234L, 1234L, 123L, 12L, 1L, 0L};
      int I;

#ifdef TEST
      for (I = 0; I < 200; ++I)
      {
#endif
            for (n = 123456789L, posn = 1, avail = 0xfffe; posn < 10; ++posn)
            {
                  unsigned long div = pow10[9 - posn];
                  unsigned long sub = n / div;
                  unsigned dig = (unsigned)(sub % 10);

                  if (1 != posn)
                  {
                        unsigned long res = sub % posn;

                        if ((0L != res) || (0L == dig) ||
                              ((dig & 1) != (posn & 1)) ||
                              (!(avail & (1 << dig))))
                        {
                              n += (posn - res) * div;
                              n -= n % div;
                              n += fill[posn];
                              dig = (unsigned)((n / 10000) % 10);
                              if (5 != dig)
                              {
                                    n += ((dig > 5 ? 10 : 5) -
                                          (dig % 5)) * 10000L;
                              }
                              posn = 0;
                              avail = 0xfffe;
                              continue;
                        }
                  }
                  avail &= ~(1 << dig);
            }
#ifdef TEST
      }
#endif
      printf("Number = %lu\n", n);
      return 0;
} 
