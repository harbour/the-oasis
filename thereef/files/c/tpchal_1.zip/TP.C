/*
**  Tony Postmayer (1:267/113.26)
*/

#include <stdio.h>
#include <stdlib.h>

unsigned int  odd[][4] = {
      {1,3,7,9},  {1,3,9,7},  {1,7,9,3},  {1,7,3,9},
      {1,9,3,7},  {1,9,7,3},  {3,7,9,1},  {3,7,1,9},
      {3,9,1,7},  {3,9,7,1},  {3,1,7,9},  {3,1,9,7},
      {7,9,1,3},  {7,9,3,1},  {7,1,3,9},  {7,1,9,3},
      {7,3,9,1},  {7,3,1,9},  {9,1,3,7},  {9,1,7,3},
      {9,3,7,1},  {9,3,1,7},  {9,7,1,3},  {9,7,3,1}
};

unsigned int even[][4] = {
      {2,6,8,4},  {2,6,4,8},  {4,6,8,2},  {4,6,2,8},
      {4,2,6,8},  {4,2,8,6},  {6,2,4,8},  {6,2,8,4},
      {8,2,4,6},  {8,2,6,4},  {8,6,2,4},  {8,6,4,2}
};

int main(void)
{
      unsigned int i, j;
      unsigned long a, b, c, d, e, f, g, h, n;
#ifdef TEST
      int I;

      for (I = 0; I < 1000; ++I)
      {
#endif
            for(i=0; i<24; i++)
            {
                  for(j=0; j<12; j++)
                  {
                        a = odd[i][0];
                        b = 10 * a + even[j][0];
                        c = 10 * b + odd[i][1];
                        if (c%3)
                              continue;
                        d = 10 * c + even[j][1];
                        e = 10 * d + 5;
                        f = 10 * e + even[j][2];
                        if (f%6)
                              continue;
                        g = 10 * f + odd[i][2];
                        if (g%7)
                              continue;
                        h = 10 * g + even[j][3];
                        if (h%8)
                              continue;
                        n = 10 * h + odd[i][3];
                  }
            }
#ifdef TEST
      }
#endif
      printf("%lu\n",n);
      return(0);
}
