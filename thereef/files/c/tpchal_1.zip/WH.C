/*
**  Wayne Halsdorf (1:141/1135)
*/

#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>

char    numb[10];
char    ods[] = "13579";
char    evs[] = "2468";
long    retval;

void    genodd(int pos);
void    geneven(int pos);

void    geneven(int pos)
{
      int     e, npos;
      long    v;
      char    sav;

      npos = pos + 1;
      for(e = 0; e < 4; e++)
      {
            if(evs[e] != '*')
            {
                  sav = numb[pos] = evs[e];
                  switch(npos)
                  {
                  case 4:
                  case 6:
                  case 8:
                        numb[npos] = '\0';
                        v = atol(numb);
                        if(v % (npos) != 0)
                              break;
                  default:
                        evs[e] = '*';
                        genodd(npos);
                        evs[e] = sav;
                        break;
                  }
            }
      }
}

void    genodd(int pos)
{
      long    v;
      int     o, npos;
      char    sav;

      npos = pos + 1;
      for(o = 0; o < 5; o++)
      {
            if(ods[o] != '*')
            {
                  sav = numb[pos] = ods[o];
                  numb[npos] = '\0';
                  v = atol(numb);
                  switch(npos)
                  {
                  case 3:
                  case 5:
                  case 7:
                        if(v % (npos) != 0)
                              break;
                  case 1:
                        ods[o] = '*';
                        geneven(npos);
                        ods[o] = sav;
                        break;
                  case 9:
                        retval = v;
                        break;
                  }
            }
      }
}


main(void)
{
#ifdef TEST
      int i;

      for (i = 0; i < 1000; ++i)
      {
            strcpy(ods, "13579");
            strcpy(evs, "2468");
#endif
            genodd(0);
#ifdef TEST
      }
#endif
      printf("%li\n", retval);
      return 0;
}
