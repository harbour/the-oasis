/*
**  Bill Greganti (1:218/905)
*/

#include <stdio.h>
#include <stdlib.h>

int  check (long);

main (void)
{
      long number;

      for (number = 123456789L; number < 987654321L;)
      {
            if      ((number / 10000000L) % 2 != 0)
                  number +=  10000000L;
            else if ((number /  1000000L) % 3 != 0)
                  number +=   1000000L;
            else if ((number /   100000L) % 4 != 0)
                  number +=    100000L;
            else if ((number /    10000L) % 5 != 0)
                  number +=     10000L;
            else if ((number /     1000L) % 6 != 0)
                  number +=      1000L;
            else if ((number /      100L) % 7 != 0)
                  number +=       100L;
            else if ((number /       10L) % 8 != 0)
                  number +=        10L;
            else if ((number            ) % 9 != 0)
                  number ++           ;
            else if (check (number) == 0)
            {
                  printf ("%lu\n", number++);
                  break;
            }
            else  number++;
      }
      return 0;
}

int check (long number)
{
      int x;
      char string[10];

      ltoa (number, string, 10);
      for (x = 0; x < 9; x++)
      {
            int y;
            for (y = 8; y > 0 + x; y--)
            {
                  if ((string[x] == string[y]) ||
                        (string[x] == '0') || (string[y] == '0'))
                  {
                        return(1);
                  }
            }
      }
      return(0);
}
