/*
**  Dave Dunfield (1:163/107.4)
*/

#include <stdio.h>

main()
{
    int i;
    long savenum;
    static int n = 0;
    static char digits[10] = { 0 };
    static long num = 0;

    ++n;
    if(n >= 10)                             /* This number qualifies */
        printf("%ld\n", num);
    else for(i=1; i < 10; ++i) {            /* Test digits 1-9 only */
        if(digits[i])                       /* Digit in use */
            continue;
        savenum = num;                      /* Save our place */
        if(!((num = num*10 + i) % n)) {     /* Divides - proceed */
            digits[i] = -1;                 /* Mark digit as used */
            main();                         /* Try sub-combinations */
            digits[i] = 0; }                /* Release digit */
        num = savenum; }                    /* Restore place */
    --n;
}
