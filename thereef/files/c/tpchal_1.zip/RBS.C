#include <stdio.h>
#include <stdlib.h>
#include <string.h>

main()
{
      unsigned posn, avail;
      char *fill[] = {
            "123456789", "12354678", "1253467", "152346",
            "51234", "1234", "123", "12", "1", ""};
      char number[11]
#ifndef TEST
      = "0123456789";
#else
      ;
      int I;

      for (I = 0; I < 1000; ++I)
      {
            strcpy(number, " 123456789");
#endif
            for (posn = 1, avail = 0xffff; posn < 10; ++posn)
            {
                  unsigned dig = number[posn] - '0';
                  unsigned long n;

                  if (1 != posn)
                  {
                        int i, res;

                        n = 10 * n + dig;
                        res = (int)(n % posn);

                        if ((0 != res) || (0 == dig) ||
                              (!(avail & (1 << dig))) ||
                              ((dig & 1) != (posn & 1)))
                        {
                              n += posn - res;
                              for (i = posn; i; n /= 10, --i)
                              {
                                    if (number[i] == (dig = n % 10 + '0'))
                                          break;
                                    number[i] = dig;
                              }
                              strcpy(number + posn + 1, fill[posn]);
                              posn = 0;
                              avail = 0xffff;
                              continue; 
                        }
                  }
                  else  n  = dig;
                  avail &= ~(1 << dig);
            }
#ifdef TEST
      }
#endif
      printf("Number = %ld\n", atol(number));
      return 0;
} 
