/*
**  Shamim Islam
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <time.h>

int success=1;
int Level;

int repeat(register int * prev,int level)
{
      register int i;

      for(i=0;i<level;i++)
            if(prev[level]==prev[i])
                  return 1;
      return 0;
}

int findLevel(register int * prev,register int incr)
{
      if(!success)
      {
            prev[Level]=0;
            Level--;
      }
      do
      {
            prev[Level]+=incr;
      }while(repeat(prev,Level));
      if(prev[Level]>=10)
      {
            prev[Level]=0;
            Level--;
      }
      else if(Level!=8)
            Level++;
      if(Level==-1)
            return -1;
      success=1;
      return Level;
}

void main(void)
{
      static int previous[9];
      static unsigned long n[9];
      static unsigned long p[9] = {
            100000000Lu,
            10000000Lu,
            1000000Lu,
            100000Lu,
            10000Lu,
            1000Lu,
            100Lu,
            10Lu,
            1Lu};
      int level=0;
      int nextlevel=0;
      int done=0;

#ifdef TEST
      int I;

      for (I = 0; I < 1000; ++I)
      {
#endif
      Level = 0;
      memset(previous, 0, sizeof(previous));
      memset(n, 0, sizeof(n));
      while(!done)
      {
            switch(level)
            {
            case 0:
                  if((nextlevel=findLevel(previous,1))==-1)
                  {
                        done=1;
                        continue;
                  }
                  // record it
                  n[0]=previous[0]*p[0];
                  level=nextlevel;

            default:
                  // To be divisible by two, it must be end in a multiple of 
                  // two
                  nextlevel=findLevel(previous,(level+1)%2==0?2:1);
                  if(nextlevel>=level)
                  {
                        // Check the number so far
                        if(((n[level]=n[level-1]+previous[level]*p[level])
                              /p[level])%(level+1)!=0)
                        {
                              success=0;
                              continue;
                        }
                        if(level!=nextlevel)
                        {
                              level=nextlevel;
                              continue;
                        }
                  }
                  else
                  {
                        level=nextlevel;
                        continue;
                  }
            }
            break;
      }
#ifdef TEST
      }
#endif
      printf("Number = %ld\n",n[level]);
}
