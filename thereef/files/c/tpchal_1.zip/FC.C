/*
**  Fraser Campbell (1:252/202)
*/

#include <stdio.h>

int a, b, c, d, f, g, h, i;
long number;

main()
{
	printf ("\nCalculating value(s) ...\n");
	for (a = 1; a <= 9; a++)
		for (b = 2; b <= 8; b+=2)   /* b, d, f, h must be even */
			for (c = 1; c <= 9; c++)
				for (d = 2; d <= 8; d+=2)
					/*
					** The 5th number which we might have called e
					** must be 5 so why declare it?
					*/
					for (f = 2; f <= 8; f+=2)
						for (g = 1; g <= 9; g++)
							for (h = 2; h <= 8; h+=2)
								for (i = 1; i <= 9; i++)
	{
		if (a != b && a != c && a != d && a != 5 && a != f &&
			a != g && a != h && a != i && b != c && b != d &&
			b != 5 && b != f && b != g && b != h && b != i &&
			c != d && c != 5 && c != f && c != g && c != h &&
			c != i && d != 5 && d != f && d != g && d != h &&
                  d != i && f != 5 && f != g && f != h && f != i &&
                  g != 5 && g != h && g != i && h != 5 && h != i  )
		{
			number = a * 100000000 + b * 10000000 + c * 1000000 +
				d * 100000 + 50000 + f * 1000 + g * 100 +
				h * 10 + i;
			if (   number % 9 == 0 &&
				((number - number % 10)/10) % 8 == 0 &&
				((number - number % 100)/100) % 7 == 0 &&
				((number - number % 1000)/1000) % 6 == 0 &&
				/*
				** No need to check for divisibility by 5 here
				*/
				((number - number % 100000)/100000) % 4 == 0 &&
				((number - number % 1000000)/1000000) % 3 == 0 &&
				((number - number % 10000000)/10000000) % 2 == 0 )
					printf ("%ld\n\n", number);
		}
	}
}   
