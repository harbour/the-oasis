/*
**  Auke Reitsma (2:281/527)
**
**  Instructions:
**
**    1. Solve problem using pencil (or pen) and paper
**    2. Insert solution in macro definition as shown below
**    3. For timing tests, define TEST macro at compile time
*/

#include <stdio.h>

#define ANSWER 381654729L

main(void)
{
#ifdef TEST
      int I;

      for (I = 0; I < 1000; ++I)
            ;
#endif
      printf("Number = %ld\n", ANSWER);
      return 0;
}
