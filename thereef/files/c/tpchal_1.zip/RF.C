/*
**  Robin Forster (1:163/107)
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>

char answer[10];
char initnumber[10]={' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '\0' };
int  used[9];

int test(char *number, int n)
{
      /* We don't need to save it.  We're always once step behind */

      number[n]='\0';
      return !(atol(number)%n);
}

int findindex(char *number, int index)
{
      char p[10];
      char digit, init = '2';

      strcpy(p,number);

      if (index & 1)                      /* if odd start at odd digit */
            init = '1';

      /* for each odd/even digit */

      for (digit = init; digit <= '9'; digit += 2)
      {
            if (!used[digit - '1'])
            {
                  p[index - 1]=digit;
                  if (test(p, index))
                  {
                        if (index != 9)
                        {
                              used[digit - '1'] = 1;
                              if (findindex(p, index + 1))  /* recurse */
                                    return 1;
                              else  used[digit - '1']=0;
                        }
                        else
                        {
                              strcpy(answer, p);            /* found it */
                              return 1;
                        }
                  }
            }
      }
      return 0;

}

int main()
{
      int i;
      unsigned long ticks;
      unsigned long far *timer;

      timer = MK_FP(0x40,0x6C);

      ticks = *timer;
      for (i = 0; i < 1000; i++)
      {
            memset(used, 0, sizeof(used));
            if(!findindex(initnumber, 1))
                  puts("No such number!\n");
      }
      printf("Answer %s\n\nTime %lu\n", answer, *timer - ticks);
      return 0;
}
