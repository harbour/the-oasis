
#ifdef COMMENT_OUT

Organization: Columbia University Department of Computer Science
Message-ID: <TIM.91Aug15142410@tompkins.cs.columbia.edu>
Newsgroups: alt.sources

Here's a short program which takes a phone number (of any length) as a command
line argument and prints words which match that number according to
digit/letter relations on the keypad.  For example, "number2word 2337" would
return "beep" and "beer".

Note that the digits 0 and 1 on the keypad don't have any letters, so no
words will match phone numbers containing them.  The program could be made
smarter by dealing with this in some way, splitting numbers into multiple
words, checking for digits like 2 and 4 which sound the same as words, or
applying other heuristics, but hey, I only have so much free time :).

Enjoy.

#endif

/*
 * number2word.c -- a quick hack to find words that match a phone number
 *
 * Timothy Jones (tim@cs.columbia.edu), June 1991
 */

#include <stdio.h>
#include <string.h>

#define WordList "/usr/dict/words"

main (argc, argv)
    int argc;
    char **argv;
{
    char number[100], line[81];
    FILE *fp;
    int i, length;

    /* check the arguments */
    if (argc != 2)
    {
        (void) fprintf (stderr, "Usage: %s <phone number>\n", argv[0]);
        exit (1);
    }

    /* remember some important things */
    (void) strcpy (number, argv[1]);
    length = strlen (number);

    /* open the words file */
    if ((fp = fopen (WordList, "r")) == NULL)
    {
        (void) fprintf (stderr, "Couldn't open %s!\n", WordList);
        exit (1);
    }

    /* read in the words, one at a time, and check for matches */
    while (fgets (line, sizeof (line), fp))
    {
        /* only look at words with the correct length */
        if ((i = strlen (line)) == length+1)
        {
            /* get rid of the trailing newline */
            line[i-1] = 0;

            /* check each character of the word */
            for (i = 0; i < length; i++)
            {
                switch (number[i] - '0')
                {
                    /*
                     * since the numbers '0' and '1' don't have any
                     * associated letters, we ignore them
                     */
                case 2:
                    if (line[i] != 'a' && line[i] != 'b' && line[i] != 'c')
                        goto next;
                    break;
                case 3:
                    if (line[i] != 'd' && line[i] != 'e' && line[i] != 'f')
                        goto next;
                        break;
                case 4:
                    if (line[i] != 'g' && line[i] != 'h' && line[i] != 'i')
                        goto next;
                    break;
                case 5:
                    if (line[i] != 'j' && line[i] != 'k' && line[i] != 'l')
                        goto next;
                    break;
                case 6:
                    if (line[i] != 'm' && line[i] != 'n' && line[i] != 'o')
                        goto next;
                    break;
                case 7:
                    if (line[i] != 'p' && line[i] != 'r' && line[i] != 's')
                        goto next;
                    break;
                case 8:
                    if (line[i] != 't' && line[i] != 'u' && line[i] != 'v')
                        goto next;
                    break;
                case 9:
                    if (line[i] != 'w' && line[i] != 'x' && line[i] != 'y')
                        goto next;
                    break;
                }
            }

            if (i == length)
            {
                (void) printf ("%s\n", line);
            }
        }
    next:
        ;
    }

    exit (0);
}

#ifdef COMMENT_OUT
--
                                        - Tim Jones
                                          tim@cs.columbia.edu

#endif
