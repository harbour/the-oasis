/* pcxarray.c
   by Bill Buckels 1990

   converts a CGA COMPATIBLE .PCX screen dump into a
   C-LANGUAGE CHARACTER ARRAY HEADER OF THE SAME NAME
   but having the extension ".c"

   the graphic is embedded and either compiled seperately
   as an object file and declared external & linked to
   or alternately is used as a header.

   the graphic is then unpacked directly into a screen buffer,
   or alternately into the frame buffer without disk i/o.

*/
#include <stdio.h>
#include <fcntl.h>
#include <io.h>
#include <string.h>



unsigned int byteword(unsigned char a, unsigned char b){return b<<8|a;}
unsigned char pcxheader[128];

int checkforpcx(char *name)
{
    FILE *fp; /* reads a ZSOFT .PCX header but ignores the color map */
    int i;    /* we only want CGA compatible full screens.           */

    unsigned int zsoft,version,codetype,pixbits;
    unsigned int xmin, ymin, xmax, ymax;
    unsigned int hres, vres;
    unsigned int no_planes, bytesperline;
    int invalid = -1, valid = 0, status=valid;

    /* read the file header */
    if((fp=fopen(name,"rb"))==NULL)return -1;
    for(i=0;i!=128;i++)pcxheader[i]=fgetc(fp);
    fclose(fp);

    zsoft   =pcxheader[0];
    version =pcxheader[1];
    codetype=pcxheader[2];
    pixbits =pcxheader[3];

    if(zsoft!=10)        status = invalid;
    if(codetype!=1)      status = invalid;
    if(pixbits != 2 )
       if(pixbits != 1)  status = invalid;

    xmin=byteword(pcxheader[4],pcxheader[5]);
    ymin=byteword(pcxheader[6],pcxheader[7]);
    xmax=byteword(pcxheader[8],pcxheader[9]);
    ymax=byteword(pcxheader[10],pcxheader[11]);
    hres=byteword(pcxheader[12],pcxheader[13]);
    vres=byteword(pcxheader[14],pcxheader[15]);
    no_planes   =pcxheader[65];
    bytesperline=byteword(pcxheader[66],pcxheader[67]);
    if(xmin != 0  )      status = invalid;
    if(ymin != 0  )      status = invalid;
    if(xmax != 319)
       if(xmax!=639)     status = invalid;
    if(ymax != 199)      status = invalid;
    if(hres != 320)
       if(hres!=640)     status = invalid;
    if(vres != 200)      status = invalid;
    if(no_planes!=1)     status = invalid;
    if(bytesperline !=80)status = invalid;
    /* we can ignore the color map since we        */
    /* are limiting ourselves to CGA modes         */
    /* so we will not handle over 2-bits per pixel */
    return status;

}



char separators[]=" .\n";

int PCXARRAY(char *pcxfilename)
{
    unsigned int packet=16,width=0;
    FILE *fp,*fp2;
    long wordcount,target;
    char buffer[128];
    char  name[128];
    char  name2[128];
    char *wordptr;


    strcpy(buffer,pcxfilename);
    wordptr=strtok(buffer,separators);
    strcpy(name,buffer);
    strcat(name,".PCX");
    strcpy(name2,buffer);
    strcat(name2,".c");

    if(checkforpcx(name)==-1)return-1;
    fp = fopen(name,"rb");
    fp2 = fopen(name2,"w");

    printf("\nInput File : %s",name);
    printf("\nOutput File: %s\n",name2);

    fprintf(fp2,
 "/* Character Array of .PCX format Run Length Full Screen CGA Graphic */\n");
    fprintf(fp2,
 "/* .PCX Input File Name was %s */\n\n",name);
    fprintf(fp2,
 "/* The BYTE COUNT Descriptor Integer precedes the Character Array.*/\n\n");

    target = filelength(fileno(fp));
    for(wordcount=0;wordcount<128;wordcount++)fgetc(fp);

    fprintf(fp2,"int %s",buffer);
    fprintf(fp2,"_SIZE = %ld ;\n\n",(target-128l));
    fprintf(fp2,"unsigned char far %s[%ld]={\n",buffer,(target-128l));

    do{
        fprintf(fp2,"%3d",fgetc(fp));
        wordcount++;
        if(wordcount !=target)fprintf(fp2,", ");
        else fprintf(fp2,"};");
        if(width++==packet){fprintf(fp2,"\n");
                            width=0;}
                            }while(wordcount!=target);
        fclose(fp);
        fclose(fp2);
        return(0);
}

char *usage[]={
"PCXARRAY(C) Copyright by Bill Buckels 1990\n",
"is not a valid CGA Full Screen .PCX file.\n",
"Usage is \"PCXARRAY [PCXFILENAME]\"\n",
"Done!\n"};


main(int argc,char *argv[])
{
    printf("%s",usage[0]);
    switch (argc)
        {
         case 2:  if(PCXARRAY(argv[1])==0)break;
                  printf("%s %s",argv[1],usage[1]);
         default: printf("%s",usage[2]);
                  exit(0);
        }
    printf("%s",usage[3]);
    exit(0);
}
