/* Garfield.C was produced by Bill Buckels Oct 1990      */
/* graphics arrays were produced by using PCXARRAY.EXE   */
/* a graphics demo using embedded .PCX files in the code */
/* compiled in Mix Power C 2.0 using the Large Model     */

extern int ODIE1_SIZE;
extern unsigned char far ODIE1[];
extern int ODIE2_SIZE;
extern unsigned char far ODIE2[];
extern int ODIE3_SIZE;
extern unsigned char far ODIE3[];


#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <dos.h>
#include <bios.h>
#include <io.h>
#include <malloc.h>
#include <conio.h>

#define BLUE      1
#define INTENSE   16
#define GRY       0
#define CMW       1

#define BLKBLK '\x00'

#define CRETURN '\x0d'
#define LFEED   '\x0A'
#define ESCAPE  '\x1b'

#define SCREENSIZE 16385
#define TEXT     3
#define CGA_320  4
#define HI_RES   6
#define HERCULES 99

int screen_mode= CGA_320;
int ADAPTER = CGA_320  ;

int background = BLUE+INTENSE;
int palette =    GRY;

unsigned char far *crt    =(unsigned char *) 0xB8000000l;
unsigned char far *inleaf =(unsigned char *)0xB8000000l+0x2000;

unsigned char far *screenbuffer0;
unsigned char far *screenbuffer1;
unsigned char far *screenbuffer2;

    /* =================[ CGA to HERCULES conversion ]===============*/

    /* Comparison Ratio:          pixels    size                     */
    /* the hercules display is    720 =  90 bytes wide               */
    /*                            348 =  87 "half-bytes" deep        */
    /* the cga HI_RES display is  640 =  80 bytes wide               */
    /*                            200 =  50 "half-bytes" deep        */
    /* horizontal transformation reduction 8:9 =                     */
    /*                            640 =  80 bytes literal            */
    /* vertical transformation ratio       3:2 =                     */
    /*                            300 =  50 "half-bytes" deep        */
    /* A slightly (11%) smaller but reasonably accurate facsimile    */
    /* of bit images ported from the cga may be displayed on the herc*/
    /* by applying the horizontal resolution transformation factor   */
    /* vertically then writing an extra scanline on every odd line   */
    /* relative to CGA coordinates. This is done as a "filler" and   */
    /* will widen horizontal lines in lineart reproductions if they  */
    /* fall on the (interleaf) filler line. Also, the aspect ratio   */
    /* is minimally (4%) reduced in the yaxis.                       */

    /* there are 2-significant advantages to this algorithm.         */
    /* 1. speed of execution due to integer arithmetic and the use   */
    /*    of the modulus operator and simple logic.                  */
    /* 2. greater image clarity due to maintaining true pixel ratio  */
    /*    in the x axis and a single-interleaf repeat in the y axis  */
    /*    thereby preserving a regular transformation matrix ratio.  */

    /*===============================================================*/


#define   HERCTEXT  0
#define   HERCGRAPH 1
int       HERCLEAF[4]={0x0000,0x2000,0x4000,0x6000};
#define   HERCLINE   90
#define   CGALINE    80
#define   SCREENSIZE 16385

/* we declare the screen buffer globally and allocate the memory      */
/* during initialization. We have room for several buffers.           */

void HERC_CLS(void)
{
  memset(crt,0,32767);

}

/* 6485 controller mode data */
char HERC_DAT[2][12] = { { 0x61, 0x50, 0x52, 0x0f, 0x19, 0x06,
                         0x19, 0x19, 0x02, 0x0d, 0x0b, 0x0c  },
                       { 0x35, 0x2d, 0x2e, 0x07, 0x5b, 0x02,
                         0x57, 0x57, 0x02, 0x03, 0x00 ,0x00  } };
void HERC_MODE(int ctrlmode)
{
   unsigned int reg,ctrl;
   ctrl = (ctrlmode) ? 0x82 : 0x20;
   outp(0x3bf,3)                  ;  /* allow graphics enable page 1 */
   outp(0x3b8,ctrl)               ;  /* disable video and set mode   */
   for (reg = 0; reg <= 11; reg++) { /* program the crt parameters   */
        outp(0x3b4,reg)           ;
        outp(0x3b5,HERC_DAT[ctrlmode][reg]);
        }
   outp(0x3b8,ctrl+8)             ;  /* re-enable the video          */
}

int setcrtmode(unsigned char _CRT_MODE)
{
    union REGS rin,rout;

    if ((biosequip() & 0x30) == 0x30){
        ADAPTER=HERCULES                ;
        if(_CRT_MODE == TEXT){
                HERC_CLS()              ;
                HERC_MODE(HERCTEXT)     ;
                }
           else{HERC_MODE(HERCGRAPH)    ;
                HERC_CLS()              ;
                }
            return (0)                  ;
            }

    rin.h.ah = 0;
    rin.h.al = _CRT_MODE;
    int86(0x10,&rin,&rout);
    return 0;

}

int colorset(background, palette)
unsigned char background, palette;
{
    union REGS rin,rout;
    
    if(ADAPTER==HERCULES) return 0;
    rin.h.ah = 11;
    rin.h.bh = 0;
    rin.h.bl = background;
    int86(0x10,&rin,&rout);
    rin.h.bh = 1;
    rin.h.bl = palette;
    int86(0x10,&rin,&rout);
    return 0;
}



int memoryload(unsigned char far *in, unsigned char far *out, int sz)
{
    unsigned int byteoff=0,packet,width=0;
    unsigned char byte,bytecount;
    long wordcount=0,target;


    target = 1l*sz;

    do{ bytecount=1;                          /* start with a seed count */
        byte=in[wordcount];
        wordcount++;
                                              /* check to see if its raw */
        if(0xC0 == (0xC0 &byte)){             /* if its not, run encoded */
                    bytecount= 0x3f &byte;
                    byte=in[wordcount];
                    wordcount++;
                    }
        for(packet=0;packet<bytecount;packet++){
                     out[byteoff]=byte;
                     byteoff++;
                     }
        }while(wordcount<target);
        return(0);
}

int cload(unsigned char far *array,int bottomborder)
{
 unsigned int y,inset=((HERCLINE*6)+5),offset=0;
 int status;


 if(ADAPTER==HERCULES){
    bottomborder=((bottomborder*3)/2);
    for(y=0;y!=(299-bottomborder);y++){
        memcpy(crt+HERCLEAF[y%4]+inset,array+offset,CGALINE);
        if(y%4==3)inset+=HERCLINE;
        if(y%3!=2)offset+=CGALINE;
        }
    return(0);
    }

    inset = offset;

    for(y=0;y<(200-bottomborder);){
        memcpy(crt+inset,array+offset,CGALINE);
        offset+=CGALINE;
        y++;
        memcpy(inleaf+inset,array+offset,CGALINE);
        offset+=CGALINE;
        inset+=CGALINE;
        y++;
        }
     return(0);

}



int SOUNDTRACK[]={

/* musical array created from file WHISTLER.SND */
/* array structure is frequency,duration */
  784,  3,32767,  0,  831,  0,32767,  0,  880,  0,32767,  0,
  932,  0,32767,  0,  988,  0,32767,  0, 1047,  0,32767,  0,
 1109,  0,32767,  0, 1175,  0,32767,  0, 1245,  0,32767,  0,
 1319,  0,32767,  0, 1397,  0,32767,  0, 1480,  0,32767,  0,
 1568,  3,32767,  0,32767,  3, 1319,  3,32767,  0, 1047,  3,
32767,  0,  988,  3,32767,  0,  880,  3,32767,  0,  988,  3,
32767,  0,32767,  3,  880,  3,32767,  0,  784,  3,32767,  0,
32767,  3,  831,  3,32767,  0,  880,  3,32767,  0,32767,  3,
  659,  3,32767,  0,  622,  3,32767,  0,32767,  3,  659,  3,
32767,  0,  784, 12,32767,  0,  659,  3,32767,  0,  587,  3,
32767,  0,  523,  3,32767,  0,32767,  3,  587,  3,32767,  0,
  659,  3,32767,  0,  784,  3,32767,  0,  880,  3,32767,  0,
 1047,  3,32767,  0,32767,  3,  880,  3,32767,  0,  784,  3,
32767,  0,32767,  3,  880,  3,32767,  0,  988,  3,32767,  0,
 1175,  3,32767,  0,  988,  3,32767,  0,  880,  3,32767,  0,
32767,  3,  988,  3,32767,  0, 1175,  9,32767,  0,  784,  6,
32767,  0,  831,  0,32767,  0,  880,  0,32767,  0,  932,  0,
32767,  0,  988,  0,32767,  0, 1047,  0,32767,  0, 1109,  0,
32767,  0, 1175,  0,32767,  0, 1245,  0,32767,  0, 1319,  0,
32767,  0, 1397,  0,32767,  0, 1480,  0,32767,  0, 1568,  3,
32767,  0,32767,  3, 1319,  3,32767,  0, 1047,  3,32767,  0,
  988,  3,32767,  0,  880,  3,32767,  0,  988,  3,32767,  0,
32767,  3,  880,  3,32767,  0,  784,  3,32767,  0,32767,  3,
  831,  3,32767,  0,  880,  3,32767,  0,32767,  3, 1319,  3,
32767,  0, 1397,  3,32767,  0,32767,  3, 1319,  3,32767,  0,
  880, 15,32767,  0,  880,  1,32767,  0,  988,  1,32767,  0,
 1047,  6,32767,  0,  880,  1,32767,  0,  988,  1,32767,  0,
 1047,  6,32767,  0,  880,  1,32767,  0,  988,  1,32767,  0,
 1047,  3,32767,  0, 1175,  3,32767,  0, 1245,  3,32767,  0,
 1319,  3,32767,  0, 1568,  3,32767,  0, 1319,  3,32767,  0,
 1175, 18,32767,  0, 1047, 12,32767,  12,


/* musical array created from file SYNCLOCK.SND */
/* array structure is frequency,duration */
  196,  6,32767,  0,  262,  3,32767,  3,  294,  3,32767,  3,
  330,  3,32767,  3,  262,  3,32767,  3,  294,  3,32767,  3,
  330,  1,32767,  1,  349, 12,32767,  0,  262,  1,32767,  1,
  247,  3,32767,  3,  262,  3,32767,  3,  294,  3,32767,  3,
  247,  3,32767,  3,  262,  3,32767,  0,  247,  3,32767,  0,
  262,  3,32767,  0,  294,  3,32767,  0,  330,  9,32767,  0,
  196,  1,32767,  1,  262,  3,32767,  3,  294,  3,32767,  3,
  330,  3,32767,  3,  262,  3,32767,  3,  294,  3,32767,  3,
  330,  1,32767,  1,  349, 12,32767,  0,  330,  1,32767,  1,
  294,  6,32767,  0,  330,  6,32767,  0,  392,  6,32767,  0,
  349,  3,32767,  0,32767,  6,  330,  3,32767,  3,  294,  1,
32767,  1,  262,  3,32767,  3,  262,  6,32767,  0,  440,  6,
32767,  0,  494,  6,32767,  0,  523,  6,32767,  0,  440,  6,
32767,  0,  494,  6,32767,  0,  523,  3,32767,  0,  494, 12,
32767,  0,  466,  3,32767,  0,  440,  6,32767,  0,  494,  3,
32767,  0,  440,  6,32767,  0,  392,  3,32767,  0,  349,  6,
32767,  0,  392, 18,32767,  0,  330,  6,32767,  0,  294,  6,
32767,  0,  330,  6,32767,  0,  349,  6,32767,  0,  330,  6,
32767,  0,  311,  6,32767,  0,  330,  3,32767,  0,  262, 12,
32767,  0,  294,  3,32767,  0,  311,  3,32767,  0,  330,  3,
32767,  0,  440,  3,32767,  0,  311,  6,32767,  0,  262,  3,
32767,  0,  220,  6,32767,  0,  294, 18,32767,  0,  196,  6,
32767,  0,  262,  3,32767,  3,  294,  3,32767,  3,  330,  3,
32767,  3,  262,  3,32767,  3,  294,  3,32767,  3,  330,  1,
32767,  1,  349, 12,32767,  0,  262,  1,32767,  1,  247,  3,
32767,  3,  262,  3,32767,  3,  294,  3,32767,  3,  247,  3,
32767,  3,  262,  3,32767,  0,  247,  3,32767,  0,  262,  3,
32767,  0,  294,  3,32767,  0,  330,  9,32767,  0,  196,  1,
32767,  1,  262,  3,32767,  3,  294,  3,32767,  3,  330,  3,
32767,  3,  262,  3,32767,  3,  294,  3,32767,  3,  330,  1,
32767,  1,  349, 12,32767,  0,  330,  1,32767,  1,  294,  6,
32767,  0,  330,  6,32767,  0,  392,  6,32767,  0,  349,  3,
32767,  0,32767,  6,  330,  3,32767,  3,  294,  1,32767,  1,
  262,  3,32767,  12,-1,-1};


int soundcounter=0;

/* play continuous */

int play()
{
    int freq,duration;
    unsigned int status=0;

    while(!(status)){
             if(SOUNDTRACK[soundcounter]==-1)soundcounter = 0;
             freq = SOUNDTRACK[soundcounter];

            /* if we got a keypress see what it is */
            if(kbhit())
            {
            status=getch();
            switch(status)
            {
                case 27: return 27;
                default: return 0;
            }
            }
            soundcounter++;
            duration=SOUNDTRACK[soundcounter];
            sound(freq,duration);
            soundcounter++;
            }

}




int scriptloader(int bookcounter,int pagecounter,int bottomborder)
{

 if(bookcounter==0){
    switch(pagecounter)
    {
        case 1:
                cload(screenbuffer0,bottomborder);
                break;

        case 2: cload(screenbuffer1,bottomborder);
                break;

        case 3:
                cload(screenbuffer2,bottomborder);
                break;

    }
    }
    return 0;
}

void trapdoor()
{                               setcrtmode(TEXT);
                               _ffree(screenbuffer0);
                               _ffree(screenbuffer1);
                               _ffree(screenbuffer2);
            printf("\nProduced by Bill Buckels\n");
                               exit(0);
}


main()
{
       int done=0;
       int counter = 1;

       printf("Press Escape to End.\n");
       printf("Press Any Other Key To Advance Pictures.\n");
       printf("Please Wait... Unpacking Slideshow...\n");
       screenbuffer0=_fmalloc(SCREENSIZE);
       screenbuffer1=_fmalloc(SCREENSIZE);
       screenbuffer2=_fmalloc(SCREENSIZE);

       memoryload(ODIE1,screenbuffer0,ODIE1_SIZE);
       memoryload(ODIE2,screenbuffer1,ODIE2_SIZE);
       memoryload(ODIE3,screenbuffer2,ODIE3_SIZE);

       setcrtmode(CGA_320);

     while(!(done))
        {
       if(counter==4)counter=1;
       scriptloader(0,counter,0);
       counter++;
             if(play()==27)trapdoor();
             }


}




