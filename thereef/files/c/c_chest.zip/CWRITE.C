/* CWRITE.C
   by Bill Buckels 1989
   revised October 1990

   Written in MIX Power C

   This Utility Converts Blocks of C Code to
   fprintf statements to be included in c language
   program generators written in c.

   Trigraph seqences are not supported.

   Output File f2 is assumed and high bits are
   stripped from input file.
   (Directly Accepts Wordstar Documents.)

   A Control Structure is also provided as
   an outline for development.

   All String Literals are reformatted with
   the appropriate delimiters.

   optionally accepts file names as command line args.

*/

#include <stdio.h>
#include <io.h>

#define QUOTE   '\x22'
#define SLASH   '\x5c'
#define CTRLZ   '\x1a'
#define CRETURN '\x0d'
#define LFEED   '\x0A'
#define ENN     '\x6e'
#define PRIME   '\x25'
#define DELETE  '\x7f'

void getfiles(name1,name2)
char *name1,name2;
{
int row;

    /* User Input Function.
       File Names were not entered on the Command Line. */
     printf("        Source -> ");
     gets(name1);
     row  = cursrow();
     printf("        Target -> ");
     while (strcmp(gets(name2),name1) == NULL){
           poscurs(row,0);
           printf("ReEnter Target ->                ");
           poscurs(row,18);
           }
     poscurs((row-1),0);
     printf("                                 \n");
     printf("                                 ");
     poscurs((row-1),0);



}



void write_tokenized_CODE(name1,name2)
char *name1, name2;
{

char c;
int row;
long linecount=0;
unsigned long int count=0;
unsigned long int target;

FILE *f1, *f2;


if ( (f1 = fopen(name1, "r") ) == NULL)
        {

            printf("Sorry... %s not found.\n",strupr(name1));
            printf("Invalid Source.");
            exit(0);
        }

 target = (filelength(fileno(f1))); /* size in bytes of input file */

 f2 = fopen(name2,"w");

      printf("Converting...\n");
      printf("      ->  ");
      printf("%s",strupr(name1));
fprintf(f2,"/*\n");
fprintf(f2,"   Program Name %s\n",name2);
fprintf(f2,"   Source File  %s\n",name1);
fprintf(f2,"\n");
fprintf(f2,"   This Template Was Created  Using The C Write(C) Utility.\n");
fprintf(f2,"   Written in MIX Power C by Bill Buckels July,1989\n");
fprintf(f2,"\n");
fprintf(f2,"   The Control Structure Provided With This Converted File\n");
fprintf(f2,"   May Be Used To Create A C Program \
Generator From A C Source File\n");
fprintf(f2,"   With A Minimum of Editing.\n");
fprintf(f2,"\n");
fprintf(f2,"   This Template accepts file names as command line args.\n");
fprintf(f2,"\n");
fprintf(f2,"   Send Correspondence to:\n");
fprintf(f2,"                            Bill Buckels, Starving Programmer\n");
fprintf(f2,"                            982 Hector Avenue\n");
fprintf(f2,"                            Winnipeg, Manitoba, \
Canada R3M 2G6\n");
fprintf(f2,"   Phone (204) 452-2815\n");
fprintf(f2,"\n");
fprintf(f2,"*/\n");
fprintf(f2,"\n");
fprintf(f2,"#include <stdio.h>\n");
fprintf(f2,"\n");
fprintf(f2,"void getfiles(name1,name2)\n");
fprintf(f2,"char *name1,name2;\n");
fprintf(f2,"{\n");
fprintf(f2,"int row;\n");
fprintf(f2,"\n");
fprintf(f2,"    /* User Input Function.\n");
fprintf(f2,"       File Names were not entered on the Command Line. */\n");
fprintf(f2,"     printf(\"        Source -> \");\n");
fprintf(f2,"     gets(name1);\n");
fprintf(f2,"     row  = cursrow();\n");
fprintf(f2,"     printf(\"        Target -> \");\n");
fprintf(f2,"     while (strcmp(gets(name2),name1) == NULL){\n");
fprintf(f2,"           poscurs(row,0);\n");
fprintf(f2,"           printf(\"ReEnter Target ->                \");\n");
fprintf(f2,"           poscurs(row,18);\n");
fprintf(f2,"           }\n");
fprintf(f2,"     poscurs((row-1),0);\n");
fprintf(f2,"     printf(\"                                 \\n\");\n");
fprintf(f2,"     printf(\"                                 \");\n");
fprintf(f2,"     poscurs((row-1),0);\n");
fprintf(f2,"\n");
fprintf(f2,"}\n");
fprintf(f2,"\n");
fprintf(f2,"\n");
fprintf(f2,"\n");
fprintf(f2,"void Read_and_Write(name1,name2)\n");
fprintf(f2,"char *name1, name2;\n");
fprintf(f2,"{\n");
fprintf(f2,"\n");
fprintf(f2,"char c;\n");
fprintf(f2,"unsigned long int count = 0;\n");
fprintf(f2,"unsigned long int target;\n");
fprintf(f2,"\n");
fprintf(f2,"FILE *f1, *f2;\n");
fprintf(f2,"\n");
fprintf(f2,"\n");
fprintf(f2,"if ( (f1 = fopen(name1, \"r\") ) == NULL)\n");
fprintf(f2,"        {\n");
fprintf(f2,"\n");
fprintf(f2,"            printf(\"Sorry... %%s not found.\\n\",name1);\n");
fprintf(f2,"            printf(\"Invalid Source.\");\n");
fprintf(f2,"            exit(0);\n");
fprintf(f2,"        }\n");
fprintf(f2,"\n");
fprintf(f2," target = (filelength(fileno(f1))); \
/* size in bytes of input file */\n");
fprintf(f2,"\n");
fprintf(f2," f2 = fopen(name2,\"w\");\n");
fprintf(f2,"\n");

      row = cursrow();
      fprintf(f2,"fprintf(f2,");
      fputc(QUOTE,f2);

      do{  /* get a character and strip off the high bit */
           c = fgetc(f1)&0x7f;
           if (c=='\n'){/* start a new line */
                        linecount++;
                        poscurs(row,0);
                        printf("%5ld",linecount);
                        fputc(SLASH,f2);
                        fputc(ENN,f2);
                        fputc(QUOTE,f2);
                        fprintf(f2,");");
                        fprintf(f2,"\nfprintf(f2,");
                        fputc(QUOTE,f2);
                        }

           else { /* formatted output */
                  switch(c)
                            {
                            case QUOTE :  {
                                           fprintf(f2,"%c%c",SLASH,QUOTE);
                                           break;
                                        }
                            case SLASH :  {
                                           fprintf(f2,"%c%c",SLASH,SLASH);
                                           break;
                                        }
                            case PRIME :  {
                                           fprintf(f2,"%c%c",PRIME,PRIME);
                                           break;
                                          }
                            case CRETURN :{
                                           break;
                                          }
                            case LFEED   : {
                                            break;
                                            }

                             case CTRLZ  : {
                                           break;
                                           }

                             case DELETE :  {
                                            break;
                                          }
                             default     :  {
                                          fputc(c,f2);
                                          }
                                    }
                              }
                } while (count++ != target);
                        fputc(SLASH,f2);
                        fputc(ENN,f2);
                        fputc(QUOTE,f2);
                        fprintf(f2,");");
                        fprintf(f2,"\n");
          poscurs(row,0);
          printf("%5ld Lines Converted.        \n",linecount);
fprintf(f2,"\n");
fprintf(f2,"\n");
fprintf(f2,"      do{\n");
fprintf(f2,"          /* get a character  from f1 and put it into f2 */\n");
fprintf(f2,"           c = fgetc(f1);\n");
fprintf(f2,"           fputc(c,f2);\n");
fprintf(f2,"\n");
fprintf(f2,"          /* are we done yet */\n");
fprintf(f2,"           count++;\n");
fprintf(f2,"                } while (count != target );\n");
fprintf(f2,"\n");
fprintf(f2,"          printf(\"Done !\\n\");\n");
fprintf(f2,"          printf(\"%%s created\\n\",name2);\n");
fprintf(f2,"          fclose(f2);    fclose(f1);\n");
fprintf(f2,"}\n");
fprintf(f2,"\n");
fprintf(f2,"\n");
fprintf(f2,"\n");
fprintf(f2,"main(int argc, char *argv[])\n");
fprintf(f2,"{\n");
fprintf(f2,"    char file1[66], file2[66];\n");
fprintf(f2,"    char *sname,*tname;\n");
fprintf(f2,"\n");
fprintf(f2,"\n");
fprintf(f2,"    switch (argc)\n");
fprintf(f2,"        {\n");
fprintf(f2,"\n");
fprintf(f2,"          case 3: sname=argv[1]; \
tname=argv[2];      /* 2 args */\n");
fprintf(f2,"                  Read_and_Write(sname,tname);\n");
fprintf(f2,"                  break;\n");
fprintf(f2,"\n");
fprintf(f2,"          default: getfiles(file1,file2);\n");
fprintf(f2,"                   Read_and_Write(file1,file2);\n");
fprintf(f2,"        }\n");
fprintf(f2,"    exit(0);\n");
fprintf(f2,"}\n");
          printf("%s created\n",strupr(name2));
          printf("      Thanks For Using C Write.");
          fclose(f2);    fclose(f1);
}



main(int argc, char *argv[])
{
    char file1[66], file2[66];

    printf("C Write - Version 2.0.0\n");
    printf("(C) Copyright 1989, 1990 by Bill Buckels\n");

    /* dedicated to speeding up the tedious stuff */

    switch (argc)
        {

          case 3: /* 2 args */
                  write_tokenized_CODE(argv[1],argv[2]);
                  break;

          default: getfiles(file1,file2);
                   write_tokenized_CODE(file1,file2);
        }
    exit(0);
}


