/* GBAS.c

   A memory resident frame grabber program for the CGA and compatible
   written in MIX POWER C by Bill Buckels 1989

   ( linked explicitly with a 2K stack and 1K heap to over-ride
     interrupt default of 1K stack, but reduced memory required
     so that (hopefully) no interference that we can avoid. )

   This program saves the CGA frame buffer to a "slide file"
   in the GWBASIC BSAVED IMAGE FORMAT.

   Graphics and 80 column text mode are both supported and the
   default is graphics mode. The Argument "80" for CGA text mode
   will initialize image grabs in 4K buffer blocks rather than
   the 16K required by a graphics dump.

   The Comments that follow are concerned with graphics mode only,
   but the practical principles apply to text mode use of the utility.

   If the apparent usefulness of such a utility momentarily escapes
   you, consider that most paint programs support only proprietary
   formats that usually try to be all things to all people and are
   as efficient as heck.

   And what's even worse is that due to the various
   bitpacking schemes and other stuff that is pretty much beyond the
   scope of what I want to say here, the average programmer writing
   in GWBASIC is effectively CUT-OFF from exporting his Paint Brush
   Creations into his BASIC programs, because the CODE that is required
   is usually beyond mortal understanding.

   This is very unfair, especially to younger programmers who would
   probably enjoy dressing-up their programs with original graphics.

   Since most Paint Programs have their own frame grabber programs,
   ( FRIEZE.COM is PCPAINT's and CATCH.COM is PSPLUS's to name afew),
   it is quite easy to capture and create a disk file of almost any
   screen from a GRAPHICS program. But as I said, it is not so easy
   to put these screens to any useful purpose once embellished in
   the respective paint program because as previously indicated,
   the image files are quite formal and abit tricky to deal with.

   The BASIC BSAVED image format is easy to display in a GWBASIC
   program (Using the BLOAD command and the example in the manual.)

   This Utility is My "little bit" towards providing a simple and
   common source of EDITTED GRAPHICS for the Casual Programmer.

   At the risk of "byteing-off" more than I can chew, I sincerely
   hope that this utility works with your computer. I have tested
   it on an AMDEK 286 10mghz AT running MSDOS 4.01 with a true
   CGA card and additionally with a SAMSUNG s550 equipped with an
   ATI Wonder, to name a couple, and successfully Grabbed screens
   in ZSOFT's PCPAINT version 3 and Logitech's PSPLUS.

   This Program uses The Print Screen Key as a "CAMERA SHUTTER" and
   the ".BAS"  extension for it's creations and prints to a file
   starting with the name "IMAGE000.BAS" and a 100 image limit.

   POSTFIX:

   Some other programs that also generate the BSAVED IMAGE are
   TheGrin, PCPG, and of course GWBASIC.

   There are other antiquated CAMERA programs that work on the XT
   and grab into a format which allow conversion to BSAVED IMAGES
   such as IBM's OLD PCSTORYBOARD or Fernando Pertuz's PRESENT,
   but I haven't had any luck with them on the AT.

   Due To an extremely conscise explanation from
   ZSOFT regarding the .PCX file format, I have completed a utility
   called BASTOPCX which allows direct conversion between the BASIC
   BSAVED CGA GRAPHICS MODE IMAGE FORMAT and EQUIVALENT PCX FORMATS.

   If its not on this disk, send me a blank with a stamped envelope
   and I'll mail you back a copy.(or drop by if you're in the area.)

   Regards-   Bill Buckels
              982 Hector Ave.
              Winnipeg, Manitoba, Canada R3M 2G6

*/

#include <bios.h>
#include <stdio.h>
#include <dos.h>

int one_count = 0;
int two_count = 0;

/* microsoft compatible bsaved image format descriptors */
char MEDRES_header[7]={
    '\xfd','\x00','\xb8','\x00','\x00','\x00','\x40'};

char TEXT_header[7]={
    '\xfd','\x00','\xb8','\x00','\x00','\xA0','\x0F'};


void interrupt GRAPHPRINT(void)
{

    /* avoids higher level string handling
       functions in an effort to keep the overhead down */

    FILE *fp;
    static char far *crtptr;
    int i;
    char *filename="IMAGE000.BAS";

    disable();
    if(one_count==10){one_count=0;
                       two_count++;
                       if(two_count==10)two_count=0;}

    filename[7]=one_count+48;
    filename[6]=two_count+48;
    one_count++;

    fp=fopen(filename,"wb");

    for(i=0;i<7;i++)fputc(MEDRES_header[i],fp);
    crtptr = MK_FP(0xB800,0);
    for(i=0;i<16385;i++)fputc(crtptr[i],fp);
    fclose(fp);
    enable();
}


void interrupt TEXTPRINT(void)
{


    FILE *fp;
    static char far *crtptr;
    int i;
    char *filename="IMAGE000.BAS";

    disable();
    if(one_count==10){one_count==0;
                       two_count++;
                       if(two_count==10)two_count==0;}

    filename[7]=one_count+48;
    filename[6]=two_count+48;
    one_count++;

    fp=fopen(filename,"wb");

    for(i=0;i<7;i++)fputc(TEXT_header[i],fp);
    crtptr = MK_FP(0xB800,0);
    for(i=0;i<4097;i++)fputc(crtptr[i],fp);
    fclose(fp);
    enable();
}


main(char argc,int *argv[])
{
    unsigned programsize;

    if(argc==2 && atoi(argv[1])==80)
                                    setvect(5,TEXTPRINT);
    else
                                    setvect(5,GRAPHPRINT);
    programsize=farsetsize(0);
    printf("GBAS.exe CGA screen GRABBER utility\n");
    printf("(C) Copyright by Bill Buckels 1989\n");
    printf("usage \"GBAS\" to capture graphics\n");
    printf("      \"GBAS\" [80] to capture 80 column text\n");
    printf("\nTHE \"CAMERA\" IS LOADED and ready to take pictures.\n");
    printf("USE THE PRINT SCREEN KEY as the \"CAMERA SHUTTER\"\n");
    printf("IMAGES will be stored in BSAVED image format in\n");
    printf("the current directory starting with \"IMAGE000.BAS.\"\n");
    keep(0, programsize);

}

