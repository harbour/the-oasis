/* Peanuts.C was produced by Bill Buckels Oct 1990       */
/* graphics arrays were produced by using PCXARRAY.EXE   */
/* a graphics demo using embedded .PCX files in the code */
/* compiled in Mix Power C 2.0 using the Large Model     */

extern int PEANUT1_SIZE;
extern unsigned char far PEANUT1[];
extern int PEANUT2_SIZE;
extern unsigned char far PEANUT2[];
extern int PEANUT3_SIZE;
extern unsigned char far PEANUT3[];
extern int PEANUT4_SIZE;
extern unsigned char far PEANUT4[];


#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <dos.h>
#include <bios.h>
#include <io.h>
#include <malloc.h>
#include <conio.h>

#define BLUE      1
#define INTENSE   16
#define CMW       1

#define BLKBLK '\x00'

#define CRETURN '\x0d'
#define LFEED   '\x0A'
#define ESCAPE  '\x1b'

#define SCREENSIZE 16385
#define TEXT     3
#define CGA_320  4
#define HI_RES   6
#define HERCULES 99

int screen_mode= CGA_320;
int ADAPTER = CGA_320  ;


int background = BLUE+INTENSE;
int palette =    CMW;

unsigned char far *crt    =(unsigned char *) 0xB8000000l;
unsigned char far *inleaf =(unsigned char *)0xB8000000l+0x2000;

unsigned char far *screenbuffer0;
unsigned char far *screenbuffer1;
unsigned char far *screenbuffer2;
unsigned char far *screenbuffer3;

    /* =================[ CGA to HERCULES conversion ]===============*/

    /* Comparison Ratio:          pixels    size                     */
    /* the hercules display is    720 =  90 bytes wide               */
    /*                            348 =  87 "half-bytes" deep        */
    /* the cga HI_RES display is  640 =  80 bytes wide               */
    /*                            200 =  50 "half-bytes" deep        */
    /* horizontal transformation reduction 8:9 =                     */
    /*                            640 =  80 bytes literal            */
    /* vertical transformation ratio       3:2 =                     */
    /*                            300 =  50 "half-bytes" deep        */
    /* A slightly (11%) smaller but reasonably accurate facsimile    */
    /* of bit images ported from the cga may be displayed on the herc*/
    /* by applying the horizontal resolution transformation factor   */
    /* vertically then writing an extra scanline on every odd line   */
    /* relative to CGA coordinates. This is done as a "filler" and   */
    /* will widen horizontal lines in lineart reproductions if they  */
    /* fall on the (interleaf) filler line. Also, the aspect ratio   */
    /* is minimally (4%) reduced in the yaxis.                       */

    /* there are 2-significant advantages to this algorithm.         */
    /* 1. speed of execution due to integer arithmetic and the use   */
    /*    of the modulus operator and simple logic.                  */
    /* 2. greater image clarity due to maintaining true pixel ratio  */
    /*    in the x axis and a single-interleaf repeat in the y axis  */
    /*    thereby preserving a regular transformation matrix ratio.  */

    /*===============================================================*/


#define   HERCTEXT  0
#define   HERCGRAPH 1
int       HERCLEAF[4]={0x0000,0x2000,0x4000,0x6000};
#define   HERCLINE   90
#define   CGALINE    80
#define   SCREENSIZE 16385

/* we declare the screen buffer globally and allocate the memory      */
/* during initialization. We have room for several buffers.           */

void HERC_CLS(void)
{
  memset(crt,0,32767);

}

/* 6485 controller mode data */
char HERC_DAT[2][12] = { { 0x61, 0x50, 0x52, 0x0f, 0x19, 0x06,
                         0x19, 0x19, 0x02, 0x0d, 0x0b, 0x0c  },
                       { 0x35, 0x2d, 0x2e, 0x07, 0x5b, 0x02,
                         0x57, 0x57, 0x02, 0x03, 0x00 ,0x00  } };
void HERC_MODE(int ctrlmode)
{
   unsigned int reg,ctrl;
   ctrl = (ctrlmode) ? 0x82 : 0x20;
   outp(0x3bf,3)                  ;  /* allow graphics enable page 1 */
   outp(0x3b8,ctrl)               ;  /* disable video and set mode   */
   for (reg = 0; reg <= 11; reg++) { /* program the crt parameters   */
        outp(0x3b4,reg)           ;
        outp(0x3b5,HERC_DAT[ctrlmode][reg]);
        }
   outp(0x3b8,ctrl+8)             ;  /* re-enable the video          */
}

int setcrtmode(unsigned char _CRT_MODE)
{
    union REGS rin,rout;

    if ((biosequip() & 0x30) == 0x30){
        ADAPTER=HERCULES                ;
        if(_CRT_MODE == TEXT){
                HERC_CLS()              ;
                HERC_MODE(HERCTEXT)     ;
                }
           else{HERC_MODE(HERCGRAPH)    ;
                HERC_CLS()              ;
                }
            return (0)                  ;
            }

    rin.h.ah = 0;
    rin.h.al = _CRT_MODE;
    int86(0x10,&rin,&rout);
    return 0;

}

int colorset(background, palette)
unsigned char background, palette;
{
    union REGS rin,rout;
    
    if(ADAPTER==HERCULES) return 0;
    rin.h.ah = 11;
    rin.h.bh = 0;
    rin.h.bl = background;
    int86(0x10,&rin,&rout);
    rin.h.bh = 1;
    rin.h.bl = palette;
    int86(0x10,&rin,&rout);
    return 0;
}



int memoryload(unsigned char far *in, unsigned char far *out, int sz)
{
    unsigned int byteoff=0,packet,width=0;
    unsigned char byte,bytecount;
    long wordcount=0,target;


    target = 1l*sz;

    do{ bytecount=1;                          /* start with a seed count */
        byte=in[wordcount];
        wordcount++;
                                              /* check to see if its raw */
        if(0xC0 == (0xC0 &byte)){             /* if its not, run encoded */
                    bytecount= 0x3f &byte;
                    byte=in[wordcount];
                    wordcount++;
                    }
        for(packet=0;packet<bytecount;packet++){
                     out[byteoff]=byte;
                     byteoff++;
                     }
        }while(wordcount<target);
        return(0);
}

int cload(unsigned char far *array,int bottomborder)
{
 unsigned int y,inset=((HERCLINE*6)+5),offset=0;
 int status;


 if(ADAPTER==HERCULES){
    bottomborder=((bottomborder*3)/2);
    for(y=0;y!=(299-bottomborder);y++){
        memcpy(crt+HERCLEAF[y%4]+inset,array+offset,CGALINE);
        if(y%4==3)inset+=HERCLINE;
        if(y%3!=2)offset+=CGALINE;
        }
    return(0);
    }

    inset = offset;

    for(y=0;y<(200-bottomborder);){
        memcpy(crt+inset,array+offset,CGALINE);
        offset+=CGALINE;
        y++;
        memcpy(inleaf+inset,array+offset,CGALINE);
        offset+=CGALINE;
        inset+=CGALINE;
        y++;
        }
     return(0);

}



int scriptloader(int bookcounter,int pagecounter,int bottomborder)
{

 if(bookcounter==0){
    switch(pagecounter)
    {
        case 1:
                cload(screenbuffer0,bottomborder);
                break;

        case 2: cload(screenbuffer1,bottomborder);
                break;

        case 3:
                cload(screenbuffer2,bottomborder);
                break;

        case 4:
                cload(screenbuffer3,bottomborder);

    }
    }
    return 0;
}

void trapdoor()
{                               setcrtmode(TEXT);
                               _ffree(screenbuffer0);
                               _ffree(screenbuffer1);
                               _ffree(screenbuffer2);
                               _ffree(screenbuffer3);
            printf("\nProduced by Bill Buckels\n");
                               exit(0);
}


main()
{
       int done=0;
       int counter = 1;

       printf("Press Escape to End.\n");
       printf("Press Any Other Key To Advance Pictures.\n");
       printf("Please Wait... Unpacking Slideshow...\n");
       screenbuffer0=_fmalloc(SCREENSIZE);
       screenbuffer1=_fmalloc(SCREENSIZE);
       screenbuffer2=_fmalloc(SCREENSIZE);
       screenbuffer3=_fmalloc(SCREENSIZE);

       memoryload(PEANUT1,screenbuffer0,PEANUT1_SIZE);
       memoryload(PEANUT2,screenbuffer1,PEANUT2_SIZE);
       memoryload(PEANUT3,screenbuffer2,PEANUT3_SIZE);
       memoryload(PEANUT4,screenbuffer3,PEANUT4_SIZE);

       setcrtmode(CGA_320);

     while(!(done))
        {
       if(counter==5)counter=1;
       scriptloader(0,counter,0);
       counter++;
             if(getch()==27)trapdoor();
             }


}




