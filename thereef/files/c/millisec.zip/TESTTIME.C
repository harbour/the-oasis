#include	<stdio.h>
#include	<dos.h>
#include	<conio.h>
#include	"timer.h"

void main()
{
	long	start_time;
	long	stop_time;
	double	time;

	initializetimer();
/*
	delay(100);
*/

	start_time=readtimer();
	stop_time=readtimer();
	time = elapsedtime(start_time, stop_time);
	printf("time between succesive calls: %f s  (%f ms)\n",
		time, time*1000.0);

	start_time=readtimer();
/*
	delay(2);
*/
	stop_time=readtimer();
	time = elapsedtime(start_time, stop_time);
	printf("time of a 'delay(2)' call   : %f s  (%f ms)\n",
		time, time*1000.0);

	printf("time until you press a key...");
	start_time = readtimer();
	getch();
	stop_time = readtimer();
	time = elapsedtime(start_time, stop_time);
	printf("\b\b\b\b\b\b\b\b\bed a key: %f s  (%f ms)\n",
		time, time*1000.0);

	restoretimer();
}

