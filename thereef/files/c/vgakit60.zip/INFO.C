/*
	VGAKIT Version 6.0

	Copyright 1988,89,90,91,92,93,94 John Bridges
	Free for use in commercial, shareware or freeware applications

	INFO.C
*/


extern int vgamem,bksize;
extern int cirrus,everex,acumos,paradise,tseng,trident,t8900;
extern int ativga,aheada,aheadb,oaktech,video7;
extern int chipstech,tseng4,genoa,ncr,compaq,vesa,dactype;

main()
{
	whichvga();
	if(cirrus) printf("cirrus\n");
	if(everex) printf("everex\n");
	if(acumos) printf("acumos\n");
	if(paradise) printf("paradise\n");
	if(tseng) printf("tseng\n");
	if(trident) printf("trident\n");
	if(t8900) printf("t8900\n");
	if(ativga) printf("ativga\n");
	if(aheada) printf("aheada\n");
	if(aheadb ) printf("aheadb\n");
	if(oaktech) printf("oaktech\n");
	if(video7) printf("video7\n");
	if(chipstech) printf("chipstech\n");
	if(tseng4) printf("tseng4\n");
	if(genoa) printf("genoa\n");
	if(ncr) printf("ncr\n");
	if(compaq) printf("compaq\n");
	if(vesa) printf("vesa\n");
	printf("dactype=%d\n",dactype);
	printf("vgamem=%dk\n",vgamem);
	printf("bksize=%d\n\n",bksize );
}

