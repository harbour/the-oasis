/* -------------------------------- FIND.C ---------------------------------
      Copyright (c) Spark Software Inc. 1990-1992.  All Rights Reserved.
   ------------------------------------------------------------------------- */

#include <windows.h>
#include <commdlg.h>
#include <ddeml.h>
#include <string.h>
#include <memory.h>
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"

#define DEFAULT_SEARCH_PATH             "C:\\*.*"


PRIVATE BYTE szFindWhat[ MAX_SEARCH_STRING_LENGTH + 1 ];
PRIVATE BYTE szIconPath[ _MAX_PATH + 1 ];
PRIVATE BYTE szSearchPath[ _MAX_PATH + 1 ] = DEFAULT_SEARCH_PATH;
PRIVATE WORD wSFlags;
PRIVATE WORD wSDelay;
PRIVATE UINT (CALLBACK* lpfnHook)(HWND, UINT, WPARAM, LPARAM);


PUBLIC LRESULT PASCAL DoFindDlg( HWND hWnd )
{
    PRIVATE FINDREPLACE FindInfo;


#if 0
    if( hFindDlg )
    {
        /* Set the focus to the existing Find dialog. */
        SetFocus( hFindDlg );
        return (LRESULT)1;
    }
#endif

    /* Run the (Common) Find dialog. */
    memset( &FindInfo , 0 , sizeof FindInfo );
    lpfnHook = MakeProcInstance( (FARPROC)FindDlgHookProc , hInst );
    FindInfo.lStructSize = sizeof FindInfo;
    FindInfo.hwndOwner = hWnd;
    FindInfo.Flags = FR_HIDEUPDOWN | FR_HIDEMATCHCASE | FR_HIDEWHOLEWORD | FR_ENABLEHOOK;
    FindInfo.lpstrFindWhat = (LPSTR)szFindWhat;
    FindInfo.wFindWhatLen = sizeof szFindWhat;
    FindInfo.lpfnHook = lpfnHook;

    if( !( hFindDlg = FindText( &FindInfo ) ) )
    {
        /* Say that the Find dialog failed. */
        ErrorMsg( IDS_CANT_RUN_FIND_DLG );
    }

    return (LRESULT)hFindDlg;

}/* DoFindDlg( ) */


PUBLIC LRESULT PASCAL HandleFindMsg( HWND hWnd , WPARAM wParam , LPARAM lParam )
{
    FINDREPLACE FAR *lpFindInfo = (FINDREPLACE FAR *)lParam;


    if( lpFindInfo->Flags & FR_DIALOGTERM )
    {
        /* Find dialog cancelled.  Destroy the find dialog. */
        DestroyWindow( hFindDlg );
        FreeProcInstance( (FARPROC)lpfnHook );
        hFindDlg = (HWND)NULL;
        return (LRESULT)0;
    }

    /* We're only interested in the common Find */
    /* dialog telling us to find a string.      */
    if( !( lpFindInfo->Flags & FR_FINDNEXT ) )
    {
        return (LRESULT)1;
    }

    /* Destroy the find dialog. */
    DestroyWindow( hFindDlg );
    FreeProcInstance( (FARPROC)lpfnHook );
    hFindDlg = (HWND)NULL;

    /* Start the search. */
    return BeginDDESearchFind( hWnd , (LPSTR)szFindWhat );

}/* HandleFindMsg( ) */


PUBLIC UINT CALLBACK FindDlgHookProc( HWND hWnd , UINT wMessage , WPARAM wParam , LPARAM lParam )
{
    if( wMessage == WM_INITDIALOG )
    {
        SetWindowText( hWnd , (LPSTR)"Find String" );
        return TRUE;
    }
    return FALSE;

}/* FindDlgHookProc( ) */


PUBLIC VOID PASCAL GetSearchParms( LPWORD lpwSearchFlags ,
    LPWORD lpwSearchDelay , LPSTR lpszSearchPath )
{
    if( lpwSearchFlags )
    {
        *lpwSearchFlags = wSFlags;
    }

    if( lpwSearchDelay )
    {
        *lpwSearchDelay = wSDelay;
    }

    if( lpszSearchPath )
    {
        lstrcpy( lpszSearchPath , (LPSTR)szSearchPath );
    }

}/* GetSearchParms( ) */


PUBLIC VOID PASCAL SetSearchParms( WORD wSearchFlags , WORD wSearchDelay ,
    LPSTR lpszSearchPath )
{
    if( ( wSFlags = wSearchFlags ) & SF_CONTINUOUS )
    {
        wSDelay = wSearchDelay;
    }

    lstrcpy( (LPSTR)szSearchPath , lpszSearchPath );

}/* SetSearchParms( ) */


PUBLIC LPSTR PASCAL GetIconPath( VOID )
{
    return (LPSTR)szIconPath;

}/* GetIconPath( ) */


PUBLIC VOID PASCAL MakeIconPathName( VOID )
{
    PRIVATE BYTE szIconFileName[ ] = "file.ico";


    /* Get the pathname of this executable module. */
    GetModuleFileName( hInst , (LPSTR)szIconPath , sizeof szIconPath );

    /* Replace the basename with the icon filename. */
    lstrcpy( GetBaseName( (LPSTR)szIconPath ) , (LPSTR)szIconFileName );

}/* MakeIconPathName( ) */


PUBLIC LPSTR PASCAL GetBaseName( LPSTR lpszPathName )
{
    LPSTR lpszBaseName;


    /* Point at the basename. */
    if( !( lpszBaseName = lstrrchr( lpszPathName , '\\' ) ) &&
        !( lpszBaseName = lstrrchr( lpszPathName , '/' ) ) )
    {
        lpszBaseName = lstrrchr( lpszPathName , ':' );
    }

    if( lpszBaseName )
    {
        lpszBaseName++;
    }
    else
    {
        lpszBaseName = lpszPathName;
    }

    return lpszBaseName;

}/* GetBaseName( ) */

/* EOF */
