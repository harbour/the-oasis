/* ----------------------------- DEMOCLI.C ---------------------------------
      Copyright (c) Spark Software Inc. 1990-1992.  All Rights Reserved.
   ------------------------------------------------------------------------- */

#define STRICT
#include <windows.h>
#include <commdlg.h>
#include <ddeml.h>
#include <string.h>
#define  PUBLIC
#define  INITMODULE
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"
#undef   INITMODULE

#define MASTER_WIN_WIDTH    400
#define MASTER_WIN_HEIGHT   200
#define MAX_MESSAGES        120
#define DEFAULT_MESSAGES    8


PRIVATE VOID    PASCAL Cleanup( VOID );
PRIVATE BOOL    PASCAL InitApp( VOID );
PRIVATE BOOL    PASCAL InitInstance( LPSTR lpszCmdLine , int nCmdShow );
PRIVATE LRESULT PASCAL DoCommand( HWND hWnd , WPARAM wParam , LPARAM lParam );
PRIVATE LRESULT PASCAL DoCreate( HWND hWnd );
PRIVATE LRESULT PASCAL DoClose( HWND hWnd );
PRIVATE LRESULT PASCAL DoDestroy( HWND hWnd );
PRIVATE LRESULT PASCAL DoFileFound( HWND hWnd , WPARAM wParam , LPARAM lParam );
PRIVATE LRESULT PASCAL DoSize( HWND hWnd , WPARAM wParam , LPARAM lParam );
PRIVATE LRESULT PASCAL DoSetFocus( HWND hWnd , WPARAM wParam );

PRIVATE UINT           wFindMessage;
PRIVATE HACCEL         hAccelTable;
PRIVATE HWND           hWndFoundFileListbox;
PRIVATE HOOKPROC       lpMsgHookProc;


PUBLIC int PASCAL WinMain( HINSTANCE hInstance , HINSTANCE hPrevInstance , LPSTR lpszCmdLine , int nCmdShow )
{
    MSG Msg;


    /* Initialize the application. */
    hInst = hInstance;
    if( !InitApp( ) || !InitInstance( lpszCmdLine , nCmdShow ) )
    {
        Cleanup( );
        ErrorMsg( IDS_CANT_INITIALIZE_APP );
        return -1;
    }

    while( GetMessage( (LPMSG)&Msg , NULL , 0 , 0 ) )
    {
        ( *lpMsgHookProc )( MSGF_DDEMGR , 0 , (LONG)(LPMSG)&Msg );
    }

    Cleanup( );
    return (int)Msg.wParam;

}/* WinMain( ) */


PRIVATE BOOL PASCAL InitApp( VOID )
{
    HWND     hPrevAppInstWnd;
    WNDCLASS wcInfo;


    /* We must be running in a non-real mode to use DDEML. */
    if( !( GetWinFlags( ) & WF_PMODE ) )
    {
        /* Sorry, this must be Windows 3.0 in real mode.  Bye bye. */
        return FALSE;
    }

    if( ( hPrevAppInstWnd = FindWindow( (LPSTR)szClass , (LPSTR)NULL ) ) )
    {
        /* Classes already registered by a previous instance. */
        /* Make sure we can see this app. instance. */
        ShowWindow( hPrevAppInstWnd , SW_SHOW );
        return TRUE;
    }

    /* Register the master window class. */
    wcInfo.style         = CS_VREDRAW | CS_HREDRAW;
    wcInfo.lpfnWndProc   = WndProc;
    wcInfo.cbClsExtra    = 0;
    wcInfo.cbWndExtra    = 0;
    wcInfo.hInstance     = hInst;
    wcInfo.hIcon         = LoadIcon( hInst , MAKEINTRESOURCE( APP_ICON ) );
    wcInfo.hCursor       = LoadCursor( (HINSTANCE)NULL , IDC_ARROW );
    wcInfo.hbrBackground = (HBRUSH)GetStockObject( WHITE_BRUSH );
    wcInfo.lpszMenuName  = MAKEINTRESOURCE( APP_MENU );
    wcInfo.lpszClassName = (LPSTR)szClass;

    return RegisterClass( (LPWNDCLASS)&wcInfo );

}/* InitApp( ) */


PRIVATE BOOL PASCAL InitInstance( LPSTR lpszCmdLine , int nCmdShow )
{
    BOOL         bQueueOK;
    RECT         rMaster;
    register int nIndex;


    /* Get as large a message queue as possible. */
    for(
        nIndex = MAX_MESSAGES , bQueueOK = FALSE;
        nIndex > DEFAULT_MESSAGES && !bQueueOK;
        nIndex--
       )
    {
        bQueueOK = SetMessageQueue( nIndex );
    }

    if( !bQueueOK )
    {
        /* Couldn't expand message queue. */
        return FALSE;
    }

    /* Initialize the DDEML. */
    if( DdeInitialize( &dwInstID ,
        (PFNCALLBACK)MakeProcInstance( (FARPROC)DDEClientCallback , hInst ) ,
        APPCMD_CLIENTONLY , 0L ) )
    {
        return FALSE;
    }
    ccInfo.iCodePage = CP_WINANSI;

    /* Create needed string handles. */
    InitTopicsAndItems( );

    /* Set up a message filter so that we can process messages during */
    /* DDEML's synchronous transaction (modal) processing loop.       */
    lpMsgHookProc = (HOOKPROC)MakeProcInstance( (FARPROC)MsgHookProc , hInst );
    SetWindowsHook( WH_MSGFILTER , lpMsgHookProc );

    /* Get the message index for the FIND dialog. */
    wFindMessage = RegisterWindowMessage( FINDMSGSTRING );

    /* Create the master window. */
    hWndMaster = CreateWindow
    (
        (LPSTR)szClass     ,
        (LPSTR)szAppName   ,
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN ,
        CW_USEDEFAULT      ,
        0                  ,
        MASTER_WIN_WIDTH   ,
        MASTER_WIN_HEIGHT  ,
        (HWND)NULL         ,
        (HMENU)NULL        ,
        hInst              ,
        (LPSTR)NULL
    );

    if( !hWndMaster || !hWndFoundFileListbox ||
        !( hAccelTable = LoadAccelerators( hInst , MAKEINTRESOURCE( APP_ACCELTAB ) ) ) )
    {
        return FALSE;
    }

    /* Construct the full pathname of an icon file for found files. */
    MakeIconPathName( );

    /* Show the window. */
    ShowWindow( hWndMaster , nCmdShow );
    GetClientRect( hWndMaster , (LPRECT)&rMaster );
    SetWindowPos( hWndFoundFileListbox , (HWND)NULL , 0 , 0 ,
        rMaster.right , rMaster.bottom ,
        SWP_DRAWFRAME | SWP_SHOWWINDOW | SWP_NOZORDER );
    UpdateWindow( hWndMaster );
    return TRUE;

}/* InitInstance( ) */


PRIVATE VOID PASCAL Cleanup( VOID )
{
    if( lpMsgHookProc )
    {
        /* Remove the message filter. */
        UnhookWindowsHook( WH_MSGFILTER , lpMsgHookProc );
        FreeProcInstance( (FARPROC)lpMsgHookProc );
    }

    /* Free needed string handles. */
    CleanupTopicsAndItems( );

    /* Uninitialize the DDEML. */
    DdeUninitialize( dwInstID );

}/* Cleanup( ) */


PUBLIC DWORD WINAPI MsgHookProc( int nCode , WORD wParam , DWORD lParam )
{
    if( nCode == MSGF_DDEMGR )
    {
        if( ( !hFindDlg || !IsDialogMessage( hFindDlg , (LPMSG)lParam ) ) &&
            !TranslateAccelerator( hWndMaster , hAccelTable , (LPMSG)lParam ) )
        {
            TranslateMessage( (LPMSG)lParam );
            DispatchMessage( (LPMSG)lParam );
        }
        return (DWORD)1;
    }
    return (DWORD)0;

}/* MsgHookProc( ) */


PUBLIC LRESULT WINAPI WndProc( HWND hWnd , UINT wMessage , WPARAM wParam , LPARAM lParam )
{
    switch( wMessage )
    {
    case WM_CREATE:         return DoCreate( hWnd );
    case WM_CLOSE:          return DoClose( hWnd );
    case WM_DESTROY:        return DoDestroy( hWnd );
    case WM_COMMAND:        return DoCommand( hWnd , wParam , lParam );
    case WM_SIZE:           return DoSize( hWnd , wParam , lParam );
    case WM_SETFOCUS:       return DoSetFocus( hWnd , wParam );
    case MM_FILE_FOUND:     return DoFileFound( hWnd , wParam , lParam );

    default:
        if( wMessage == wFindMessage )
        {
            return HandleFindMsg( hWnd , wParam , lParam );
        }
        return DefWindowProc( hWnd , wMessage , wParam , lParam );
    }

}/* WndProc( ) */


PRIVATE LRESULT PASCAL DoCreate( HWND hWnd )
{
    /* Create the found file listbox. */
    hWndFoundFileListbox = CreateWindow
    (
        (LPSTR)"listbox"   ,
        (LPSTR)""          ,
        WS_CHILD | WS_VSCROLL | LBS_NOTIFY ,
        CW_USEDEFAULT      ,
        0                  ,
        CW_USEDEFAULT      ,
        0                  ,
        hWnd               ,
        (HMENU)IDC_LB_FOUND_FILE ,
        hInst              ,
        (LPSTR)NULL
    );

    return (LRESULT)1;

}/* DoCreate( ) */


PRIVATE LRESULT PASCAL DoClose( HWND hWnd )
{
    /* We won't bother to shut down transactions or conversations if the */
    /* server has already terminated.  Doing so would cause DDEML errors */
    /* to be displayed via ErrorMsg( ) when the related DDEML functions  */
    /* fail to find the server.                                          */
    if( !bServerTerminated )
    {
        /* Abandon all pending transactions. */
        DdeAbandonTransaction( dwInstID , (HCONV)NULL , (DWORD)0 );

        /* End the advise loop and conversation, if any. */
        EndDDESearchFind( hWndMaster , TRUE );
    }

    DestroyWindow( hWnd );
    return (LRESULT)1;

}/* DoClose( ) */


PRIVATE LRESULT PASCAL DoDestroy( HWND hWnd )
{
    /* Say Goodbye to Hollywood. */
    PostQuitMessage( wExitStatus );
    return (LRESULT)1;

}/* DoDestroy( ) */


PRIVATE LRESULT PASCAL DoCommand( HWND hWnd , WPARAM wParam , LPARAM lParam )
{
    DWORD          dwFileSize;
    LPSTR          lpszFileContents;
    LRESULT        lSelection;
    OFSTRUCT       ofInfo;
    BROWSEFILEINFO bfInfo;
    HFILE          hFile;


    switch( wParam )
    {
    case IDM_FIND:
        /* Display the modeless (common) Find dialog. */
        return DoFindDlg( hWnd );

    case IDM_CONFIGURE:
        /* Display the Configure dialog. */
        DO_DIALOG( ConfigureDlgProc , DLG_CONFIGURE , hInst , hWnd ,
            (LPARAM)NULL );
        return (LRESULT)1;

    case IDM_CLEAR_WINDOW:
        SendMessage( hWndFoundFileListbox , LB_RESETCONTENT , 0 , (LPARAM)0 );
        return (LRESULT)1;

    case IDM_DDE_TOPICS:
    case IDM_DDE_SYSITEMS:
    case IDM_DDE_RTNMSG:
    case IDM_DDE_STATUS:
    case IDM_DDE_FORMATS:
    case IDM_DDE_HELP:
        return DoDDESystemTopic( hWnd , wParam );

    case IDM_ABOUT:
        /* Display the About dialog. */
        DO_DIALOG( AboutDlgProc , DLG_ABOUT , hInst , hWnd , (LPARAM)NULL );
        return (LRESULT)1;

    case IDM_BROWSE_FILE:
        /* Fake ourselves out - make believe it's a doubleclick. */
        wParam = (WPARAM)IDC_LB_FOUND_FILE;
        lParam = MAKELPARAM( hWndFoundFileListbox , LBN_DBLCLK );

        /* Fall through. */

    case IDC_LB_FOUND_FILE:
        if( HIWORD( lParam ) == LBN_DBLCLK )
        {
            /* Get the selected string. */
            lSelection = SendMessage( hWndFoundFileListbox , LB_GETCURSEL ,
                0 , (LPARAM)0 );
            if( lSelection == (LRESULT)LB_ERR )
            {
                /* Could not get list box selection. */
                ErrorMsg( IDS_CANNOT_GET_FILENAME );
                return (LRESULT)0;
            }

            SendMessage( hWndFoundFileListbox , LB_GETTEXT ,
                (WPARAM)lSelection , (LPARAM)(LPSTR)szString );

            /* Open the file whose name we retrieved. */
            if( ( hFile = OpenFile( (LPSTR)szString , (LPOFSTRUCT)&ofInfo ,
                OF_READ | OF_SHARE_DENY_WRITE ) ) == -1 )
            {
                /* File open failed. */
                ErrorMsg( IDS_CANNOT_OPEN_FILE );
                return (LRESULT)0;
            }

            /* Get one large buffer for the file contents. */
            dwFileSize = (DWORD)_llseek( hFile , (LONG)0 , 2 );
            if( !( bfInfo.hFileContents = GetMem( dwFileSize ) ) ||
                !( lpszFileContents = LockMem( bfInfo.hFileContents ) ) )
            {
                /* Memory allocation or lock failed. */
                if( bfInfo.hFileContents )
                {
                    FreeMem( bfInfo.hFileContents );
                }

                _lclose( hFile );
                ErrorMsg( IDS_CANNOT_DISPLAY_FILE );
                return (LRESULT)0;
            }

            /* Seek to TOF and read the file. */
            _llseek( hFile , (LONG)0 , 0 );
            if( ( bfInfo.dwFileSize =
                (DWORD)_hread( hFile , (VOID _huge *)lpszFileContents ,
                (LONG)dwFileSize ) ) == (DWORD)-1 )
            {
                /* Couldn't read the file. */
                UnlockMem( bfInfo.hFileContents );
                FreeMem( bfInfo.hFileContents );
                _lclose( hFile );
                ErrorMsg( IDS_CANNOT_DISPLAY_FILE );
                return (LRESULT)0;
            }

            /* Close the file and unlock the buffer. */
            UnlockMem( bfInfo.hFileContents );
            _lclose( hFile );

            /* Pass the file info to the Browse File dialog. */
            lstrcpy( (LPSTR)bfInfo.szBaseName , GetBaseName( (LPSTR)szString ) );
            DO_DIALOG( BrowseFileDlgProc , DLG_BROWSE_FILE , hInst , hWnd ,
                (LPARAM)(LPBROWSEFILEINFO)&bfInfo );

            /* Free the buffer. */
            FreeMem( bfInfo.hFileContents );
        }
        return (LRESULT)1;
    }

    return (LRESULT)0;

}/* DoCommand( ) */


PRIVATE LRESULT PASCAL DoSize( HWND hWnd , WPARAM wParam , LPARAM lParam )
{
    /* Resize the found file listbox. */
    SetWindowPos( hWndFoundFileListbox , (HWND)NULL , 0 , 0 ,
        LOWORD( lParam ) , HIWORD( lParam ) ,
        SWP_DRAWFRAME | SWP_SHOWWINDOW | SWP_NOZORDER | SWP_NOMOVE );
    return (LRESULT)1;

}/* DoSize( ) */


PRIVATE LRESULT PASCAL DoSetFocus( HWND hWnd , WPARAM wParam )
{
    /* Set the focus to the found file listbox. */
    SetFocus( hWndFoundFileListbox );
    return (LRESULT)1;

}/* DoSetFocus( ) */


PRIVATE LRESULT PASCAL DoFileFound( HWND hWnd , WPARAM wParam , LPARAM lParam )
{
    /* Don't add a found filename already in the client's listbox. */
    if( SendMessage( hWndFoundFileListbox , LB_FINDSTRINGEXACT ,
        (WPARAM)-1 , lParam ) != LB_ERR )
    {
        /* String already here.  Do nothing. */
        return (LRESULT)1;
    }

    /* Put the name of the found file into the client's listbox. */
    return SendMessage( hWndFoundFileListbox , LB_ADDSTRING , 0 , lParam ) + 1;

}/* DoFileFound( ) */


PUBLIC VOID ErrorMsg( UINT wErrorMsgIndex )
{
    if( !LoadString( hInst , wErrorMsgIndex , (LPSTR)szString , sizeof szString ) )
    {
        LoadString( hInst , IDS_UNKNOWN_ERROR , (LPSTR)szString , sizeof szString );
    }

    MessageBox( GetFocus( ) , (LPSTR)szString , (LPSTR)szAppName , MB_OK | MB_ICONEXCLAMATION );

}/* ErrorMsg( ) */

/* EOF */
