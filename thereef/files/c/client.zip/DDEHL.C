/* -------------------------------- DDEHL.C --------------------------------
      Copyright (c) Spark Software Inc. 1990-1992.  All Rights Reserved.
   ------------------------------------------------------------------------- */

#include <windows.h>
#include <commdlg.h>
#include <ddeml.h>
#include <string.h>
#include <memory.h>
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"

#define SERVICE_PROGMAN         "PROGMAN"
#define TOPIC_PROGMAN           "PROGMAN"
#define PROGMAN_GROUP_NAME      "Files Found"


PRIVATE VOID PASCAL BuildServiceName( VOID );

PRIVATE BOOL  bAdvise;
PRIVATE BYTE  szServiceName[ MAX_HSZ_LENGTH + 1 ] = SERVER_APP_NAME;
PRIVATE BYTE  szServerNodeName[ MAX_NODE_NAME_LENGTH + 1 ];
PRIVATE BYTE  szOldServerNodeName[ MAX_NODE_NAME_LENGTH + 1 ];
PRIVATE DWORD dwTransactionTimeout = (DWORD)STD_SYNC_TIMEOUT;


PUBLIC LPSTR PASCAL GetServerNode( VOID )
{
    return (LPSTR)szServerNodeName;

}/* GetServerNode( ) */


PUBLIC VOID PASCAL SetServerNode( LPSTR lpszNodeName )
{
    /* Save the previous server node name so that we can revert to it. */
    strcpy( szOldServerNodeName , szServerNodeName );

    _fstrncpy( (LPSTR)szServerNodeName , lpszNodeName , MAX_NODE_NAME_LENGTH );
    szServerNodeName[ MAX_NODE_NAME_LENGTH ] = '\0';
    BuildServiceName( );

}/* SetServerNode( ) */


PUBLIC VOID PASCAL RevertServerNode( VOID )
{
    /* Revert to the previous server node name. */
    strcpy( szServerNodeName , szOldServerNodeName );
    BuildServiceName( );

}/* RevertServerNode( ) */


PUBLIC DWORD PASCAL GetTransactionTimeout( VOID )
{
    return dwTransactionTimeout;

}/* GetTransactionTimeout( ) */


PUBLIC VOID PASCAL SetTransactionTimeout( DWORD dwTimeout )
{
    dwTransactionTimeout = dwTimeout;

}/* SetTransactionTimeout( ) */


PRIVATE VOID PASCAL BuildServiceName( VOID )
{
    *szServiceName = '\0';
    if( *szServerNodeName )
    {
        strcpy( szServiceName , "\\\\" );
        strcat( szServiceName , szServerNodeName );
        strcat( szServiceName , "\\" );
    }

    strcat( szServiceName , SERVER_APP_NAME );

}/* BuildServiceName( ) */


PUBLIC LRESULT PASCAL DoDDESystemTopic( HWND hWnd , WORD wParam )
{
    BYTE          szCaption[ 32 ];
    PRIVATE BYTE  szFormat[ 256 ];
    WORD          wDDEMLError;
    UINT          wResourceID;
    DWORD         dwLength;
    LPSTR         lpszOurData;
    LPSTR         lpszTopic;
    LPSTR         lpszItem;
    HDDEDATA      hddResult;
    HCONV         hConv;
    HSZ           hszItem;


    /* Set up our service, topic and item names. */
    switch( wParam )
    {
    case IDM_DDE_TOPICS:
        lpszItem = (LPSTR)SZDDESYS_ITEM_TOPICS;
        wResourceID = IDS_EXPLAIN_TOPICS;
        break;

    case IDM_DDE_SYSITEMS:
        lpszItem = (LPSTR)SZDDESYS_ITEM_SYSITEMS;
        wResourceID = IDS_EXPLAIN_SYSITEMS;
        break;

    case IDM_DDE_RTNMSG:
        lpszItem = (LPSTR)SZDDESYS_ITEM_RTNMSG;
        wResourceID = IDS_EXPLAIN_RTNMSG;
        break;

    case IDM_DDE_STATUS:
        lpszItem = (LPSTR)SZDDESYS_ITEM_STATUS;
        wResourceID = IDS_EXPLAIN_STATUS;
        break;

    case IDM_DDE_FORMATS:
        lpszItem = (LPSTR)SZDDESYS_ITEM_FORMATS;
        wResourceID = IDS_EXPLAIN_FORMATS;
        break;

    case IDM_DDE_HELP:
        lpszItem = (LPSTR)SZDDESYS_ITEM_HELP;
        wResourceID = 0;
        break;

    default:
        /* Invalid wParam. */
        return (LRESULT)0;
    }
    lpszTopic = (LPSTR)SZDDESYS_TOPIC;

    /* Start a DDE conversation with our server. */
    HandleDDEMLError(
        ( hConv = BeginDDEConversation( hWnd , (LPSTR)szServiceName ,
            lpszTopic , (LPWORD)&wDDEMLError ) ) ,
        1 , (LRESULT)0 );

    /* Create a string handle for the item. */
    hszItem = DdeCreateStringHandle( dwInstID , lpszItem , CP_WINANSI );

    /* Send this request. */
    HandleDDEMLError(
        ( hddResult = DoTransaction( hWnd , (VOID FAR *)NULL , (DWORD)0 ,
            hConv , hszItem , CF_TEXT , XTYP_REQUEST ,
            dwTransactionTimeout , (LPDWORD)NULL , (LPWORD)&wDDEMLError ) ) ,
        0 , (LRESULT)0 );

    DdeFreeStringHandle( dwInstID , hszItem );

    /* End our DDE conversation. */
    HandleDDEMLError(
        EndDDEConversation( hWnd , hConv , (LPWORD)&wDDEMLError ) ,
        1 , (LRESULT)0 );

    if( !hddResult )
    {
        return (LRESULT)0;
    }

    /* Access the data and display it. */
    lpszOurData = DdeAccessData( hddResult , (LPDWORD)&dwLength );
    wsprintf( (LPSTR)szCaption , (LPSTR)"%s Item" , lpszItem );

    if( wResourceID )
    {
        LoadString( hInst , wResourceID , (LPSTR)szFormat , sizeof szFormat );
        wsprintf( (LPSTR)szString , (LPSTR)szFormat ,
            *lpszOurData ? lpszOurData : (LPSTR)"(No information)" );
    }
    else
    {
        lstrcpy( (LPSTR)szString ,
            *lpszOurData ? lpszOurData : (LPSTR)"(No information)" );
    }

    MessageBox( GetFocus( ) , (LPSTR)szString , (LPSTR)szCaption ,
        MB_OK | MB_ICONASTERISK );
    DdeUnaccessData( hddResult );
    DdeFreeDataHandle( hddResult );
    return (LRESULT)1;

}/* DoDDESystemTopic( ) */


PUBLIC LRESULT PASCAL DoDDESearchConfigure( HWND hWnd , WORD wSearchFlags ,
    WORD wSearchDelay , LPSTR lpszSearchPath )
{
    WORD          wDDEMLError;
    LPSTR         lpszTopic;
    LPSTR         lpszItem;
    HDDEDATA      hddResult;
    HCONV         hConv;
    HDDEDATA      hddPokeData;
    HSZ           hszItem;


    /* Set up our service, topic and item names. */
    lpszTopic = (LPSTR)TOPIC_SEARCH;
    lpszItem = (LPSTR)ITEM_CONFIGURE;

    /* Start a DDE conversation with our server. */
    HandleDDEMLError(
        ( hConv = BeginDDEConversation( hWnd , (LPSTR)szServiceName ,
            lpszTopic , (LPWORD)&wDDEMLError ) ) ,
        1 , (LRESULT)0 );

    /* Create a string handle for the item. */
    hszItem = DdeCreateStringHandle( dwInstID , lpszItem , CP_WINANSI );

    /* Create a DDE data handle for the poke data.    */
    wsprintf( (LPSTR)szString , (LPSTR)"%u %u %s" ,
        wSearchFlags , wSearchDelay , lpszSearchPath );
    hddPokeData = DdeCreateDataHandle( dwInstID ,
        (VOID FAR *)(LPSTR)szString , (DWORD)strlen( szString ) + 1 ,
        0 , hszItem , CF_TEXT , 0 );

    /* Send this poke. */
    HandleDDEMLError(
        ( hddResult = DoTransaction( hWnd , (VOID FAR *)hddPokeData ,
            (DWORD)-1 , hConv , hszItem , CF_TEXT , XTYP_POKE ,
            dwTransactionTimeout , (LPDWORD)NULL , (LPWORD)&wDDEMLError ) ) ,
        0 , (LRESULT)0 );

    DdeFreeStringHandle( dwInstID , hszItem );

    /* End our DDE conversation. */
    HandleDDEMLError(
        EndDDEConversation( hWnd , hConv , (LPWORD)&wDDEMLError ) ,
        1 , (LRESULT)0 );

    if( !hddResult )
    {
        return (LRESULT)0;
    }

    return (LRESULT)1;

}/* DoDDESearchConfigure( ) */


PUBLIC LRESULT PASCAL BeginDDESearchFind( HWND hWnd , LPSTR lpszFindWhat )
{
    WORD          wDDEMLError;
    HDDEDATA      hddResult;
    HCONV         hConv;
    HDDEDATA      hddFindWhat;
    HSZ           hszItem;


    /* Start the search conversation and start an advise loop. */
    if( !( hConv = BeginDDESearchConv( hWnd ) ) )
    {
        return (LRESULT)0;
    }

    /* Create a string handle for the item. */
    hszItem = DdeCreateStringHandle( dwInstID , (LPSTR)ITEM_FIND , CP_WINANSI );

    /* Create a data handle for the text we'd like to find. */
    hddFindWhat = DdeCreateDataHandle( dwInstID ,
        (VOID FAR *)lpszFindWhat , (DWORD)lstrlen( lpszFindWhat ) + 1 ,
        0 , hszItem , CF_TEXT , 0 );

    /* Poke the data handle into the server. */
    HandleDDEMLError(
        ( hddResult = DoTransaction( hWnd , (VOID FAR *)hddFindWhat ,
            (DWORD)-1 , hConv , hszItem , CF_TEXT , XTYP_POKE ,
            dwTransactionTimeout , (LPDWORD)NULL , (LPWORD)&wDDEMLError ) ) ,
        0 , (LRESULT)0 );

    /* Free the item string handle. */
    DdeFreeStringHandle( dwInstID , hszItem );

    if( !hddResult )
    {
        return (LRESULT)0;
    }

    return (LRESULT)1;

}/* BeginDDESearchFind( ) */


PUBLIC HCONV PASCAL BeginDDESearchConv( HWND hWnd )
{
    WORD     wDDEMLError;
    HDDEDATA hddResult;
    HCONV    hConv;
    HSZ      hszItem;


    /* If there is no DDE conversation present for searching... */
    if( !( hConv = GetSearchConvHandle( ) ) )
    {
        /* Start a DDE conversation with our server. */
        HandleDDEMLError(
            ( hConv = BeginDDEConversation( hWnd , (LPSTR)szServiceName ,
                (LPSTR)TOPIC_SEARCH , (LPWORD)&wDDEMLError ) ) ,
            1 , (HCONV)NULL );
        SetSearchConvHandle( hConv );
    }

    if( !bAdvise )
    {
        /* Create a string handle for the item. */
        hszItem = DdeCreateStringHandle( dwInstID , (LPSTR)ITEM_FIND ,
            CP_WINANSI );

        /* Start an advise loop. */
        HandleDDEMLError(
            ( hddResult = DoTransaction( hWnd , (VOID FAR *)NULL ,
                (DWORD)0 , hConv , hszItem , CF_TEXT , XTYP_ADVSTART ,
                dwTransactionTimeout , (LPDWORD)NULL ,
                (LPWORD)&wDDEMLError ) ) ,
            0 , (HCONV)NULL );

        /* Free the item string handle. */
        DdeFreeStringHandle( dwInstID , hszItem );

        if( !hddResult )
        {
            /* Advise loop start failed.  Clean up the conversation. */
            EndDDESearchFind( hWnd , FALSE );
            return (HCONV)0;
        }

        /* Record the fact that we established an advise loop. */
        bAdvise = TRUE;
    }

    return hConv;

}/* BeginDDESearchConv( ) */


PUBLIC LRESULT PASCAL EndDDESearchFind( HWND hWnd , BOOL bAdvStop )
{
    WORD          wDDEMLError;
    HDDEDATA      hddResult;
    HCONV         hConv;
    HSZ           hszItem;


    if( !( hConv = GetSearchConvHandle( ) ) )
    {
        /* No conversation active. */
        return (LRESULT)0;
    }

    if( bAdvStop )
    {
        /* Create a string handle for the item. */
        hszItem = DdeCreateStringHandle( dwInstID , (LPSTR)ITEM_FIND ,
            CP_WINANSI );

        /* Stop the advise loop. */
        HandleDDEMLError(
            ( hddResult = DoTransaction( hWnd , (VOID FAR *)NULL ,
                (DWORD)0 , hConv , hszItem , CF_TEXT , XTYP_ADVSTOP ,
                dwTransactionTimeout , (LPDWORD)NULL ,
                (LPWORD)&wDDEMLError ) ) ,
            0 , (LRESULT)0 );

        /* Free the item string handle. */
        DdeFreeStringHandle( dwInstID , hszItem );

        /* Record the fact that we stopped our advise loop. */
        bAdvise = FALSE;
    }

    /* End our DDE conversation. */
    HandleDDEMLError(
        EndDDEConversation( hWnd , hConv , (LPWORD)&wDDEMLError ) ,
        1 , (LRESULT)0 );
    SetSearchConvHandle( (HCONV)NULL );

    if( !hddResult )
    {
        return (LRESULT)0;
    }

    return (LRESULT)1;

}/* EndDDESearchFind( ) */


PUBLIC BOOL PASCAL ProcessFoundFile( HWND hWnd , LPSTR lpszFilePathName )
{
    BOOL          bGroupIconFound;
    WORD          wSearchFlags;
    WORD          wDDEMLError;
    register WORD wIndex;
    int           nFilePathNameLength;
    DWORD         dwLength;
    HCONV         hConv;
    LPSTR         lpszBaseFileName;
    LPSTR         lpszOurData;
    GLOBALHANDLE  hOurData;
    HSZ           hszItem;
    HDDEDATA      hddResult;
    HDDEDATA      hddExecuteCmd;
    PRIVATE LPSTR lpszCmds[ ] =
    {
        "[CreateGroup(%s)]" ,
#define PM_CMD_CREATE               0
        "[ShowGroup(%s,1)]" ,
#define PM_CMD_SHOW                 1
        "[AddItem(%s,%s,%s)]" ,
#define PM_CMD_ADD                  2
        (LPSTR)NULL
    };


    /* Display the name of the found file. */
    SendMessage( hWnd , MM_FILE_FOUND , 0 , (LPARAM)lpszFilePathName );

    /* Get the search parameters as previously set up. */
    GetSearchParms( (LPWORD)&wSearchFlags , (LPWORD)NULL , (LPSTR)NULL );

    /* Only proceed if we want to transmit the pathname to Program Manager. */
    if( !( wSearchFlags & SF_XMIT_TO_PROGMAN ) )
    {
        return TRUE;
    }

    /* Say that we haven't yet looked for the group icon for this file. */
    bGroupIconFound = FALSE;

    /* Start a DDE conversation with the Program Manager. */
    HandleDDEMLError(
        ( hConv = BeginDDEConversation( hWnd , (LPSTR)SERVICE_PROGMAN ,
            (LPSTR)TOPIC_PROGMAN , (LPWORD)&wDDEMLError ) ) ,
        1 , FALSE );

    /* First, see if the (group and the) icon are already present. */

    /* Create a string handle for the item. */
    hszItem = DdeCreateStringHandle( dwInstID , (LPSTR)PROGMAN_GROUP_NAME ,
        CP_WINANSI );

    hddResult = DoTransaction( hWnd , (VOID FAR *)NULL ,
            (DWORD)0 , hConv , hszItem , CF_TEXT , XTYP_REQUEST ,
            dwTransactionTimeout , (LPDWORD)NULL ,
            (LPWORD)&wDDEMLError );

    DdeFreeStringHandle( dwInstID , hszItem );

    /* If the group doesn't exist, wDDEMLError will be */
    /* DMLERR_NOTPROCESSED and hddResult will be NULL. */
    /* If the group does exist, we're gonna search it. */
    if( wDDEMLError == DMLERR_NO_ERROR && hddResult )
    {
        /* Get a copy of the data and process it. */
        lpszOurData = DoGetData( hddResult , (LPGLOBALHANDLE)&hOurData ,
            (LPDWORD)&dwLength , TRUE );
        DdeFreeDataHandle( hddResult );

        /* Start at the second line of data. */
        nFilePathNameLength = _fstrlen( lpszFilePathName );
        while( TRUE )
        {
            if( !( lpszOurData = _fstrchr( lpszOurData , '\n' ) ) ||
                !*++lpszOurData )
            {
                break;
            }

            /* Go to the full pathname (skip the open quote).  */
            /* NOTE: assumption here that filenames will never */
            /* have embedded commas or quotes.                 */
            if( !( lpszOurData = _fstrchr( lpszOurData , ',' ) ) ||
                !( lpszOurData = _fstrchr( lpszOurData , '"' ) ) ||
                !*++lpszOurData )
            {
                break;
            }

            if( !_fstrnicmp( lpszOurData , lpszFilePathName , nFilePathNameLength ) )
            {
                /* We found the group icon for this file. */
                bGroupIconFound = TRUE;
                break;
            }
        }

        UnlockMem( hOurData );
        FreeMem( hOurData );
    }

    /* If the group icon was found or something unexpected happenned, */
    /* do nothing.  If the group icon was not found, ...              */
    if( !bGroupIconFound )
    {
        /* Add the icon to the Program Manager group. */

        /* Make certain that our Program Manager group is */
        /* showing, then add the new file to that group.  */
        for( wIndex = 0; lpszCmds[ wIndex ]; wIndex++ )
        {
            /* Format the command string. */
            switch( wIndex )
            {
            case PM_CMD_CREATE:
            case PM_CMD_SHOW:
                wsprintf( (LPSTR)szString , lpszCmds[ wIndex ] ,
                    (LPSTR)PROGMAN_GROUP_NAME );
                break;

            case PM_CMD_ADD:
                lpszBaseFileName = GetBaseName( lpszFilePathName );
                wsprintf( (LPSTR)szString , lpszCmds[ wIndex ] ,
                    lpszFilePathName , lpszBaseFileName , GetIconPath( ) );
                break;
            }

            /* Create a DDE data handle for the execute string. */
            hddExecuteCmd = DdeCreateDataHandle( dwInstID ,
                (VOID FAR *)(LPSTR)szString , (DWORD)strlen( szString ) + 1 ,
                0 , NULL , CF_TEXT , 0 );

            /* Send this Execute string. */
            HandleDDEMLError(
                DoTransaction( hWnd , (VOID FAR *)hddExecuteCmd ,
                    (DWORD)-1 , hConv , NULL , CF_TEXT , XTYP_EXECUTE ,
                    dwTransactionTimeout , (LPDWORD)NULL ,
                    (LPWORD)&wDDEMLError ) ,
                0 , FALSE );
        }
    }

    /* End our DDE conversation. */
    HandleDDEMLError(
        EndDDEConversation( hWnd , hConv , (LPWORD)&wDDEMLError ) ,
        1 , FALSE );

    return TRUE;

}/* ProcessFoundFile( ) */

/* EOF */
