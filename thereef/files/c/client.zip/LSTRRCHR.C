/* ---------------------------- LSTRRCHR.C  --------------------------------
      Copyright (c) Spark Software Inc. 1990-1992.  All Rights Reserved.
   ------------------------------------------------------------------------- */


#include <windows.h>
#include <commdlg.h>
#include <ddeml.h>
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"


PUBLIC LPSTR PASCAL lstrrchr( LPSTR lpszString , register int nChar )
{
    register LPSTR lpszLocalString;


    lpszLocalString = lpszString;
    while( *lpszLocalString )
    {
        lpszLocalString++;
    }

    /* Search for the desired character. */
    for(
        lpszLocalString--;
        lpszLocalString >= lpszString;
        lpszLocalString--
       )
    {
        if( (int)*lpszLocalString == nChar )
        {
            return lpszLocalString;
        }
    }

    /* Character not found. */
    return (LPSTR)NULL;

}/* lstrrchr( ) */

/* EOF */
