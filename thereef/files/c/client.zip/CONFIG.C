/* ------------------------------ CONFIG.C ---------------------------------
      Copyright (c) Spark Software Inc. 1990-1992.  All Rights Reserved.
   ------------------------------------------------------------------------- */

#include <windows.h>
#include <ddeml.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"

#define MAX_DELAY_LENGTH                4
#define MAX_TIMEOUT_LENGTH              6


PUBLIC BOOL WINAPI ConfigureDlgProc( HWND hDlg , UINT wMessage , WPARAM wParam , LPARAM lParam )
{
    BOOL         bTranslated;
    BOOL         bChecked;
    PRIVATE BYTE szSearchPath[ _MAX_PATH + 1 ];
    PRIVATE BYTE szFormat[ 256 ];
    WORD         wSearchFlags;
    WORD         wSearchInterval;
    DWORD        dwTimeout;
    LPSTR        lpszDummy1;
    LPSTR        lpszDummy2;
    struct _stat StatInfo;


    switch( wMessage )
    {
    case WM_INITDIALOG:
        /* Get the search parameters as previously set up. */
        GetSearchParms( (LPWORD)&wSearchFlags , (LPWORD)&wSearchInterval ,
            (LPSTR)szSearchPath );

        /* Set up the max. length of strings input to our   */
        /* edit controls and initialize the control values. */
        /* Search delay. */
        SendDlgItemMessage( hDlg , IDC_ET_DELAY , EM_LIMITTEXT ,
            MAX_DELAY_LENGTH , (LPARAM)0 );
        SetDlgItemInt( hDlg , IDC_ET_DELAY , wSearchInterval , FALSE );

        /* Search path. */
        SendDlgItemMessage( hDlg , IDC_ET_DIRECTORY , EM_LIMITTEXT ,
            _MAX_PATH , (LPARAM)0 );
        SetDlgItemText( hDlg , IDC_ET_DIRECTORY , (LPSTR)szSearchPath );

        /* Continuous searches checkbox. */
        if( wSearchFlags & SF_CONTINUOUS )
        {
            SendDlgItemMessage( hDlg , IDC_CB_CONTINUOUS , BM_SETCHECK ,
                1 , (LPARAM)0 );
        }
        else
        {
            /* Disallow the user from entering or editing a delay interval. */
            EnableWindow( GetDlgItem( hDlg , IDC_ST_DELAY ) , FALSE );
            EnableWindow( GetDlgItem( hDlg , IDC_ET_DELAY ) , FALSE );
        }

        /* Transmit to Program Manager checkbox. */
        if( wSearchFlags & SF_XMIT_TO_PROGMAN )
        {
            SendDlgItemMessage( hDlg , IDC_CB_XMIT_TO_PROGMAN , BM_SETCHECK ,
                1 , (LPARAM)0 );
        }

        /* Transaction timeout. */
        SendDlgItemMessage( hDlg , IDC_ET_TIMEOUT , EM_LIMITTEXT ,
            MAX_TIMEOUT_LENGTH , (LPARAM)0 );
        _ultoa( GetTransactionTimeout( ) , szString , 10 );
        SetDlgItemText( hDlg , IDC_ET_TIMEOUT , (LPSTR)szString );

        /* Server node name. */
        SendDlgItemMessage( hDlg , IDC_ET_SERVER_NODE , EM_LIMITTEXT ,
            MAX_NODE_NAME_LENGTH , (LPARAM)0 );
        SetDlgItemText( hDlg , IDC_ET_SERVER_NODE , GetServerNode( ) );
        return TRUE;

    case WM_COMMAND:
        switch( wParam )
        {
        case IDC_CB_CONTINUOUS:
            if( HIWORD( lParam ) == BN_CLICKED )
            {
                bChecked = (BOOL)SendDlgItemMessage( hDlg ,
                    IDC_CB_CONTINUOUS , BM_GETCHECK , 0 , (LPARAM)0 );
                EnableWindow( GetDlgItem( hDlg , IDC_ST_DELAY ) , bChecked );
                EnableWindow( GetDlgItem( hDlg , IDC_ET_DELAY ) , bChecked );
                return TRUE;
            }
            return FALSE;

        case IDOK:
            wSearchFlags = wSearchInterval = 0;

            /* Retrieve the new search parameters. */
            /* Continuous searches checkbox. */
            if( SendDlgItemMessage( hDlg , IDC_CB_CONTINUOUS , BM_GETCHECK ,
                0 , (LPARAM)0 ) )
            {
                wSearchFlags |= SF_CONTINUOUS;

                /* Search delay. */
                wSearchInterval = (WORD)GetDlgItemInt( hDlg , IDC_ET_DELAY ,
                    (BOOL FAR *)&bTranslated , FALSE );
                if( !bTranslated )
                {
                    /* User must supply a delay value. */
                    ErrorMsg( IDS_SUPPLY_DELAY_VALUE );
                    SetFocus( IDC_ET_DELAY );
                    return TRUE;
                }
            }

            /* Transmit to Program Manager checkbox. */
            if( SendDlgItemMessage( hDlg , IDC_CB_XMIT_TO_PROGMAN ,
                BM_GETCHECK , 0 , (LPARAM)0 ) )
            {
                wSearchFlags |= SF_XMIT_TO_PROGMAN;
            }

            /* Search path. */
            GetDlgItemText( hDlg , IDC_ET_DIRECTORY , (LPSTR)szSearchPath ,
                sizeof szSearchPath );

            if( !IsValidPath( (LPSTR)szSearchPath ,
                (LPSTR FAR *)&lpszDummy1 , (LPSTR FAR *)&lpszDummy2 ,
                (VOID FAR *)&StatInfo ) )
            {
                LoadString( hInst , IDS_INVALID_PATH , (LPSTR)szFormat ,
                    sizeof szFormat );
                wsprintf( (LPSTR)szString , (LPSTR)szFormat ,
                    (LPSTR)szSearchPath );
                MessageBox( GetFocus( ) , (LPSTR)szString , (LPSTR)szAppName ,
                    MB_OK | MB_ICONASTERISK );
                SetFocus( IDC_ET_DIRECTORY );
                return TRUE;
            }

            /* Transaction timeout. */
            if( !GetDlgItemText( hDlg , IDC_ET_TIMEOUT , (LPSTR)szString ,
                MAX_TIMEOUT_LENGTH ) )
            {
                /* User must supply a delay value. */
                ErrorMsg( IDS_SUPPLY_TIMEOUT_VALUE );
                SetFocus( IDC_ET_TIMEOUT );
                return TRUE;
            }
            sscanf( szString , "%lu" , &dwTimeout );

            /* Server node name. */
            /* NOTE: we have to save this immediately to establish */
            /* the "configure server parms" conversation.          */
            GetDlgItemText( hDlg , IDC_ET_SERVER_NODE , (LPSTR)szString ,
                MAX_NODE_NAME_LENGTH );
            SetServerNode( (LPSTR)szString );

            if( DoDDESearchConfigure( hDlg , wSearchFlags , wSearchInterval ,
                (LPSTR)szSearchPath ) )
            {
                /* Save the transaction timeout. */
                SetTransactionTimeout( dwTimeout );

                /* Set the local copy of the search parameters. */
                SetSearchParms( wSearchFlags , wSearchInterval ,
                    (LPSTR)szSearchPath );
            }
            else
            {
                /* The "configure server parms" conversation failed.   */
                /* Revert to the old server node name - the new server */
                /* node name may be incorrect.                         */
                RevertServerNode( );
            }

            /* Fall through. */

        case IDCANCEL:
            EndDialog( hDlg , NULL );
            return TRUE;
        }

        /* Unrecognized message received. */
        return FALSE;
    }

    /* Unrecognized message received. */
    return FALSE;

}/* ConfigureDlgProc( ) */

/* EOF */
