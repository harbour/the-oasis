/* --------------------------------- DDE.C ---------------------------------
      Copyright (c) Spark Software Inc. 1990-1992.  All Rights Reserved.
   ------------------------------------------------------------------------- */

#include <windows.h>
#include <commdlg.h>
#include <ddeml.h>
#include <memory.h>
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"


PRIVATE HCONV hSearchConv;
PRIVATE HSZ   hszSearchTopic;
PRIVATE HSZ   hszFindItem;


PUBLIC HDDEDATA EXPENTRY DDEClientCallback( WORD wType , WORD wFmt ,
    HCONV hConv , HSZ hsz1 , HSZ hsz2 , HDDEDATA hData ,
    DWORD dwData1 , DWORD dwData2 )
{
    WORD         wDDEMLError;
    DWORD        dwLength;
    LPSTR        lpszOurData;
    CONVINFO     ciInfo;
    HSZ          hszService;


    if( hConv )
    {
        /* Make certain that the conversation didn't die. */
        ciInfo.cb = sizeof( CONVINFO );
        if( !DdeQueryConvInfo( hConv , (DWORD)QID_SYNC , (CONVINFO FAR *)&ciInfo ) )
        {
            /* Conversation does not exist. */
            return (HDDEDATA)NULL;
        }
    }

    switch( wType )
    {
    case XTYP_ADVDATA:
        if( hData )
        {
            /* Check the topic and item. */
            if( DdeCmpStringHandles( hsz1 , hszSearchTopic ) ||
                DdeCmpStringHandles( hsz2 , hszFindItem ) )
            {
                /* Incorrect topic and/or item. */
                return (HDDEDATA)DDE_FNOTPROCESSED;
            }

            if( ( lpszOurData = DdeAccessData( hData , (LPDWORD)&dwLength ) ) )
            {
                /* Process the filename. */
                ProcessFoundFile( hWndMaster , lpszOurData );
                DdeUnaccessData( hData );
            }
            else
            {
                /* Couldn't access data. */
                return (HDDEDATA)DDE_FNOTPROCESSED;
            }
        }

        /* DDE_FACK says we processed the transaction,  */
        /* not whether or not we liked the data we got. */
        return (HDDEDATA)DDE_FACK;

    case XTYP_UNREGISTER:
        /* Create a string handle for the service. */
        hszService = DdeCreateStringHandle( dwInstID , (LPSTR)SERVER_APP_NAME ,
            CP_WINANSI );

        /* Check to see if OUR server has terminated.   */
        /* NOTE: We're not tracking multiple instances. */
        if( !DdeCmpStringHandles( hsz1 , hszService ) )
        {
            bServerTerminated = TRUE;
        }
        DdeFreeStringHandle( dwInstID , hszService );
        return (HDDEDATA)0;

    case XTYP_XACT_COMPLETE:
        /* Process the completion of an asynchronous transaction. */

        /* First, check for errors. */
        if( ( wDDEMLError = DdeGetLastError( dwInstID ) ) != DMLERR_NO_ERROR )
        {
            ErrorMsg( (UINT)wDDEMLError );
        }

#       if 0

        /* Check the topic and item. */
        if( DdeCmpStringHandles( hsz1 , hszDesiredTopic ) ||
            DdeCmpStringHandles( hsz2 , hszDesiredItem ) )
        {
            /* Incorrect topic and/or item. */
            return (HDDEDATA)NULL;
        }

#       endif

        /* We are not required to return anything */
        /* from a XTYP_XACT_COMPLETE transaction. */
        return (HDDEDATA)NULL;
    }

    return (HDDEDATA)NULL;

}/* DDEClientCallback( ) */


PUBLIC VOID PASCAL InitTopicsAndItems( VOID )
{
    /* Create string handles for the desired topics and items. */
    hszSearchTopic = DdeCreateStringHandle( dwInstID , (LPSTR)TOPIC_SEARCH ,
        CP_WINANSI );
    hszFindItem = DdeCreateStringHandle( dwInstID , (LPSTR)ITEM_FIND ,
        CP_WINANSI );

}/* InitTopicsAndItems( ) */


PUBLIC VOID PASCAL CleanupTopicsAndItems( VOID )
{
    /* Free the string handles for the desired topics and items. */
    DdeFreeStringHandle( dwInstID , hszFindItem );
    DdeFreeStringHandle( dwInstID , hszSearchTopic );

}/* CleanupTopicsAndItems( ) */


PUBLIC HCONV PASCAL BeginDDEConversation( HWND hWnd , LPSTR lpszApp , LPSTR lpszTopic , LPWORD lpwDDEMLError )
{
    HCONV    hConv;
    HSZ      hszApp, hszTopic;
    HWND     hwndConv = 0;


    /* Create string handles for the desired application and topic. */
    if( !( hszApp = DdeCreateStringHandle( dwInstID , lpszApp , CP_WINANSI ) ) ||
        !( hszTopic = DdeCreateStringHandle( dwInstID , lpszTopic , CP_WINANSI ) ) )
    {
        if( lpwDDEMLError )
        {
            /* If the strings couldn't be created, let the caller know why. */
            *lpwDDEMLError = DdeGetLastError( dwInstID );
        }
        return (HCONV)NULL;
    }

    /* Begin the conversation. */
    if( !( hConv = DdeConnect( dwInstID , hszApp , hszTopic , &ccInfo ) ) &&
        lpwDDEMLError )
    {
        /* If the conversation couldn't be started, let the caller know why. */
        *lpwDDEMLError = DdeGetLastError( dwInstID );
    }

    /* Free these string handles. */
    DdeFreeStringHandle( dwInstID , hszApp );
    DdeFreeStringHandle( dwInstID , hszTopic );
    return hConv;

}/* BeginDDEConversation( ) */


PUBLIC BOOL PASCAL EndDDEConversation( HWND hWnd , HCONV hConv ,
    LPWORD lpwDDEMLError )
{
    BOOL bStatus;


    if( !( bStatus = DdeDisconnect( hConv ) ) && lpwDDEMLError )
    {
        /* If the conversation couldn't be ended, let the caller know why. */
        *lpwDDEMLError = DdeGetLastError( dwInstID );
    }

    return bStatus;

}/* EndDDEConversation( ) */


PUBLIC HDDEDATA PASCAL DoTransaction( HWND hWnd , LPVOID lpvData ,
    DWORD dwData , HCONV hConv , HSZ hszItem , UINT wFormat , UINT wType ,
    DWORD dwTimeout , LPDWORD lpdwResult , LPWORD lpwDDEMLError )
{
    HDDEDATA hddResult;


    if( !lpdwResult && dwTimeout == TIMEOUT_ASYNC )
    {
        /* Caller must provide a legal lpdwResult for async transactions. */
        return (HDDEDATA)NULL;
    }

    /* Start the transaction. */
    hddResult = DdeClientTransaction( lpvData , dwData , hConv , hszItem ,
        wFormat , wType , dwTimeout , lpdwResult );

    if( dwTimeout == TIMEOUT_ASYNC )
    {
        if( hddResult )
        {
            /* Asynchronous transaction start successful. */
            /* Record our window handle within DDEML.      */
            DdeSetUserHandle( hConv , *lpdwResult , (DWORD)hWnd );
        }
        else
        {
            /* Asynchronous transaction start unsuccessful. */
            /* Let the caller know why.                     */
            *lpwDDEMLError = DdeGetLastError( dwInstID );
        }
    }
    else
    {
        /* Synchronous transaction completed.         */
        /* If an error occurred, get the error index. */
        *lpwDDEMLError = DdeGetLastError( dwInstID );
    }

    return hddResult;

}/* DoTransaction( ) */


PUBLIC LPSTR PASCAL DoGetData( HDDEDATA hData , LPGLOBALHANDLE lphData ,
    LPDWORD lpdwLength , BOOL bLock )
{
    DWORD dwLength;
    LPSTR lpszData;


    /* Get the length of the data, then allocate */
    /* and lock a buffer for the data.           */
    if( !lphData || !lpdwLength || !hData ||
        !( dwLength = DdeGetData( hData , (void FAR *)NULL , 0 , 0 ) ) ||
        !( *lphData = GetMem( dwLength ) ) ||
        !( lpszData = (LPSTR)LockMem( *lphData ) ) )
    {
        return (LPSTR)NULL;
    }

    /* Copy the data to the buffer. */
    *lpdwLength = DdeGetData( hData , lpszData , dwLength , 0 );
    if( !bLock )
    {
        UnlockMem( *lphData );
    }
    return lpszData;

}/* DoGetData( ) */


PUBLIC HCONV PASCAL GetSearchConvHandle( VOID )
{
    return hSearchConv;

}/* GetSearchConvHandle( ) */


PUBLIC VOID PASCAL SetSearchConvHandle( HCONV hConv )
{
    hSearchConv = hConv;

}/* SetSearchConvHandle( ) */

/* EOF */
