/* ------------------------------ BROWSE.C ---------------------------------
      Copyright (c) Spark Software Inc. 1990-1992.  All Rights Reserved.
   ------------------------------------------------------------------------- */

#include <windows.h>
#include <ddeml.h>
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"


PUBLIC BOOL WINAPI BrowseFileDlgProc( HWND hDlg , UINT wMessage , WPARAM wParam , LPARAM lParam )
{
    LPSTR            lpszFileContents;
    LPBROWSEFILEINFO lpbfInfo;


    switch( wMessage )
    {
    case WM_INITDIALOG:
        lpbfInfo = (LPBROWSEFILEINFO)lParam;
        wsprintf( (LPSTR)szString , (LPSTR)"%s (%lu bytes)" ,
            lpbfInfo->szBaseName , lpbfInfo->dwFileSize );
        SetWindowText( hDlg , (LPSTR)szString );

        if( lpbfInfo->hFileContents )
        {
            if( !( lpszFileContents = (LPSTR)LockMem( lpbfInfo->hFileContents ) ) )
            {
                /* Couldn't lock file contents buffer. */
                ErrorMsg( IDS_CANNOT_DISPLAY_FILE );
                return TRUE;
            }

            /* Display the file's contents and unlock the buffer. */
            SetDlgItemText( hDlg , IDC_ET_FILE , lpszFileContents );
            UnlockMem( lpbfInfo->hFileContents );
        }
        return TRUE;


    case WM_COMMAND:
        if( wParam == IDOK )
        {
            EndDialog( hDlg , NULL );
            return TRUE;
        }

        /* Unrecognized message received. */
        return FALSE;
    }

    /* Unrecognized message received. */
    return FALSE;

}/* BrowseFileDlgProc( ) */

/* EOF */
