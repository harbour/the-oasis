#include <stdio.h>
#include <dos.h>

int main(int argc, char *argv[])
{
    FILE *f1, *f2, *fo;
    unsigned char left, right;

    f1 = fopen(argv[1],"rb");
    f2 = fopen(argv[2],"rb");
    fo = fopen(argv[3],"wb");

    while(fread(&left,1,1,f1) != 0 && fread(&right,1,1,f2) != 0)
    {
	fwrite(&right,1,1,fo);
	fwrite(&left,1,1,fo);
    }

    fclose(fo);
    fclose(f2);
    fclose(f1);
}
