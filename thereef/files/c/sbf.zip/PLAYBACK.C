; Soundblaster .VOC file playback program Version 1.1
; Copyright (C) 1992, Heath I Hunnicutt
;
; This program is released to the public domain for non-commercial use only.
;
; Modules needed to compile: PLAYBACK.C, DMA_CODE.OBJ, SB_DSP.OBJ
;
; Contact me at: heathh@cco.caltech.edu
;

#include <dos.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <alloc.h>
#include <conio.h>
#include <string.h>

//DMA_CODE.H
extern void far dma_reset(int Channel);
extern void far dma_setup(int Channel,char far *Buffer,unsigned Length,int Dir);
extern int  far dma_done(int Channel);
//SB_DSP.H
extern void far dsp_time(int pacing);
extern void far dsp_reset(void);
extern void far dsp_dma_prepare(int Dir,unsigned Length);
extern void far dsp_voice(int Activity);
extern void far set_SB_address(int base);

typedef struct {
	char Sig[20];
	unsigned Data_Off;
	unsigned Version;
	unsigned Check;
} Voc_Header;

#define VOC_SIGNATURE "Creative Voice File\032\032"

void main()
{
	unsigned len;
	int  h;
	char far *Buf;
	char far *Aligned,*Live[2];
	unsigned Contents[2];
	int Filling,Playing;
	unsigned long physical,aligned_physical;
	Voc_Header header;
	long temp,size,type;
	int pace,compression;

	clrscr();
	Buf=farmalloc(128000l);
	if (Buf==NULL) {
		printf("Not enough free RAM.\n");
		exit(0);
	}
	physical=((unsigned long)FP_OFF(Buf)) + (((unsigned long)FP_SEG(Buf)) << 4);
	printf("Buf is %p, maps to physical 0x%05lX\n",Buf,physical);
	aligned_physical=physical+0x0FFFFL;
	aligned_physical&=0xF0000L;
	Aligned=MK_FP((unsigned )((aligned_physical >> 4) & 0xFFFF),0);
	Live[0]=Aligned;
	Live[1]=Aligned+32000U;
	printf("Alligned address is %p\n",Aligned);
	printf("[Esc] to abort, any other key to continue.\n");
	if (getch()==27)
		exit(0);
	h=_open(_argv[1],O_RDONLY);
	if (h<1) {
		printf("PLAYBACK filename.voc\n");
		exit(0);
	}
	set_SB_address(0x220);
	dsp_reset();
	dsp_voice(1);
	dma_reset(1);
	_dos_read(h,&header,sizeof(header),&len);
	if (memcmp(header.Sig,VOC_SIGNATURE,19)) {
		printf("Incorrect file format.\n");
		exit(0);
	}
	printf("\nHEADER:\n%s",header.Sig);
	printf("\nVersion: %u\nCheck: %u\n\n",header.Version,header.Check);
	lseek(h,header.Data_Off,SEEK_SET);
	_dos_read(h,&temp,4,&len);
	type=temp & 0x000000FF;
	size=temp >> 8;
	if (len!=4 || type!=1) {
		printf("Unknown/Unsupported sample type.\n");
		exit(0);
	}
	pace=compression=0;
	_dos_read(h,&pace,1,&len);
	_dos_read(h,&compression,1,&len);
	dsp_time(pace);
	printf("Pace: %d  Type: %ld  Size:%ld Compression: %d\n",pace,type,size,compression);
	if (type<=2 && compression!=0) {
		printf("Sample is compressed!\n");
		exit(0);
	}

	Contents[0]=Contents[1]=0U;
	_dos_read(h,Live[0],32000U,&Contents[0]);
	if (Contents[0])
		_dos_read(h,Live[1],32000U,&Contents[1]);
	Filling=0;
	Playing=0;
	for (;;) {
		if (!Contents[Playing])
			break;
		dma_setup(1,Live[Playing],Contents[Playing],1);
		dsp_dma_prepare(1,Contents[Playing]);
		if (Playing!=Filling) {
			_dos_read(h,Live[Filling],32000U,&Contents[Filling]);
			Filling = 1-Filling;
		}
		while (dma_done(1)!=-1)
			;
	  Playing = 1-Playing;
	}
	printf("Shutting down....dma_reset(1)..."); dma_reset(1);
	printf("dsp_reset()..."); dsp_reset();
	printf("farfree(Buf)..."); farfree(Buf);
	printf("exit(0)\n"); exit(0);
}
