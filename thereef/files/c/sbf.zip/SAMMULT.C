#include <stdio.h>

int main(int argc, char *argv[])
{
    FILE *fi, *fo;
    unsigned char ch;
    int i;

    fi = fopen(argv[1],"rb");
    fo = fopen(argv[2],"wb");

    i = 0;
    while(fread(&ch,1,1,fi) != 0)
    {
	fwrite(&ch,1,1,fo);
	if((i % 3) == 0)
	    fwrite(&ch,1,1,fo);
	i++;
    }

    fclose(fi);
    fclose(fo);
    return 0;
}
