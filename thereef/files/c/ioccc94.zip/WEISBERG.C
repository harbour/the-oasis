
main(){
	int x=3,n,m=2,*t,*a,*b=0;
	while(b?o:((*(t=b=(int*)malloc(o))=2),a=t+1,o))n=*b,n>=m?c:x%n?(int)b++:N);
}
