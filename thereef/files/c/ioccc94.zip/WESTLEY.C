#if O
main(){}
#else
























#if rop&onut&((own&rain)|warf)
#include "						  										  The orc scrambles to the drain,					          trying to get the donut; you						          run out the door and escape!							  										  	       The End								  										  "
#else
#if escribe
#if ocument
#include "						  										  It reads:								              Depress Dotted Dog							  										  "
#else
#if oor
#include "						  										  The door is decorated with relief						  figures of various dog breeds						            										  "
#else
#if rain
#include "						  										  Through the drain you see a dwarf						  in another cell							            										  "
#else
#if warf
#include "						  										  The gnarled dwarf looks thirsty					            										  "
#else
#if ungeon|ebris
#include "						  										  You notice a desk, a phone, and					          a phone directory among the clutter						  										  "
#else
#if esk
#include "						  										  There are some dimes on the desk						  										  "
#else
#if irectory
#include "						  										  It reads:								              Pixie's Pub -								      instant service -								      Dial DUNgeon0614								  										  "
#else
#include "						  										  You notice nothing unusual							  										  "
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#else
#if ial&UNgeon0614
#include "						  										  Pixie takes your order, and							  magically, the room is filled						          with banana daiquiris								  										  "
#endif
#if rink&aiquiri
#include "						  										  As you drink, a voice from						          below says 'Could you drop						          one down here?'								  										  "
#endif
#if rop&aiquiri
#if warf|own
#include "						  										  The dwarf eagerly accepts						          the drink.  'Thanks!  Here,						          I found this, but I can't							  understand it.'  He hands							  you a document								  										  "
#else
#include "						  										  You drop the drink							          on the floor									  										  "
#endif
#endif
#if epress&(almatian|almation)
#include "						  										  As you press the dalmatian						          figure, the door opens - only						          to reveal a menacing orc by							  a vending machine (with a							  sign reading 'DEPOSIT MONEY')							  										  "
#endif
#if eposit&(ime|imes)
#include "						  										  Donuts spill out; you get						          some, the orc hungrily eats						          the rest									  										  "
#endif
#if rop&onut
#include "						  										  The orc quickly eats the						          donut; he still bars the						          way										  										  "
#endif
#if rop+epress+ime+eposit+rink+aiquiri+onut==1
#include "						  										  Be more specific								  										  "
#endif
#include "						  										  You are in a debris-filled						          dungeon; a door bars the						          way, and sludge trickles into						          a floor drain									  										  "
#endif
#endif
#endif
