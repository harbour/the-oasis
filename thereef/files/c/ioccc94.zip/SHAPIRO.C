#include <stdio.h>
                        /*MLSPXPMPVPOQN
                     POPJLVMMQNQNPSPYPXLRP
                   XMTJMLSPXPMPVPOQNPOPJLVMN
                 QSPWPOPXLRPXMTJMLNPOPPPSPXPOP
                JLYPRLTPVLUPVLWPVLXPVLVPSLJLUQP
              PJQLQSPXPNQPPRLTPVL*/main(){int K/*
             PUOUPWOV*/,L/*WPVLXPVLKPUOVPWOSLU*/,M
            /*PPPPVPOQMQRPR*/=0;FILE/*TPSLUMWQT*/ *
           J/*MPRPKPLQ*/;     J=      fopen(__FILE__
          /*T*/,"r");for      (;(       L/*KPUOWOWMUQ
         LLOLMPULWLWL         WLW         LWLWLWLWLWLW
         LWLWLULVOXP          LLV          LLLOLMPULOL
        MMNP*/=getc           (J)            )!= -1;L/*
       OLWLRMMQUL             VOX             PLLVLLLMQO
       PMPYPXPNP              MQL              LVLLLWPSP
      XPOQNQOPMQ              LLV              LTj*/>='J'
     &&L/*LRPYP               OQL               QMQLLVLLL
     OLMQVOXPL                LVL                LLVOe*/<=
     'J'+15&&(                (M=                !M/*MMMQMV
     OJMMMMMU                 OOL                 NPU MPMOM
    UMRNOLMQV                 OJM                 MMMMRMLLW
    QUMTJSPX                  PNQ                  JLLPUOWO
    WMUQJMVL                  JMV                  L*/)?K/*
    MQMV*/=L:               putchar                (K/*deMN
    MaVbcLKM                  KMV                  Le*/-'J'
   /*MWQUMTJ                  WPK                  PSPXPR*/
    |(L/*PQV                  LMPSLSPXPNQ*/-       'J'<<4))
    ));exit(                  0);}/*LPQUMMPR       PKPLQJLT
    LTLJLMPU                   MTJUQMPRPKPLQ       JLNPUONM
    JMWOVLTL                                       OPVLPPWM
    PMUMTJNQ                                       SPWPOPYO
    NQJLQPUM                                       TJPNSNVN
    ONJLTLRP                                       VLTLSPUM
    TJQQRPSP                                       VPOPJLRL
    WLWLPPJLP                                     LPLJLKLJQ
     SPJQOPRL                                     NPSLJLPL
     PLJLKLPPY                                   PLQUPRLSL
     SLUMTJRPW                                   MPPNPYPJQ
      OPXPRLPMW                                 LPPVMVMKM
      VLLLKPLLSL                               UMSPWMPPNP
       YPJQOPXPR                               LRLPMWLPP
       VMVMKMSLUL                             KMVLLLLQLL
        SLUMTJPPYP                           LQRLUMUMSL
         UQSPPPRLPPS                       LUQPPQPOPNQ
         MQRLNPVLNMJM                     VLSPSLUMNPUO
          MQNQLQVPOPXPR                 LNPSLWLKMWOWM
           QLVOJMQLUMTJSP             PPRLTLNPWMWMQL
            JMQLULPPSLUQMQJQLQSPXPNQPPRLTLMPVLLLOLM
             QVOXPLLVLNPULKMSLUMYPRLMQNQNPYPOQNQVL
              PMVLPMWLPPVLNPULKMVLJMSLWQTJSPPPRLT
                LNPXMQLJMQLULPPSLYPRLRPVLOMVLNP
                 VLJMVLJMSLWQOPVPMQOPUQNQSPWPO
                   PRLPLQPSLUMOPWMKPMQMPNQSP
                     WPOPRLVPYPMPKPVPNQSPW
                        POPRLPLQPSLSLUM

TJPPYPLQRLPQWMKMUMPQVMPMUMPQULULSLYPRLRPVLPQKLWMKMPLPLPQKLWMPMWLKMVLPQ
ULQLJMQLVLKPNQYPSPRLOPULLPUOPQWOSLVLPQSLMQVPOPOPJQRLKMSLUMWQWQWQTJTJ*/

