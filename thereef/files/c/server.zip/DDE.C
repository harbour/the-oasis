/* --------------------------------- DDE.C ---------------------------------
      Copyright (c) Spark Software Inc. 1990-1992.  All Rights Reserved.
   ------------------------------------------------------------------------- */

#include <windows.h>
#include <commdlg.h>
#include <ddeml.h>
#include <string.h>
#include <memory.h>
#include <stdlib.h>
#include <ctype.h>
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"

#define DDE_STATUS_READY        "Ready"
#define DDE_STATUS_BUSY         "Busy"


PRIVATE BOOL     PASCAL   CheckTopicAndFormat( HSZ hszTopic , WORD wFmt );
PRIVATE BOOL     PASCAL   IsMatchingConvContext( PCONVCONTEXT pccInfo );
PRIVATE HDDEDATA CALLBACK SATopics( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms );
PRIVATE HDDEDATA CALLBACK SAItems( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms );
PRIVATE HDDEDATA CALLBACK SARtnMsg( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms );
PRIVATE HDDEDATA CALLBACK SAStatus( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms );
PRIVATE HDDEDATA CALLBACK SAFormats( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms );
PRIVATE HDDEDATA CALLBACK SAHelp( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms );
PRIVATE HDDEDATA CALLBACK SAConfigure( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms );
PRIVATE HDDEDATA CALLBACK SAFind( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms );

PRIVATE ITEMINFO SystemTopicItems[ ] =
{
    { (LPSTR)SZDDESYS_ITEM_TOPICS   , (HSZ)NULL , SATopics             } ,
    { (LPSTR)SZDDESYS_ITEM_SYSITEMS , (HSZ)NULL , SAItems              } ,
    { (LPSTR)SZDDESYS_ITEM_RTNMSG   , (HSZ)NULL , SARtnMsg             } ,
    { (LPSTR)SZDDESYS_ITEM_STATUS   , (HSZ)NULL , SAStatus             } ,
    { (LPSTR)SZDDESYS_ITEM_FORMATS  , (HSZ)NULL , SAFormats            } ,
    { (LPSTR)SZDDESYS_ITEM_HELP     , (HSZ)NULL , SAHelp               } ,
    { (LPSTR)NULL                   , (HSZ)NULL , (LPSERVERACTION)NULL }
};
#define NUM_SYSTEM_TOPIC_ITEMS  ( ( sizeof( SystemTopicItems ) / sizeof ITEMINFO ) - 1 )

PRIVATE ITEMINFO SearchTopicItems[ ] =
{
    { (LPSTR)SZDDE_ITEM_ITEMLIST    , (HSZ)NULL , SAItems              } ,
    { (LPSTR)ITEM_CONFIGURE         , (HSZ)NULL , SAConfigure          } ,
    { (LPSTR)ITEM_FIND              , (HSZ)NULL , SAFind               } ,
    { (LPSTR)NULL                   , (HSZ)NULL , (LPSERVERACTION)NULL }
};
#define NUM_SEARCH_TOPIC_ITEMS  ( ( sizeof( SearchTopicItems ) / sizeof ITEMINFO ) - 1 )
#define TOTAL_TOPICS            ( NUM_SYSTEM_TOPIC_ITEMS + NUM_SEARCH_TOPIC_ITEMS )

PRIVATE TOPICINFO Topics[ ] =
{
    { (LPSTR)SZDDESYS_TOPIC , (HSZ)NULL , (LPITEMINFO)SystemTopicItems } ,
    { (LPSTR)TOPIC_SEARCH   , (HSZ)NULL , (LPITEMINFO)SearchTopicItems } ,
    { (LPSTR)NULL           , (HSZ)NULL , (LPITEMINFO)NULL             }
};
#define NUM_TOPICS              ( ( sizeof( Topics ) / sizeof TOPICINFO ) - 1 )

PRIVATE UINT Formats[ ] = { CF_TEXT , 0 };
PRIVATE BYTE szHelpTextFormat[ ] =
    "The supported topics are:\r\n"
    "%s: Generic DDE server services.\r\n"
    "%s: Text search services.\r\n"
    "\n"
    "The supported %s items are:\r\n"
    "%s: Get a topic list.\r\n"
    "%s: Get an item list for this topic.\r\n"
    "%s: Get info about the last WM_DDE_ACK sent.\r\n"
    "%s: Get server status.\r\n"
    "%s: Get a format list.\r\n"
    "%s: Get help info (print this message).\r\n"
    "\n"
    "The supported %s items are:\r\n"
    "%s: Get an item list for this topic.\r\n"
    "%s: Set search config parms.\r\n"
    "%s: Search files for a given string.\r\n"
    ;

PRIVATE BYTE szRtnMsg[ 0x0100 ];


PUBLIC HDDEDATA EXPENTRY DDEServerCallback( WORD wType , WORD wFmt ,
    HCONV hConv , HSZ hsz1 , HSZ hsz2 , HDDEDATA hData ,
    DWORD dwData1 , DWORD dwData2 )
{
    WORD         wHSZPairOffset;
    DWORD        dwHSZPairSize;
    LPITEMINFO   lpItemInfo;
    LPTOPICINFO  lpTopicInfo;
    LPVOID       lpExtraParms;
    HSZ          hszSysTopic;
    HSZ          hszTopicsItem;
    HSZPAIR      hszPair;
    HDDEDATA     hddResult;


    /* Only allow conversations using supported topics and formats. */
    if( !CheckTopicAndFormat( hsz1 , wFmt ) )
    {
        return (HDDEDATA)NULL;
    }

    /* Within this switch, we're going to handle connects, wildconnects */
    /* and errors completely.  All other transactions of interest will  */
    /* be prepared for handling by an appropriate helper function if    */
    /* such preparation is necessary.                                   */
    lpExtraParms = (LPVOID)NULL;
    switch( wType )
    {
    case XTYP_CONNECT:
        /* Allow the connection if the conversation context matches ours. */
        return (HDDEDATA)IsMatchingConvContext( (PCONVCONTEXT)dwData1 );

    case XTYP_WILDCONNECT:
        /* If the item is NOT our service name, deny the connection. */
        if( hsz2 && DdeCmpStringHandles( hsz2 , hszAppName ) )
        {
            return (HDDEDATA)NULL;
        }

        /* Allow the connection if the conversation context matches ours. */
        if( !IsMatchingConvContext( (PCONVCONTEXT)dwData1 ) )
        {
            return (HDDEDATA)NULL;
        }

        /* Get a buffer for one service/topic string handle pair. */
        dwHSZPairSize = (DWORD)sizeof( HSZPAIR );
        if( !( hddResult = DdeCreateDataHandle( dwInstID , (LPVOID)NULL ,
            dwHSZPairSize , (DWORD)0 , (HSZ)NULL , wFmt , 0 ) ) )
        {
            return (HDDEDATA)NULL;
        }

        /* Record the pairs and expand the buffer as needed. */
        for(
            lpTopicInfo = (LPTOPICINFO)Topics , wHSZPairOffset = 0;
            lpTopicInfo->lpItemInfo;
            lpTopicInfo++
           )
        {
            if( !hsz1 || !DdeCmpStringHandles( hsz1 , lpTopicInfo->hszTopic ) )
            {
                hszPair.hszSvc   = hszAppName;
                hszPair.hszTopic = lpTopicInfo->hszTopic;

                if( !( hddResult = DdeAddData( hddResult , (LPVOID)&hszPair ,
                    dwHSZPairSize , dwHSZPairSize * wHSZPairOffset ) ) )
                {
                    return (HDDEDATA)NULL;
                }
                wHSZPairOffset++;
            }
        }

        /* NULL terminate the array and return the handle. */
        hszPair.hszSvc   = (HSZ)NULL;
        hszPair.hszTopic = (HSZ)NULL;
        return DdeAddData( hddResult , (LPVOID)&hszPair ,
            dwHSZPairSize , dwHSZPairSize * wHSZPairOffset );

    case XTYP_ERROR:
        /* Clean up all our unfinished business and exit. */
        ErrorMsg( DMLERR_SYS_ERROR );
        DdeAbandonTransaction( dwInstID , (HCONV)NULL , 0 );
        SendMessage( hWndMaster , WM_CLOSE , 0 , (LPARAM)0 );
        return (HDDEDATA)NULL;

    case XTYP_REQUEST:
        /* If the request is for the system topic and topics item, */
        /* let the server action function know that it shouldn't   */
        /* include the system topic itself in the list.            */
        /* This is just an example of how the    */
        /* lpExtraParms parameter might be used. */
        hszSysTopic = DdeCreateStringHandle( dwInstID ,
            (LPSTR)SZDDESYS_TOPIC , CP_WINANSI );
        hszTopicsItem = DdeCreateStringHandle( dwInstID ,
            (LPSTR)SZDDESYS_ITEM_TOPICS , CP_WINANSI );
        if( !DdeCmpStringHandles( hszSysTopic , hsz1 ) &&
            !DdeCmpStringHandles( hszTopicsItem , hsz2 ) )
        {
            lpExtraParms = (LPVOID)SZDDESYS_TOPIC;
        }

        DdeFreeStringHandle( dwInstID , hszTopicsItem );
        DdeFreeStringHandle( dwInstID , hszSysTopic );
        break;
    }

    /* Look up the requested topic. */
    for(
        lpTopicInfo = (LPTOPICINFO)Topics;
        lpTopicInfo->lpItemInfo;
        lpTopicInfo++
       )
    {
        /* Is this the requested topic? */
        if( !DdeCmpStringHandles( lpTopicInfo->hszTopic , hsz1 ) )
        {
            /* Look up the requested item. */
            for(
                lpItemInfo = lpTopicInfo->lpItemInfo;
                lpItemInfo->lpServerAction;
                lpItemInfo++
               )
            {
                /* Is this the requested item? */
                if( !DdeCmpStringHandles( lpItemInfo->hszItem , hsz2 ) )
                {
                    /* Call the helper function for this topic and item. */
                    hddResult = (*lpItemInfo->lpServerAction)( wType ,
                        wFmt , hConv , hsz1 , hsz2 , hData ,
                        dwData1 , dwData2 , lpExtraParms );

                    /* Return the correct value according */
                    /* to the transaction type.           */
                    switch( wType & XCLASS_MASK )
                    {
                    case XCLASS_BOOL:
                        return hddResult ? (HDDEDATA)TRUE : (HDDEDATA)FALSE;

                    case XCLASS_FLAGS:
                        return hddResult ? (HDDEDATA)DDE_FACK :
                            (HDDEDATA)DDE_FNOTPROCESSED;

                    case XCLASS_DATA:
                        return hddResult;
                    }

                    return (HDDEDATA)NULL;
                }
            }
        }
    }

    return (HDDEDATA)NULL;

}/* DDEServerCallback( ) */


PRIVATE BOOL PASCAL CheckTopicAndFormat( HSZ hszTopic , WORD wFmt )
{
    LPUINT       lpwFormat;
    LPTOPICINFO  lpTopicInfo;


    /* Topic may be NULL if this call results from a wildconnect transaction. */
    if( hszTopic )
    {
        /* Loop until we match the topic or finish looking at all topics. */
        for(
            lpTopicInfo = (LPTOPICINFO)Topics;
            DdeCmpStringHandles( lpTopicInfo->hszTopic , hszTopic );
            lpTopicInfo++
           )
        {
            if( !lpTopicInfo->lpItemInfo )
            {
                /* Unsupported topic. */
                return FALSE;
            }
        }
    }

    if( wFmt )
    {
        /* Loop until we match the format or finish looking at all formats. */
        for( lpwFormat = Formats; *lpwFormat != wFmt; lpwFormat++ )
        {
            if( !*lpwFormat )
            {
                /* Unsupported format. */
                return FALSE;
            }
        }
    }
    return TRUE;

}/* CheckTopicAndFormat( ) */


PRIVATE BOOL PASCAL IsMatchingConvContext( PCONVCONTEXT pccInfo )
{
    /* If the client is a non-DDEML DDE client, the server isn't   */
    /* using a security code and the standard code page is in use, */
    /* permit the connection.                                      */
    if( !pccInfo && !ccInfo.dwSecurity && ccInfo.iCodePage == CP_WINANSI )
    {
        return TRUE;
    }

    /* If the client is a DDEML DDE client, the server's conversation */
    /* context flags, codepage and security code match those of the   */
    /* client, permit the connection.                                 */
    if( pccInfo && pccInfo->wFlags == ccInfo.wFlags &&
        pccInfo->iCodePage == ccInfo.iCodePage &&
        pccInfo->dwSecurity == ccInfo.dwSecurity )
    {
        return TRUE;
    }

    /* Something didn't match; deny the connection. */
    return FALSE;

}/* IsMatchingConvContext( ) */


PUBLIC VOID PASCAL InitTopicsAndItems( VOID )
{
    register LPITEMINFO  lpItemInfo;
    register LPTOPICINFO lpTopicInfo;


    /* Create a string handle for the name of this server. */
    hszAppName = DdeCreateStringHandle( dwInstID , (LPSTR)szAppName ,
        CP_WINANSI );

    /* Create the topic and item handles used for advise loops. */
    hszSearchTopic = DdeCreateStringHandle( dwInstID , (LPSTR)TOPIC_SEARCH ,
        CP_WINANSI );
    hszFindItem  = DdeCreateStringHandle( dwInstID , (LPSTR)ITEM_FIND ,
        CP_WINANSI );

    /* Create string handles for all topics */
    /* and items supported by this server.  */
    for(
        lpTopicInfo = (LPTOPICINFO)Topics;
        lpTopicInfo->lpItemInfo;
        lpTopicInfo++
       )
    {
        /* Create this topic handle. */
        lpTopicInfo->hszTopic = DdeCreateStringHandle( dwInstID ,
            lpTopicInfo->lpszTopic , CP_WINANSI );

        for(
            lpItemInfo = lpTopicInfo->lpItemInfo;
            lpItemInfo->lpServerAction;
            lpItemInfo++
           )
        {
            /* Create this item handle. */
            lpItemInfo->hszItem = DdeCreateStringHandle( dwInstID ,
                lpItemInfo->lpszItem , CP_WINANSI );
        }
    }

}/* InitTopicsAndItems( ) */


PUBLIC VOID PASCAL CleanupTopicsAndItems( VOID )
{
    register LPITEMINFO  lpItemInfo;
    register LPTOPICINFO lpTopicInfo;


    /* Free string handles for all topics  */
    /* and items supported by this server. */
    for(
        lpTopicInfo = (LPTOPICINFO)Topics;
        lpTopicInfo->lpItemInfo;
        lpTopicInfo++
       )
    {
        /* Free this topic handle. */
        DdeFreeStringHandle( dwInstID , lpTopicInfo->hszTopic );

        for(
            lpItemInfo = lpTopicInfo->lpItemInfo;
            lpItemInfo->lpServerAction;
            lpItemInfo++
           )
        {
            /* Free this item handle. */
            DdeFreeStringHandle( dwInstID , lpItemInfo->hszItem );
        }
    }

    /* Free the topic and item handles used for advise loops. */
    DdeFreeStringHandle( dwInstID , hszFindItem );
    DdeFreeStringHandle( dwInstID , hszSearchTopic );

    /* Free the string handle for the name of this server. */
    DdeFreeStringHandle( dwInstID , hszAppName );

}/* CleanupTopicsAndItems( ) */


PRIVATE HDDEDATA CALLBACK SATopics( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms )
{
    DWORD       dwLength;
    DWORD       dwOffset;
    HDDEDATA    hddResult;
    LPTOPICINFO lpTopicInfo;


    /* We're only interested in XTYP_REQUEST transactions. */
    if( wType != XTYP_REQUEST )
    {
        return (HDDEDATA)NULL;
    }

    /* Get a buffer for our topics. */
    if( !( hddResult = DdeCreateDataHandle( dwInstID , (LPVOID)NULL ,
        (DWORD)1 , (DWORD)0 , hsz2 , wFmt , 0 ) ) )
    {
        return (HDDEDATA)NULL;
    }

    /* Record the topics and expand the buffer as needed. */
    for(
        lpTopicInfo = (LPTOPICINFO)Topics , dwOffset = 0;
        lpTopicInfo->lpItemInfo;
        lpTopicInfo++
       )
    {
        /* Don't copy the system topic to the list. */
        if( lstrcmp( lpTopicInfo->lpszTopic , (LPSTR)lpExtraParms ) )
        {
            /* Copy the string and a trailing tab to the buffer. */
            dwLength = (DWORD)lstrlen( lpTopicInfo->lpszTopic );
            if( !( hddResult = DdeAddData( hddResult ,
                    (LPVOID)lpTopicInfo->lpszTopic , dwLength , dwOffset ) ) ||
                !( hddResult = DdeAddData( hddResult ,
                    (LPVOID)"\t" , 1 , ( dwOffset += dwLength ) ) ) )
            {
                return (HDDEDATA)NULL;
            }

            /* Point at the byte just past the tab. */
            dwOffset++;
        }
    }

    /* Null terminate the list (at the last tab) and return the handle. */
    return DdeAddData( hddResult , (LPVOID)"\0" , 1 , --dwOffset );

}/* SATopics( ) */


PRIVATE HDDEDATA CALLBACK SAItems( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms )
{
    DWORD       dwLength;
    DWORD       dwOffset;
    HDDEDATA    hddResult;
    LPTOPICINFO lpTopicInfo;
    LPITEMINFO  lpItemInfo;


    /* We're only interested in XTYP_REQUEST transactions. */
    if( wType != XTYP_REQUEST )
    {
        return (HDDEDATA)NULL;
    }

    /* Get the topic of interest. */
    for(
        lpTopicInfo = (LPTOPICINFO)Topics;
        DdeCmpStringHandles( lpTopicInfo->hszTopic , hsz1 );
        lpTopicInfo++
       )
    {
        if( !lpTopicInfo->lpItemInfo )
        {
            /* Topic not found. */
            return (HDDEDATA)NULL;
        }
    }

    /* Get a buffer for our items. */
    if( !( hddResult = DdeCreateDataHandle( dwInstID , (LPVOID)NULL ,
        (DWORD)1 , (DWORD)0 , hsz2 , wFmt , 0 ) ) )
    {
        return (HDDEDATA)NULL;
    }

    /* Record the items and expand the buffer as needed. */
    for(
        lpItemInfo = lpTopicInfo->lpItemInfo , dwOffset = 0;
        lpItemInfo->lpServerAction;
        lpItemInfo++
       )
    {
        /* Copy the string and a trailing tab to the buffer. */
        dwLength = (DWORD)lstrlen( lpItemInfo->lpszItem );
        if( !( hddResult = DdeAddData( hddResult ,
                (LPVOID)lpItemInfo->lpszItem , dwLength , dwOffset ) ) ||
            !( hddResult = DdeAddData( hddResult ,
                (LPVOID)"\t" , 1 , ( dwOffset += dwLength ) ) ) )
        {
            return (HDDEDATA)NULL;
        }

        /* Point at the byte just past the tab. */
        dwOffset++;
    }

    /* Null terminate the list (at the last tab) and return the handle. */
    return DdeAddData( hddResult , (LPVOID)"\0" , 1 , --dwOffset );

}/* SAItems( ) */


PRIVATE HDDEDATA CALLBACK SARtnMsg( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms )
{
    /* We're only interested in XTYP_REQUEST transactions. */
    if( wType != XTYP_REQUEST )
    {
        return (HDDEDATA)NULL;
    }

    /* Return a buffer containing info about the last */
    /* WM_DDE_ACK that the DDEML sent on our behalf.  */
    return DdeCreateDataHandle( dwInstID , (LPSTR)szRtnMsg ,
        (DWORD)strlen( szRtnMsg ) + 1 , (DWORD)0 , hsz2 , wFmt , 0 );

}/* SARtnMsg( ) */


PRIVATE HDDEDATA CALLBACK SAStatus( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms )
{
    LPSTR lpszDDEStatus;


    /* We're only interested in XTYP_REQUEST transactions. */
    if( wType != XTYP_REQUEST )
    {
        return (HDDEDATA)NULL;
    }

    /* Return a buffer containing the server status. */
    /* We're not doing anything fancy here, so we'll */
    /* just say we're always ready for action.       */
    lpszDDEStatus = DDE_STATUS_READY;
    return DdeCreateDataHandle( dwInstID , lpszDDEStatus ,
        (DWORD)lstrlen( lpszDDEStatus ) + 1 , (DWORD)0 , hsz2 , wFmt , 0 );

}/* SAStatus( ) */


PRIVATE HDDEDATA CALLBACK SAFormats( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms )
{
    LPUINT lpwFormat;


    /* We're only interested in XTYP_REQUEST transactions. */
    if( wType != XTYP_REQUEST )
    {
        return (HDDEDATA)NULL;
    }

    /* Record the formats and expand the buffer as needed. */
    lpwFormat = Formats;
    wsprintf( (LPSTR)szString , (LPSTR)"%u" , *lpwFormat );
    for( lpwFormat++; *lpwFormat; lpwFormat++ )
    {
        wsprintf( (LPSTR)szString + strlen( szString ) ,
            (LPSTR)"\t%u" , *lpwFormat );
    }

    /* Create a buffer for our formats. */
    return DdeCreateDataHandle( dwInstID , (LPVOID)szString ,
        (DWORD)strlen( szString ) + 1 , (DWORD)0 , hsz2 , wFmt , 0 );

}/* SAFormats( ) */


PRIVATE HDDEDATA CALLBACK SAHelp( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms )
{
    /* We're only interested in XTYP_REQUEST transactions. */
    if( wType != XTYP_REQUEST )
    {
        return (HDDEDATA)NULL;
    }

    /* Return a buffer containing our help text. */
    wsprintf( (LPSTR)szString , (LPSTR)szHelpTextFormat ,
        (LPSTR)SZDDESYS_TOPIC , (LPSTR)TOPIC_SEARCH   ,
        (LPSTR)SZDDESYS_TOPIC ,
        (LPSTR)SZDDESYS_ITEM_TOPICS , (LPSTR)SZDDESYS_ITEM_SYSITEMS ,
        (LPSTR)SZDDESYS_ITEM_RTNMSG , (LPSTR)SZDDESYS_ITEM_STATUS ,
        (LPSTR)SZDDESYS_ITEM_FORMATS , (LPSTR)SZDDESYS_ITEM_HELP ,
        (LPSTR)TOPIC_SEARCH   ,
        (LPSTR)SZDDE_ITEM_ITEMLIST , (LPSTR)ITEM_CONFIGURE ,
        (LPSTR)ITEM_FIND );
    return DdeCreateDataHandle( dwInstID , (LPSTR)szString ,
        (DWORD)strlen( szString ) + 1 , (DWORD)0 , hsz2 , wFmt , 0 );

}/* SAHelp( ) */


PRIVATE HDDEDATA CALLBACK SAConfigure( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms )
{
    WORD wSearchFlags;
    WORD wSearchDelay;


    /* We're only interested in XTYP_POKE transactions. */
    if( wType != XTYP_POKE )
    {
        return (HDDEDATA)NULL;
    }

    /* Get the search parameters from the client data. */
    if( DdeGetData( hData , (VOID FAR *)NULL , 0 , 0 ) !=
        DdeGetData( hData , (VOID FAR *)szString , sizeof szString , 0 ) )
    {
        return (HDDEDATA)NULL;
    }

    wSearchFlags = (WORD)atoi( strtok( szString , " " ) );
    wSearchDelay = (WORD)atoi( strtok( (char *)NULL , " " ) );

    /* Reset the search engine. */
    ResetSearch( RS_ALL );

    /* Store the configuration info. */
    return (HDDEDATA)SetSearchInfo( wSearchFlags , wSearchDelay ,
        (LPSTR)strtok( (char *)NULL , " " ) );

}/* SAConfigure( ) */


PRIVATE HDDEDATA CALLBACK SAFind( UINT wType , UINT wFmt , HCONV hConv ,
    HSZ hsz1 , HSZ hsz2 , HDDEDATA hData , DWORD dwData1 , DWORD dwData2 ,
    LPVOID lpExtraParms )
{
    LPSTR lpszFoundFileName;


    /* We're only interested in XTYP_ADVSTART, XTYP_POKE, */
    /* XTYP_ADVSTOP and XTYP_ADVREQ transactions.         */
    switch( wType )
    {
    case XTYP_ADVSTART:
    case XTYP_ADVSTOP:
        return (HDDEDATA)1;

    case XTYP_POKE:
        /* Get the search text from the client data. */
        if( DdeGetData( hData , (VOID FAR *)NULL , 0 , 0 ) !=
            DdeGetData( hData , (VOID FAR *)szString , sizeof szString , 0 ) )
        {
            return (HDDEDATA)NULL;
        }

        /* Set the string we're looking for. */
        if( SetSearchString( hConv , (LPSTR)szString ) )
        {
            /* Start up this search. */
            InitSearch( hsz1 , hsz2 );
            return (HDDEDATA)1;
        }

        /* Could not set the search string. */
        return (HDDEDATA)0;

    case XTYP_ADVREQ:
        /* Send the complete pathname of the found file to the client. */
        if( !( lpszFoundFileName = GetFoundFileName( hConv ) ) )
        {
            return (HDDEDATA)NULL;
        }

        /* Return a data handle for the found file name. */
        return DdeCreateDataHandle( dwInstID , (LPVOID)lpszFoundFileName ,
            lstrlen( lpszFoundFileName ) + 1 , (DWORD)0 , hsz2 , CF_TEXT , 0 );
    }

    return (HDDEDATA)NULL;

}/* SAFind( ) */

/* EOF */
