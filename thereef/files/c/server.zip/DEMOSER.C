/* ----------------------------- DEMOSER.C ---------------------------------
      Copyright (c) Spark Software Inc. 1990-1992.  All Rights Reserved.
   ------------------------------------------------------------------------- */

#define STRICT
#include <windows.h>
#include <commdlg.h>
#include <ddeml.h>
#include <string.h>
#define  PUBLIC
#define  INITMODULE
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"
#undef   INITMODULE

#define MASTER_WIN_WIDTH    300
#define MASTER_WIN_HEIGHT   200
#define MAX_MESSAGES        120
#define DEFAULT_MESSAGES    8
#define MESSAGE_INTERVAL    500 // in milliseconds - 1/2 second.


PRIVATE VOID    PASCAL Cleanup( VOID );
PRIVATE BOOL    PASCAL InitApp( VOID );
PRIVATE BOOL    PASCAL InitInstance( LPSTR lpszCmdLine , int nCmdShow );
PRIVATE LRESULT PASCAL DoCommand( HWND hWnd , WPARAM wParam , LPARAM lParam );
PRIVATE LRESULT PASCAL DoDestroy( HWND hWnd );
PRIVATE LRESULT PASCAL DoFileFound( HWND hWnd , WPARAM wParam , LPARAM lParam );

PRIVATE GLOBALHANDLE   hFileContents;


PUBLIC int PASCAL WinMain( HINSTANCE hInstance , HINSTANCE hPrevInstance , LPSTR lpszCmdLine , int nCmdShow )
{
    DWORD dwTime;
    MSG   Msg;


    /* Initialize the application. */
    hInst = hInstance;
    if( !InitApp( ) || !InitInstance( lpszCmdLine , nCmdShow ) )
    {
        Cleanup( );
        ErrorMsg( IDS_CANT_INITIALIZE_APP );
        return -1;
    }

    /* Implement a message loop that returns control */
    /* to us after the queue is processed.           */
    dwTime = GetTickCount( );
    while( TRUE )
    {
        while( PeekMessage( (LPMSG)&Msg , NULL , 0 , 0 , PM_REMOVE ) )
        {
            if( Msg.message == WM_QUIT )
            {
                Cleanup( );
                return (int)Msg.wParam;
            }

            TranslateMessage( (LPMSG)&Msg );
            DispatchMessage(  (LPMSG)&Msg );
        }

        /* See if it's the right time to execute a search. */
        if( GetTickCount( ) > dwTime + MESSAGE_INTERVAL )
        {
            /* Execute a piece of a text search. */
            DoSearch( );

            /* Get the current time. */
            dwTime = GetTickCount( );
        }
    }

}/* WinMain( ) */


PRIVATE BOOL PASCAL InitApp( VOID )
{
    HWND     hPrevAppInstWnd;
    WNDCLASS wcInfo;


    /* We must be running in a non-real mode to use DDEML. */
    if( !( GetWinFlags( ) & WF_PMODE ) )
    {
        /* Sorry, this must be Windows 3.0 in real mode.  Bye bye. */
        return FALSE;
    }

    if( ( hPrevAppInstWnd = FindWindow( (LPSTR)szClass , (LPSTR)NULL ) ) )
    {
        /* Classes already registered by a previous instance. */
        /* Make sure we can see this app. instance. */
        ShowWindow( hPrevAppInstWnd , SW_SHOW );
        return TRUE;
    }

    /* Register the master window class. */
    wcInfo.style         = CS_VREDRAW | CS_HREDRAW;
    wcInfo.lpfnWndProc   = WndProc;
    wcInfo.cbClsExtra    = 0;
    wcInfo.cbWndExtra    = 0;
    wcInfo.hInstance     = hInst;
    wcInfo.hIcon         = LoadIcon( hInst , MAKEINTRESOURCE( APP_ICON ) );
    wcInfo.hCursor       = LoadCursor( (HINSTANCE)NULL , IDC_ARROW );
    wcInfo.hbrBackground = (HBRUSH)GetStockObject( WHITE_BRUSH );
    wcInfo.lpszMenuName  = MAKEINTRESOURCE( APP_MENU );
    wcInfo.lpszClassName = (LPSTR)szClass;

    return RegisterClass( (LPWNDCLASS)&wcInfo );

}/* InitApp( ) */


PRIVATE BOOL PASCAL InitInstance( LPSTR lpszCmdLine , int nCmdShow )
{
    BOOL         bQueueOK;
    register int nIndex;


    /* Get as large a message queue as possible. */
    for(
        nIndex = MAX_MESSAGES , bQueueOK = FALSE;
        nIndex > DEFAULT_MESSAGES && !bQueueOK;
        nIndex--
       )
    {
        bQueueOK = SetMessageQueue( nIndex );
    }

    if( !bQueueOK )
    {
        /* Couldn't expand message queue. */
        return FALSE;
    }

    /* Initialize the DDE Management Library. */
    if( DdeInitialize( &dwInstID ,
        (PFNCALLBACK)MakeProcInstance( (FARPROC)DDEServerCallback , hInst ) ,
        APPCMD_FILTERINITS , 0L ) )
    {
        return FALSE;
    }
    ccInfo.iCodePage = CP_WINANSI;

    /* Create our string handles. */
    InitTopicsAndItems( );

    /* Get a buffer into which file chunks will be read. */
    /* NOTE: the "+ 1" is for a terminating null.        */
    if( !( hFileContents = GetMem( CHUNK_LENGTH + 1 ) ) )
    {
        /* Couldn't allocate file contents buffer. */
        /* Display an error message and terminate. */
        ErrorMsg( IDS_CANNOT_ALLOCATE_MEMORY );
        return FALSE;
    }

    /* Lock the I/O buffer. */
    if( !( lpszFileContents = (LPSTR)LockMem( hFileContents ) ) )
    {
        /* Memory lock failed. */
        /* Display an error message and terminate. */
        FreeMem( hFileContents );
        ErrorMsg( IDS_CANNOT_LOCK_MEMORY );
        return FALSE;
    }

    /* Register our service name. */
    DdeNameService( dwInstID , hszAppName , (HSZ)NULL , DNS_REGISTER );

    /* Create the master window. */
    hWndMaster = CreateWindow
    (
        (LPSTR)szClass     ,
        (LPSTR)szAppName   ,
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN ,
        CW_USEDEFAULT      ,
        0                  ,
        MASTER_WIN_WIDTH   ,
        MASTER_WIN_HEIGHT  ,
        (HWND)NULL         ,
        (HMENU)NULL        ,
        hInst              ,
        (LPSTR)NULL
    );

    if( !hWndMaster )
    {
        /* Couldn't create a window.               */
        /* Display an error message and terminate. */
        FreeMem( hFileContents );
        ErrorMsg( IDS_CANNOT_CREATE_WIN );
        return FALSE;
    }

    /* Show the window. */
    ShowWindow( hWndMaster , nCmdShow );
    UpdateWindow( hWndMaster );
    return TRUE;

}/* InitInstance( ) */


PRIVATE VOID PASCAL Cleanup( VOID )
{
    /* Unregister our service name and clean up. */
    DdeNameService( dwInstID , (HSZ)NULL , (HSZ)NULL , DNS_UNREGISTER );

    if( hFileContents )
    {
        UnlockMem( hFileContents );
        FreeMem( hFileContents );
    }

    FreeFoundFileNameBuffer( );

    /* Free needed string handles. */
    CleanupTopicsAndItems( );

    /* Uninitialize the DDEML. */
    DdeUninitialize( dwInstID );

}/* Cleanup( ) */


PUBLIC LRESULT WINAPI WndProc( HWND hWnd , UINT wMessage , WPARAM wParam , LPARAM lParam )
{
    switch( wMessage )
    {
    case WM_DESTROY:    return DoDestroy( hWnd );
    case WM_COMMAND:    return DoCommand( hWnd , wParam , lParam );
    default:            return DefWindowProc( hWnd , wMessage , wParam ,
                            lParam );
    }

}/* WndProc( ) */


PRIVATE LRESULT PASCAL DoDestroy( HWND hWnd )
{
    /* Say Goodbye to Hollywood. */
    PostQuitMessage( wExitStatus );
    return (LRESULT)1;

}/* DoDestroy( ) */


PRIVATE LRESULT PASCAL DoCommand( HWND hWnd , WPARAM wParam , LPARAM lParam )
{
    switch( wParam )
    {
    case IDM_ABOUT:
        /* Display the About dialog. */
        DO_DIALOG( AboutDlgProc , DLG_ABOUT , hInst , hWnd , (LPARAM)NULL );
        return (LRESULT)1;
    }

    return (LRESULT)0;

}/* DoCommand( ) */


PUBLIC VOID ErrorMsg( UINT wErrorMsgIndex )
{
    if( !LoadString( hInst , wErrorMsgIndex , (LPSTR)szString , sizeof szString ) )
    {
        LoadString( hInst , IDS_UNKNOWN_ERROR , (LPSTR)szString , sizeof szString );
    }

    MessageBox( GetFocus( ) , (LPSTR)szString , (LPSTR)szAppName , MB_OK | MB_ICONEXCLAMATION );

}/* ErrorMsg( ) */

/* EOF */
