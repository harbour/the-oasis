/* ---------------------------- STRING.C  ----------------------------------
        Copyright (c) Spark Software Inc. 1989-91.  All rights reserved.
   ------------------------------------------------------------------------- */

#include <windows.h>
#include <ddeml.h>
#include <ctype.h>
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"


PUBLIC int PASCAL lstrnicmp( LPSTR lpsz1 , LPSTR lpsz2 , WORD wCount )
{
    while( *lpsz1 && *lpsz2 && wCount )
    {
        if( tolower( *lpsz1 ) != tolower( *lpsz2 ) )
        {
            break;
        }

        lpsz1++ , lpsz2++ , wCount--;
    }

    if( !wCount )
    {
        return 0;
    }
    return tolower( *lpsz1 ) - tolower( *lpsz2 );

}/* lstrnicmp( ) */


PUBLIC LPSTR PASCAL lstristr( LPSTR lpszLeft , LPSTR lpszRight )
{
    register WORD wCount;


    for( wCount = lstrlen( (LPSTR)lpszRight ); *lpszLeft; lpszLeft++ )
    {
        if( !lstrnicmp( lpszLeft , lpszRight , wCount ) )
        {
            return lpszLeft;
        }
    }

    return (LPSTR)NULL;

}/* lstristr( ) */

/* EOF */
