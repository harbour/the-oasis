/* -------------------------------- FIND.C ---------------------------------
      Copyright (c) Spark Software Inc. 1990-1992.  All Rights Reserved.
   ------------------------------------------------------------------------- */

#include <windows.h>
#include <commdlg.h>
#include <ddeml.h>
#include <string.h>
#include <memory.h>
#include <dos.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "../commdefs.h"
#include "../commglob.h"
#include "defs.h"
#include "globals.h"

#define MAX_SEARCH_STRINGS              8


PRIVATE VOID    PASCAL   OurYield( VOID );
PRIVATE BOOL    PASCAL   SetFoundFileName( HCONV hConv , LPSTR lpszFileName );
PRIVATE LRESULT PASCAL   SearchChunk( LPSTR lpszFileName );

PRIVATE BYTE             szFileName[ _MAX_PATH + 1 ];
PRIVATE BYTE             szSearchPath[ _MAX_PATH + 1 ];
PRIVATE BYTE             szWildcard[ ] = "*.*";
PRIVATE PSTR             pszBaseName;
PRIVATE WORD             wSDelay;
PRIVATE WORD             wSFlags;
PRIVATE WORD             wFoundFiles;
PRIVATE DWORD            dwFileOffset;
PRIVATE DWORD            dwEndLastSearchTime;
PRIVATE GLOBALHANDLE     hffInfo;
PRIVATE struct _find_t   FindInfo;
PRIVATE SEARCHSTRINGINFO SearchStringInfo[ MAX_SEARCH_STRINGS ];


PUBLIC BOOL PASCAL SetSearchString( HCONV hConv , LPSTR lpszThisSearchString )
{
    register WORD wIndex;


    /* Doublecheck the string length (the Find */
    /* dialog should have already done this).  */
    if( lstrlen( lpszThisSearchString ) > MAX_SEARCH_STRING_LENGTH )
    {
        /* Search string too long. */
        return FALSE;
    }

    /* Find an empty structure for the search string info. */
    for( wIndex = 0; wIndex < MAX_SEARCH_STRINGS; wIndex++ )
    {
        if( !SearchStringInfo[ wIndex ].hConv )
        {
            break;
        }
    }

    if( wIndex == MAX_SEARCH_STRINGS )
    {
        /* Can't set search string info. */
        return FALSE;
    }

    /* Set up the info. */
    SearchStringInfo[ wIndex ].hConv = hConv;
    lstrcpy( SearchStringInfo[ wIndex ].szSearchString , lpszThisSearchString );
    return TRUE;

}/* SetSearchString( ) */


PUBLIC VOID PASCAL ResetSearch( WORD wCmd )
{
    register WORD wIndex;


    if( wCmd & RS_SEARCH_STRINGS )
    {
        /* Forget the old search string info. */
        for( wIndex = 0; wIndex < MAX_SEARCH_STRINGS; wIndex++ )
        {
            SearchStringInfo[ wIndex ].hConv = (HCONV)NULL;
        }
    }

    if( wCmd & RS_FILE_INFO )
    {
        /* Set ourselves up for the next cycle. */
        *FindInfo.name = '\0';
        dwFileOffset = (DWORD)0;
    }

    if( wCmd & RS_END_LAST_SEARCH_TIME )
    {
        /* Forget about the last time we searched.  Just forget it, OK? */
        dwEndLastSearchTime = (DWORD)0;
    }

}/* ResetSearch( ) */


PUBLIC BOOL PASCAL SetSearchInfo( WORD wSearchFlags , WORD wSearchDelay ,
    LPSTR lpszSearchPath )
{
    int nLength;


    if( ( nLength = lstrlen( lpszSearchPath ) ) > _MAX_PATH )
    {
        /* Path too long. */
        return FALSE;
    }

    /* Copy the path and remove a trailing path separator, if any. */
    lstrcpy( (LPSTR)szSearchPath , lpszSearchPath );

    if( strchr( "/\\" , szSearchPath[ nLength - 1 ] ) )
    {
        /* Don't remove the path separator if we're */
        /* talking about the root directory.        */
        if( nLength > 1 && szSearchPath[ nLength - 2 ] != ':' )
        {
            szSearchPath[ nLength - 1 ] = '\0';
        }
    }

    /* If continuous searches were specified, */
    if( ( wSFlags = wSearchFlags ) & SF_CONTINUOUS )
    {
        /* Copy the delay value. */
        wSDelay = wSearchDelay;
    }
    return TRUE;

}/* SetSearchInfo( ) */


PUBLIC LRESULT PASCAL InitSearch( HSZ hszTopic , HSZ hszItem )
{
    LPSTR        lpszPathSeparator;
    LPSTR        lpszFirstMetaCharacter;
    int          nLength;
    struct _stat StatInfo;


    if( *FindInfo.name )
    {
        /* We're in the middle of a search cycle, */
        /* which means we're already initialized. */
        return (LRESULT)1;
    }

    if( *szSearchPath )
    {
        if( !IsValidPath( (LPSTR)szSearchPath ,
            (LPSTR FAR *)&lpszFirstMetaCharacter ,
            (LPSTR FAR *)&lpszPathSeparator , (VOID FAR *)&StatInfo ) )
        {
            /* Path is invalid. */
            return (LRESULT)0;
        }

        /* If it's a directory and no metacharacters were supplied, use *.*. */
        if( !lpszFirstMetaCharacter && StatInfo.st_mode & _S_IFDIR )
        {
            nLength = strlen( szSearchPath );
            if( !strchr( "/\\" , szSearchPath[ nLength - 1 ] ) )
            {
                /* For aesthetics' sake, use the same path  */
                /* divider that this pathname already uses. */
                if( strchr( szSearchPath , '\\' ) )
                {
                    strcat( szSearchPath , "\\" );
                }
                else
                {
                    strcat( szSearchPath , "/" );
                }
                lpszPathSeparator = (LPSTR)szSearchPath +
                    strlen( szSearchPath ) - 1;
            }
            strcat( szSearchPath , szWildcard );
        }

        /* Copy the path to szFileName without the filename portion.  */
        /* Point pszBaseName at the terminating null.                 */
        if( !lpszPathSeparator )
        {
            /* szSearchPath doesn't include a path or a drive designator. */
            lpszPathSeparator = (LPSTR)szSearchPath;
        }
        else
        {
            lpszPathSeparator++;
        }

        nLength = lpszPathSeparator - (LPSTR)szSearchPath;
        strncpy( szFileName , szSearchPath , nLength );
        szFileName[ nLength ] = '\0';
        pszBaseName = szFileName + nLength;
    }
    else
    {
        /* Use the root directory of the current drive.  Copy a '/'  */
        /* to szFileName; point pszBaseName at the terminating null. */
        szFileName[ 0 ] = '/';
        szFileName[ 1 ] = '\0';
        pszBaseName = szFileName + 1;
    }
    return (LRESULT)1;

}/* InitSearch( ) */


PUBLIC LRESULT PASCAL DoSearch( VOID )
{
    /* If we aren't set up to search, return. */
    if( !SearchStringInfo[ 0 ].hConv || !pszBaseName )
    {
        return (LRESULT)0;
    }

    /* If we're doing continuous searches and   */
    /* our interval hasn't elapsed yet, return. */
    if( ( wSFlags & SF_CONTINUOUS ) && dwEndLastSearchTime &&
        ( GetTickCount( ) < dwEndLastSearchTime + wSDelay * 1000 ) )
    {
        return (LRESULT)0;
    }

    /* If the offset is zero, we're either starting a search cycle or */
    /* have finished with one file and should go on to the next file. */
    /* Get another filename.                                          */
    if( !dwFileOffset )
    {
        /* Step through all filenames corresponding to this pattern. */
        if( ( !*FindInfo.name &&
            !_dos_findfirst( szSearchPath , _A_NORMAL , &FindInfo ) ) ||
            ( *FindInfo.name &&
            !_dos_findnext( &FindInfo ) ) )
        {
            /* Construct the full pathname of the file and search it. */
            strcpy( pszBaseName , FindInfo.name );
        }
        else
        {
            /* We're ending a search cycle. */

            if( wSFlags & SF_CONTINUOUS )
            {
                /* If we're doing continuous searches, remember */
                /* the time we finished this search.            */
                dwEndLastSearchTime = GetTickCount( );
            }
            else
            {
                /* If we're not doing continuous searches, */
                /* get rid of the search strings.          */
                ResetSearch( RS_SEARCH_STRINGS );
            }

            /* Set ourselves up for the next cycle. */
            ResetSearch( RS_FILE_INFO );
            return (LRESULT)0;
        }
    }

    /* Search CHUNK_LENGTH bytes of this file. */
    return SearchChunk( (LPSTR)szFileName );

}/* DoSearch( ) */


PRIVATE LRESULT PASCAL SearchChunk( LPSTR lpszFileName )
{
    PRIVATE BYTE  szErrMsg[ _MAX_PATH * 2 + 1 ];
    register WORD wIndex;
    DWORD         dwIOSize;
    LPSTR         lpszText;
    OFSTRUCT      ofInfo;
    HFILE         hFile;
    HCURSOR       hOldCursor;


    /* Set the cursor to an hourglass - this may take a while. */
    hOldCursor = SetCursor( LoadCursor( (HANDLE)NULL , IDC_WAIT ) );

    /* Open the file whose name we retrieved. */
    if( ( hFile = OpenFile( lpszFileName , (LPOFSTRUCT)&ofInfo ,
        OF_READ | OF_SHARE_DENY_WRITE ) ) == -1 )
    {
        /* File open failed. */
        SetCursor( hOldCursor );
        LoadString( hInst , IDS_CANNOT_OPEN_FILE , (LPSTR)szString ,
            sizeof szString );
        wsprintf( (LPSTR)szErrMsg , (LPSTR)szString ,
            lpszFileName , OpenFileErrorMsg( ofInfo.nErrCode ) );
        MessageBox( GetFocus( ) , (LPSTR)szErrMsg , (LPSTR)szAppName ,
            MB_OK | MB_ICONEXCLAMATION );
        return (LRESULT)0;
    }

    /* Seek to the current offset and read a chunk. */
    _llseek( hFile , dwFileOffset , 0 );
    if( ( dwIOSize = (DWORD)_lread( hFile , (VOID _huge *)lpszFileContents ,
        (UINT)CHUNK_LENGTH ) ) == (DWORD)-1 )
    {
        /* Couldn't read the file. */
        _lclose( hFile );
        SetCursor( hOldCursor );
        ErrorMsg( IDS_CANNOT_SEARCH_FILE );
        return (LRESULT)0;
    }

    if( !dwIOSize )
    {
        /* We're at EOF.  Prepare ourselves for the next file. */
        dwFileOffset = (DWORD)0;
        _lclose( hFile );
        SetCursor( hOldCursor );
        return (LRESULT)1;
    }

    /* Null terminate the data read. */
    lpszFileContents[ dwIOSize ] = '\0';

    /* Next time, pick up where we left off. */
    dwFileOffset += dwIOSize;

    /* Close the file. */
    _lclose( hFile );

    /* Search the buffer for the desired strings. */
    wIndex = 0;
    do
    {
        lpszText = lpszFileContents;
        for(
            lpszText = lstristr( lpszText ,
                SearchStringInfo[ wIndex ].szSearchString );
            lpszText;
            lpszText = lstristr( ++lpszText ,
                SearchStringInfo[ wIndex ].szSearchString )
           )
        {
            /* Store the name of the found file. */
            SetFoundFileName( SearchStringInfo[ wIndex ].hConv , lpszFileName );

            /* Notify the DDE callback that we found a desired string. */
            DdePostAdvise( dwInstID , hszSearchTopic , hszFindItem );
        }
    }
    while( SearchStringInfo[ ++wIndex ].hConv );

    SetCursor( hOldCursor );
    return (LRESULT)1;

}/* SearchChunk( ) */


PRIVATE BOOL PASCAL SetFoundFileName( HCONV hConv , LPSTR lpszFileName )
{
    register WORD   wIndex;
    WORD            wMaxFoundFiles;
    DWORD           dwLength;
    LPFOUNDFILEINFO lpffInfo;


    dwLength = sizeof( FOUNDFILEINFO );

    /* If there is no found file info buffer, or it isn't big enough... */
    if( !hffInfo ||
        ( wFoundFiles + 1 ) * dwLength > MemSize( hffInfo ) )
    {
        /* Set the new size of the found file info buffer. */
        /* Make room for one more structure.               */
        if( hffInfo )
        {
            dwLength += MemSize( hffInfo );
        }

        /* Get a buffer into which found filenames will be placed. */
        if( !( hffInfo = AdjustMem( hffInfo , dwLength ) ) )
        {
            /* Couldn't reallocate found filenames buffer. */
            /* Display an error message and terminate.     */
            ErrorMsg( IDS_CANNOT_ALLOCATE_MEMORY );
            return FALSE;
        }
    }
    ++wFoundFiles;

    /* Lock the buffer. */
    if( !( lpffInfo = (LPFOUNDFILEINFO)LockMem( hffInfo ) ) )
    {
        /* Memory lock failed. */
        if( hffInfo )
        {
            FreeMem( hffInfo );
            hffInfo = (GLOBALHANDLE)NULL;
        }

        ErrorMsg( IDS_CANNOT_LOCK_MEMORY );
        return FALSE;
    }

    /* Go to the first unused structure. */
    wMaxFoundFiles = (WORD)( MemSize( hffInfo ) /
        (DWORD)sizeof( FOUNDFILEINFO ) );
    for( wIndex = 0; wIndex < wMaxFoundFiles; wIndex++ )
    {
        if( !lpffInfo[ wIndex ].hConv )
        {
            break;
        }
    }

    if( wIndex == wMaxFoundFiles )
    {
        /* Can't set found file info. */
        UnlockMem( hffInfo );
        return FALSE;
    }

    /* Copy the new info into the structure. */
    lpffInfo[ wIndex ].hConv = hConv;
    lstrcpy( lpffInfo[ wIndex ].szFoundFileName , lpszFileName );

    /* Unlock the buffer. */
    UnlockMem( hffInfo );
    return TRUE;

}/* SetFoundFileName( ) */


PUBLIC LPSTR PASCAL GetFoundFileName( HCONV hConv )
{
    PRIVATE BYTE    szFoundFileName[ _MAX_PATH + 1 ];
    register WORD   wIndex;
    WORD            wMaxFoundFiles;
    LPFOUNDFILEINFO lpffInfo;


    /* Lock the buffer. */
    if( !( lpffInfo = (LPFOUNDFILEINFO)LockMem( hffInfo ) ) )
    {
        /* Memory allocation or lock failed. */
        if( hffInfo )
        {
            FreeMem( hffInfo );
            hffInfo = (GLOBALHANDLE)NULL;
        }

        ErrorMsg( IDS_CANNOT_LOCK_MEMORY );
        return (LPSTR)NULL;
    }

    /* Go to the first structure for this conversation. */
    wMaxFoundFiles = (WORD)( MemSize( hffInfo ) /
        (DWORD)sizeof( FOUNDFILEINFO ) );
    for( wIndex = 0; wIndex < wMaxFoundFiles; wIndex++ )
    {
        if( lpffInfo[ wIndex ].hConv == hConv )
        {
            break;
        }
    }

    if( wIndex == wMaxFoundFiles )
    {
        /* We never found our conversation handle. */

        /* Internal inconsistency - can't get found file info. */
        UnlockMem( hffInfo );
        return (LPSTR)NULL;
    }

    /* Copy the found file name from the structure */
    /* and mark the structure for reuse.           */
    lstrcpy( (LPSTR)szFoundFileName , lpffInfo[ wIndex ].szFoundFileName );
    lpffInfo[ wIndex ].hConv = (HCONV)NULL;
    --wFoundFiles;

    /* Unlock the buffer. */
    UnlockMem( hffInfo );
    return (LPSTR)szFoundFileName;

}/* GetFoundFileName( ) */


PUBLIC VOID PASCAL FreeFoundFileNameBuffer( VOID )
{
    if( hffInfo )
    {
        FreeMem( hffInfo );
        hffInfo = (GLOBALHANDLE)NULL;
    }

}/* FreeFoundFileNameBuffer( ) */


PRIVATE VOID PASCAL OurYield( VOID )
{
    MSG Msg;


    if( PeekMessage( (LPMSG)&Msg , NULL , 0 , 0 , PM_REMOVE ) )
    {
        TranslateMessage( (LPMSG)&Msg );
        DispatchMessage( (LPMSG)&Msg );
    }

}/* OurYield( ) */

/* EOF */
