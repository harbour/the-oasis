/* +++Date last modified: 05-Jul-1997 */

#define X N(a,O(h,W(f,M(c,g))),O(i,W(f,M(d,g))))
#define A(x) r(D(x,1); O(x,-9); D(x,O(x,1)))
#define L(x) toupper(getchar())-x
#define R Z,Z,0,0
#define S 0,9,6,6,6,6,6,6,9,0
#define q D(h,0); A(f)A(g)
#define T 0,6,1,2,2,2,2,1,6,0
#define U 0,6,2,3,3,3,3,2,6,0
#define C(x) ((x<1)||(x>8))
#define F(x,y) printf(x,y);
#define N(x,y,z) *O(*O(x,y),z)
#define y(a,b,c) a[b][c]
#define O(x,y) ((x)+(y))
#define u(x) (O(0,-(x)))
#define W(x,y) ((x)*(y))
#define G(x) printf(x);
#define D(x,y) (x=(y))
#define P (rand()%6)
#define Y D(e,O(e,1))
#define s D(f,O(f,Q))
#define H(x) return x
#define B(x) while(x)
#define M(x,y) *O(x,y)
#define z(a,b) a[b]
#define E(x) if(x)
#define I main(){
#define Z 0,0,0,0
#define t G("\n")
#define V(x) (!x)
#define v h,i,j,k
#define w e,f,g
#define J int
#define Q u(1)
#define p "%c"
#define o 'A'
#define r for
#define n 60
#define K do

J y(a,10,10)={R,R,R,R,Z,1,Q,Z,Z,Q,1,R,R,R,R,Z},y(b,10,10)={R,S,T,
U       ,       U       ,       U       ,       U       ,       T
,       S       ,       R       }       ,       z       (       c
,       9       )       =       {       Q       ,       Q       ,
Q,0,0,1,1,1,0},z(d,9)={Q,0,1,Q,1,Q,0,1,0};I J w,v;l();r(D(e,0);O(
e       ,       -       n       )       ;       Y       )       {
q       D       (       h       ,       O       (       h       ,
m       (       f       ,       g       ,       1       ,       1
)));E(h){K{G("\n?")K{D(f,L(O('A',Q)));}B(C(f));K{D(g,L('0'));}B(C
(       g       )       )       ;       }       B       (       V
(       m       (       f       ,       g       ,       1       ,
Q       )       )       )       ;       l       (       )       ;
}q E((D(k,O(m(f,g,Q,1),P)))>h){D(h,k);D(i,f);D(j,g);}E(h&&m(i,j,Q
,       Q       )       ) /***/ l /***/ (       )       ;       }
}       J       m       (/*   */v/*****/)       J       v       ;
{       J       w       ; /***/ E /***/ (       N       (       a
,h,i))H(0);E(O(k,Q))D(N(a,h,i),j);D(e,N(b,h,i));r(D(g,1);O(g,-9);
D       (       g       , /***/ O /***/ (       g       ,       1
)       )       )       {/*****/D/*   */(       g       ,       O
(       g       ,       Q /***/ ) /***/ )       ;       E       (
V(O(N(a,O(h,M(c,g)),O(i,M(d,g))),j))){r(D(f,1);V(O(X,j));D(f,O(f,
1       )       )       )       ;       E       (       V       (
O       (       N       (       a       ,       O       (       h
,       W       (       f       ,       M       (       c       ,
g))),O(i,W(f,M(d,g)))),u(j))))r(s;f;s){X=X*k;D(e,O(e,N(b,O(h,W(f,
M       (       c       ,       g       )       )       )       ,
O       (       i       ,       W       (       f       ,       M
(       d       ,       g       )       )       )       )       )
);}}D(g,O(g,1));}E(V(O(e,u(N(b,h,i))))){D(N(a,h,i),0);H(0);}H(e);
}       l       (       )       {       J       f       ,       g
;       t       A       (       g       )       {       F       (
p       ,       O       (       O       (       o       ,       g
),Q))A(f)F("%c:",M("X O<",O(N(a,g,f),1)))t}G(" ")A(f)F("%d ",f)t}
