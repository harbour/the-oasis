/* +++Date last modified: 05-Jul-1997 */

main(){char *c="main(){char *c=%c%s%c;printf(c,34,c,34);}";printf(c,34,c,34);}
