/*
	 06/21/91:  Fixed dumb bug in buffer handling for msgs longer than 8K.
                Old BASIC habits die hard...
     07/12/91:  You can now redirect stdout and get a "clean" (but not
                completely raw--hell, you've got the packet) dump of a
								packet.
                Sped up unredirected OS/2 output w/ Vio call.
     12/26/91:  Added resyncing for grunged packets instead of just dying
                More work on portability
*/

#ifdef OS2
 #define INCL_DOS
 #define INCL_VIO
 #include <os2.h>
#endif
 #include <stdlib.h>
 #include <stdio.h>
 #include <io.h>
 #include <fcntl.h>
 #include <stdarg.h>
 #include <string.h>
 #include <ctype.h>
 #include <conio.h>
 #include <sys/types.h>
 #include <sys/stat.h>

/*
     This code released to public domain 06/16/91 by M. Kimes, who wrote it.
     Compact or large model, byte alignment, unsigned chars.  No toupper()
     macro.  The executables in the archive were compiled with MSC 6.0a
     for MS-DOS and OS/2.  This code isn't extremely portable -- but I've
     written worse... The FSC-0039 and FSC-0048 stuff is from the latest
     info I have, which might well be out of date by now.
     FSC-0045 is the way to go, anyway.  The code originally began
     as just a way to list the addresses in a packet header.  It got out
     of hand.  I figured the least I could do is share it with other
     developers who might have similar needs, thereby saving them the time
     of Yet Another Project.


     Fingers down the throat of Echopol (or whatever name it masquerades
     under these days)...an unpaid apolitical announcement.  And leave
     my damn soul alone.  I'm saving it.

     A word to *ECs who might be tempted to use this program to prove
     software brand x is non-compliant:  remember that the program that
     created a packet isn't necessarily the program that made a "bad"
     message, and that this program is not guaranteed to do more than
     take up space on a disk until you delete it (it might be wrong).

     All opinions expressed are my own.  It'd be dumb if I expressed
     yours, wouldn't it?
*/

#ifndef OS2
    typedef struct {
        char                 reserved[21];      /* reserved by MS-DOS */
        char                 attrFile;          /* attributes */
        unsigned             ftimeLastWrite;    /* time */
        unsigned             fdateLastWrite;    /* date */
        unsigned long        cbFile;            /* file size */
        char                 achName[13];       /* file name */
    } DOSFileData;
#else
    #define DOSFileData FILEFINDBUF
#endif

/* include proper header files and create macros */
#if defined OS2
    #define FIND_FIRST(spec,attr,buf) DosFindFirst(spec,&search_handle,attr,buf,sizeof(FILEFINDBUF),&num_matches,0L)
    #define FIND_NEXT(buf) DosFindNext(search_handle,buf,sizeof(FILEFINDBUF),&num_matches)
    #define FIND_CLOSE() DosFindClose(search_handle)
    char * searchpath (char *filename);
#elif defined (_MSC_VER) || defined(_QC) || defined(__WATCOMC)
    #include "direct.h"
    #include "dos.h"
    #define FIND_FIRST(spec, attr, buf) _dos_findfirst(spec, attr, (struct find_t *)buf)
    #define FIND_NEXT(buf) _dos_findnext((struct find_t *)buf)
    #define FIND_CLOSE()
    char *searchpath(char *filename);
#elif defined (__TURBOC__)
    #include "dir.h"
    #define FIND_FIRST(spec, attr, buf) findfirst(spec, (struct ffblk *)buf,attr)
    #define FIND_NEXT(buf) findnext((struct ffblk *)buf)
		#define FIND_CLOSE()
		#ifdef putchar
			#undef putchar
			int putchar (int ch);
		#endif
#elif defined (__ZTC__)
    #include "dos.h"
    #define FIND_FIRST(spec, attr, buf) dos_findfirst(spec, attr, (struct DOS_FIND *)buf)
    #define FIND_NEXT(buf) dos_findnext((struct DOS_FIND *)buf)
    #define FIND_CLOSE(buf)
    char *searchpath(char *filename);
#endif

typedef struct  {     /* FSC-0045 */
    unsigned int
        onode,
        dnode,
        opoint,
        dpoint;
    char
        zeros[8];
    unsigned int
        subver,       /* 2 */
        version,      /* 2 */
        onet,
        dnet;
    char
        product,
        rev_lev,
        password[8];
    unsigned int
        ozone,
        dzone;
    char
        odomain[8],
        ddomain[8];
    long
        specific;
} NEWPKTHDR;

typedef struct {               /* close to stoneage */
	unsigned int
        orig_node,             /* originating node */
        dest_node,             /* destination node */
        year,                  /* 1989 - nnnnn */
        month,
        day,
        hour,
        minute,
        second,
        rate,                  /* unused */
        ver,                   /* 2 */
        orig_net,              /* originating net */
        dest_net;              /* destination net */
	 char
        product,
        rev_lev,               /* revision level */
        password[8];
	 unsigned int
        qm_orig_zone,
        qm_dest_zone;
	 char
				domain[8];
	 unsigned int
        orig_zone,             /* originating zone */
        dest_zone,             /* destination zone */
        orig_point,            /* originating point */
        dest_point;            /* destination point */
     long
        pr_data;
} OLDPKTHDR;

typedef struct {               /* FSC-0039 */
	unsigned int
        orig_node,             /* originating node */
        dest_node,             /* destination node */
        year,                  /* 1989 - nnnnn */
        month,
        day,
        hour,
        minute,
        second,
        rate,                  /* unused */
        ver,                   /* 2 */
        orig_net,              /* originating net */
        dest_net;              /* destination net */
	 char
        product,
        rev_lev,               /* revision level */
        password[8];
	 unsigned int
        qm_orig_zone,
        qm_dest_zone;
	 char
        filler[2];
     unsigned int
        capword2;
     char
        product2,
        rev_lev2;
     unsigned int
        capword,
        orig_zone,             /* originating zone */
        dest_zone,             /* destination zone */
        orig_point,            /* originating point */
        dest_point;            /* destination point */
     long
        pr_data;
} MEDPKTHDR;

typedef struct {               /* FSC-0048 */
	unsigned int
        orig_node,             /* originating node */
        dest_node,             /* destination node */
        year,                  /* 1989 - nnnnn */
        month,
        day,
        hour,
        minute,
        second,
        rate,                  /* unused */
        ver,                   /* 2 */
        orig_net,              /* originating net */
        dest_net;              /* destination net */
	 char
        product,
        rev_lev,               /* revision level */
        password[8];
	 unsigned int
        qm_orig_zone,
        qm_dest_zone,
        aux_net;
     unsigned int
        capword2;
     char
        product2,
        rev_lev2;
     unsigned int
        capword,
        orig_zone,             /* originating zone */
        dest_zone,             /* destination zone */
        orig_point,            /* originating point */
        dest_point;            /* destination point */
     long
        pr_data;
} MEDPKTHDR2;

/*--------------------------------------------------------------------------*/
/* FIDO Message attributes (attr) (informational)                           */
/*--------------------------------------------------------------------------*/
#define MSGPRIVATE 0x0001  /* private message,          0000 0000 0000 0001 */
#define MSGCRASH   0x0002  /* accept for forwarding     0000 0000 0000 0010 */
#define MSGREAD    0x0004  /* read by addressee         0000 0000 0000 0100 */
#define MSGSENT    0x0008  /* sent OK (remote)          0000 0000 0000 1000 */
#define MSGFILE    0x0010  /* file attached to msg      0000 0000 0001 0000 */
#define MSGFWD     0x0020  /* being forwarded           0000 0000 0010 0000 */
#define MSGORPHAN  0x0040  /* unknown dest node         0000 0000 0100 0000 */
#define MSGKILL    0x0080  /* kill after mailing        0000 0000 1000 0000 */
#define MSGLOCAL   0x0100  /* FidoNet vs. local         0000 0001 0000 0000 */
#define MSGXX1     0x0200  /*                           0000 0010 0000 0000 */
#define MSGXX2     0x0400  /* STRIPPED by FidoNet<tm>   0000 0100 0000 0000 */
#define MSGFRQ     0x0800  /* file request              0000 1000 0000 0000 */
#define MSGRRQ     0x1000  /* receipt requested         0001 0000 0000 0000 */
#define MSGCPT     0x2000  /* is a return receipt       0010 0000 0000 0000 */
#define MSGARQ     0x4000  /* audit trail requested     0100 0000 0000 0000 */
#define MSGURQ     0x8000  /* update request            1000 0000 0000 0000 */

typedef struct {
    unsigned int onode,dnode,onet,dnet,attr;
    int          cost;
} MSGHDR;

/* functions in this module */

int                  printstring            (char *s);
int                  printtext              (char *s);
void                 pause                  (void);
void                 deinit                 (void);
void                 display_product        (unsigned int product,
                                             unsigned int rev_lev);
char *               stripcr                (char *a);
int                  is_stdout_redirected   (void);
int                  (*printfunc)(const char *fmt,...);
int                  (*putfunc)(int c);
#ifdef OS2
    int              fake_printf (const char *szFormat,...);
    int              fake_putchar (int c);
#endif


/* global variables declared here */

int stdout_redirected;  /* gets set if stdout is redirected */





int main (int argc,char *argv[]) {

#ifdef OS2
    SHORT        search_handle;
    USHORT       num_matches;
#endif
    static char  buffer[8194];
    static char  attrstr[16][11] = {
                 "MSGPRIVATE","MSGCRASH","MSGREAD","MSGSENT","MSGFILE","MSGFWD",
                 "MSGORPHAN","MSGKILL","MSGLOCAL","MSGXX1","MSGXX2","MSGFRQ",
                 "MSGRRQ","MSGCPT","MSGARQ","MSGURQ"};
	FILE         *fp;
	OLDPKTHDR    po;
	NEWPKTHDR    *pn;
	MEDPKTHDR    *pm;
    MEDPKTHDR2   *pl;
    DOSFileData  f;
    MSGHDR       mh;
    int          lastargc = 1,numsent,stopsending,retcode;
    size_t       br;
    char         *spec = "*.PKT",*p;
    unsigned int ozone,dzone,anint,msgno,pktno = 0,x;
    long         pos,totalmsgs = 0;


    printfunc = printf;
    putfunc = putchar;

	atexit(deinit);

    {
        int handle;

        handle = fileno(stdout);
        setmode(handle,O_BINARY);
        handle = fileno(stderr);
        setmode(handle,O_BINARY);
    }

    stdout_redirected = is_stdout_redirected();

#ifdef OS2
    if(!stdout_redirected) {
        printfunc = fake_printf;
        putfunc = fake_putchar;
    }
#endif

    if(!stdout_redirected) {
        fprintf(stderr,"\x1b[0m\x1b[2J\x1b[0;1;34mPacket explorer for developers by M. Kimes  "__DATE__"  "__TIME__
                       "\r\n ANSI emulation required\r\n\r\nControls:\r\n\r\n"
                       "  [P]ause msg (or [Spacebar])\r\n  [S]kip msg\r\n"
                       "  [A]bort pkt (next pkt)\r\n E[X]it\r\n\r\n"
                       "Color codes:\r\n\r\n \x1b[0;1;5;31mSerious\x1b[0;1;31m Error\r\n"
                       " \x1b[0;1;33mPacket header information\r\n"
                       " \x1b[0;1;36mMsg header information\r\n"
                       " \x1b[0mMsg text\r\n"
                       " \x1b[0;1;30;47mHex control code representation\r\n"
                       "\x1b[0;1;32m Summary information\r\n");
    }
    if(argc > 1) {
        spec = argv[1];
        fprintf(stderr,"\r\n Using command line filespec %s\r\n",argv[1]);
        lastargc++;
    }
    else {
        fprintf(stderr,"\r\n Using filespecs *.PKT and *.?U?");
#ifdef OS2
        fprintf(stderr," and P.*.*.*.*.*");
#endif
        if(!stdout_redirected)
          fprintf(stderr,"\r\n\x1b[0;1;34m\r\nYou can also pass a filespec on the command line.\r\n");
    }
    if(!stdout_redirected) {
        fprintf(stderr,"\r\n\x1b[0;1;34m[Any Key to begin]");
        getch();
        (*printfunc)("\x1b[2J");
    }

	pn = (NEWPKTHDR *)&po;
    pl = (MEDPKTHDR2 *)&po;
	pm = (MEDPKTHDR *)&po;

OverAgain:

#ifdef OS2
	search_handle = -1;
	num_matches = 1;
#endif

	do {
		p = strchr(spec,'\\');
		if(p) *p = '/';
	} while(p);

	p = strrchr(spec,'/');
	if(!p) p = strrchr(spec,':');
	if(p) {
		p++;
	}

	if(!FIND_FIRST(spec,0,&f)) {
		do {
			pktno++;
			msgno = 0;
			if(p) {
				*p = 0;
				sprintf(buffer,"%s%s",spec,f.achName);
			}
			else strcpy(buffer,f.achName);
			fp = fopen(buffer,"rb");
            if(!stdout_redirected) (*printfunc)("\x1b[0;1;33m");
			if(!fp) {
                (*printfunc)("\r\n");
                if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                (*printfunc)("Couldn't open packet \"%s\"\r\n",f.achName);
                if(!stdout_redirected) (*printfunc)("\x1b[0m");
            }
			else {
				br = fread(&po,1,sizeof(OLDPKTHDR),fp);
                if(br < sizeof(OLDPKTHDR)) {
                    (*printfunc)("\r\n");
                    if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                    (*printfunc)("Packet %s short:  %u byte%s",f.achName,br,&"s"[1 == br]);
				}
                else if(po.ver != 2) {
                    (*printfunc)("\r\n");
                    if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                    (*printfunc)("\"%s\" not version 2.x; may not be a packet",f.achName);
                    pktno--;
                }
                else {
                    if(po.rate == 2) {  /* preferred method */
                        (*printfunc)("\r\nFSC-0045 (AKA version 2.2) packet:  \"%s\"",f.achName);
                        (*printfunc)("\r\nFrom %u:%u/%u.%u@%0.8s to %u:%u/%u.%u@%0.8s",
                               pn->ozone,pn->onet,pn->onode,pn->opoint,pn->odomain,
                               pn->dzone,pn->dnet,pn->dnode,pn->dpoint,pn->ddomain);
                        (*printfunc)("\r\nProduced by product #%hu.%hu   Password: \"%0.8s\"",
                               pn->product,pn->rev_lev,pn->password);
                        display_product(pn->product,pn->rev_lev);
                    }
                    else if(pm->capword && pm->capword == (~pm->capword2)) {
                        (*printfunc)("\r\nFSC-0039 (AKA version 2.+) packet:  \"%s\"",f.achName);
                        ozone = pm->orig_zone;
                        dzone = pm->dest_zone;
                        if(!ozone) ozone = pm->qm_orig_zone;
                        if(!dzone) dzone = pm->qm_dest_zone;
                        (*printfunc)("\r\nFrom %u:%u/%u.%u@???????? to %u:%u/%u.%u@????????",
                               ozone,pm->orig_net,pm->orig_node,pm->orig_point,
                               dzone,pm->dest_net,pm->dest_node,pm->dest_point);
                        ozone = pm->product + (pm->product2 << 8);
                        dzone = pm->rev_lev + (pm->rev_lev2 << 8);
                        (*printfunc)("\r\nProduced by product #%u.%u  Password: \"%0.8s\"  Capword: %u",
                               ozone,dzone,pm->password,pm->capword);
                        display_product(ozone,dzone);
                    }
                    else if(pl->capword && pl->capword == pl->capword2) {
                        (*printfunc)("\r\nFSC-0048 (AKA version 2.N) packet:  \"%s\"",f.achName);
                        ozone = pl->orig_zone;
                        dzone = pl->dest_zone;
                        if(!ozone) ozone = pl->qm_orig_zone;
                        if(!dzone) dzone = pl->qm_dest_zone;
                        if(pl->orig_net == 65535U) {
                            (*printfunc)("\r\nFrom %u:%u/%u.0@???????? to %u:%u/%u.%u@????????",
                                   ozone,pl->orig_net,pl->orig_node,
                                   dzone,pl->dest_net,pl->dest_node,pl->dest_point);
                        }
                        else {
                            (*printfunc)("\r\nFrom %u:%u/%u.%u@???????? to %u:%u/%u.%u@????????",
                                   ozone,pl->aux_net,pl->orig_node,pl->orig_point,
                                   dzone,pl->dest_net,pl->dest_node,pl->dest_point);
                        }
                        ozone = pl->product + (pl->product2 << 8);
                        dzone = pl->rev_lev + (pl->rev_lev2 << 8);
                        (*printfunc)("\r\nProduced by product #%u.%u  Password: \"%0.8s\"  Capword: %u",
                               ozone,dzone,pm->password,pm->capword);
                        display_product(ozone,dzone);
                    }
					else {
                        (*printfunc)("\r\nStoneage (AKA version 2) packet:  \"%s\"",f.achName);
                        ozone = po.qm_orig_zone;
                        dzone = po.qm_dest_zone;
						if(!ozone) ozone = po.orig_zone;
						if(!dzone) dzone = po.dest_zone;
                        (*printfunc)("\r\nFrom %u:%u/%u.%u@???????? to %u:%u/%u.%u@%0.8s",
                               ozone,po.orig_net,po.orig_node,po.orig_point,
                               dzone,po.dest_net,po.dest_node,po.dest_point,
                               po.domain);
                        (*printfunc)("\r\nProduced by #%hu.%hu  Password: \"%0.8s\"",
                               po.product,po.rev_lev,po.password);
                        display_product(po.product,po.rev_lev);
                    }
					for(;;) {
GrungeReSync:
						if(!fread(&anint,sizeof(int),1,fp)) {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                            (*printfunc)("Unexpected end of packet");                           break;
						}
						if(!anint || anint != 2) {
                            if(!anint) {
                                (*printfunc)("\r\n");
                                if(!stdout_redirected) (*printfunc)("\x1b[0;1;32m");
                                (*printfunc)("End of packet: %u msg%s",
                                       msgno,&"s"[1 == msgno]);
                            }
                            else {
                                (*printfunc)("\r\n");
                                if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                                (*printfunc)("Grunged packet: attempting resync, expect some garbage");
                                if(kbhit() && toupper(getch()) == 'A') {
                                    (*printfunc)("\r\nKeyboard abort\r\n");
                                    break;
                                }
                                fseek(fp,-1L,SEEK_CUR);
                                goto GrungeReSync;
                            }
							break;
						}
						br = fread(&mh,1,sizeof(mh),fp);
						if(br < sizeof(mh)) {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                            (*printfunc)("Incomplete msg header");
							break;
						}
                        (*printfunc)("\r\n\r\n");
                        if(!stdout_redirected) (*printfunc)("\x1b[0;1;36m");
                        (*printfunc)("Msg #%u from %u/%u to %u/%u",++msgno,
                               mh.onet,mh.onode,mh.dnet,mh.dnode);
                        (*printfunc)("  *  Attrib: %u  Cost: %d",mh.attr,mh.cost);
						totalmsgs++;
						if(mh.attr) {
                            (*printfunc)("\r\n");
							for(x = 0;x < 16;x++) {
                                if(mh.attr & (1 << x)) (*printfunc)("%s ",attrstr[x]);
							}
						}
						pos = ftell(fp);
						br = fread(buffer,1,20,fp);
						if(br < 20) {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                            (*printfunc)("Incomplete msg header");
							break;
						}
						for(x = 0;x < 19;x++) {
                            if(buffer[x] == 0) break;
                        }
                        if(x == 19 && buffer[19] == 0) (*printfunc)("\r\nDate: ");
                        else {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;36m");
                            (*printfunc)("Grunged");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;36m");
                            (*printfunc)(" date: ");
                        }
						buffer[19] = 0;
                        if(printstring(buffer) == -1) goto NextPacket;
						fseek(fp,pos + (long)strlen(buffer) + 1L,SEEK_SET);
						pos = ftell(fp);
						if(!fread(buffer,1,36,fp)) {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                            (*printfunc)("Incomplete msg header");
							break;
						}
						for(x = 0;x < 36;x++) {
							if(buffer[x] == 0) break;
                        }
                        if(x == 36) {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;36m");
                            (*printfunc)("Grunged");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;36m");
                            (*printfunc)(" to: ");
                        }
                        else (*printfunc)("\r\nTo:   ");
						buffer[35] = 0;
                        if(printstring(buffer) == -1) goto NextPacket;
						fseek(fp,pos + (long)strlen(buffer) + 1L,SEEK_SET);
						pos = ftell(fp);
						if(!fread(buffer,1,36,fp)) {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                            (*printfunc)("Incomplete msg header");
							break;
						}
						for(x = 0;x < 36;x++) {
							if(buffer[x] == 0) break;
						}
                        if(x == 36) {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;36m");
                            (*printfunc)("Grunged");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;36m");
                            (*printfunc)(" from: ");
                        }
                        else (*printfunc)("\r\nFrom: ");
						buffer[35] = 0;
                        if(printstring(buffer) == -1) goto NextPacket;
						fseek(fp,pos + (long)strlen(buffer) + 1L,SEEK_SET);
						pos = ftell(fp);
						if(!fread(buffer,1,72,fp)) {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                            (*printfunc)("Incomplete msg header");
							break;
						}
						for(x = 0;x < 36;x++) {
							if(buffer[x] == 0) break;
						}
                        if(x == 72) {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;36m");
                            (*printfunc)("Grunged");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;36m");
                            (*printfunc)(" subj: ");
                        }
                        else (*printfunc)("\r\nSubj: ");
						buffer[71] = 0;
                        if(printstring(buffer) == -1) goto NextPacket;
						fseek(fp,pos + (long)strlen(buffer) + 1L,SEEK_SET);
						pos = ftell(fp);
						memset(buffer,0,8193);
                        if(!fread(buffer,1,8192,fp)) {
                            (*printfunc)("\r\n");
                            if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                            (*printfunc)("No msg text");
                            break;
						}
                        stopsending = 0;
                        do {
                            for(x = 0;x < 8192;x++) {
                                if(buffer[x] == 0) break;
                            }
                            if(!x) break;
                            buffer[8192] = 0;
                            numsent = min(8192,x);
                            if(!stdout_redirected) (*printfunc)("\x1b[0m");
                            (*printfunc)("\r\n");
                            if(!stopsending) {
                                retcode = printtext(buffer);
                                if(retcode == -1) goto NextPacket;
                                if(retcode < numsent) stopsending++;
                            }
                            if(x == 8192) {
                                pos = ftell(fp);
                                memset(buffer,0,8193);
                                if(!fread(buffer,1,8192,fp)) {
                                    (*printfunc)("\r\n");
                                    if(!stdout_redirected) (*printfunc)("\x1b[0;1;5;31m");
                                    (*printfunc)("Premature end of message");
                                    goto NextPacket;
                                }
                            }
                        } while(x == 8192);
						fseek(fp,pos + (long)strlen(buffer) + 1L,SEEK_SET);
						pos = ftell(fp);
                    }
NextMsg:
                    if(!stdout_redirected) (*printfunc)("\x1b[0m");
                    (*printfunc)("\r\n");
                }
NextPacket:
				fclose(fp);
			}

#ifdef OS2
			num_matches = 1;
#endif

		} while(!FIND_NEXT(&f));
        FIND_CLOSE();
	}

	if(!stricmp(spec,"*.PKT")) {
        spec = "*.?U?";
		goto OverAgain;
    }
#ifdef OS2
    else if(!stricmp(spec,"*.?U?")) {
        spec = "P.*.*.*.*.*";
        goto OverAgain;
    }
#endif
    else {
        if(argc > lastargc) {
            spec = argv[lastargc++];
            fprintf(stderr,"\r\n\x1b[0;1;32m Using command line filespec %s",spec);
            goto OverAgain;
        }
    }
    if(!pktno) {
        (*printfunc)("\r\n");
        if(!stdout_redirected) (*printfunc)("\x1b[0;1;32m");
        (*printfunc)("No packets were found.");
    }
    else {
        (*printfunc)("\r\n");
        if(!stdout_redirected) (*printfunc)("\x1b[0;1;32m");
        (*printfunc)("Found %u packet%s w/ %lu msg%s",
               pktno,&"s"[1 == pktno],totalmsgs,&"s"[1L == totalmsgs]);
    }

    return 0;
}


int printstring (char *s) {

	unsigned int x;
    int          kp;


    (*putfunc)('\"');
    for(x = 0; x < 8192;x++) {
		if(!s[x]) break;
        if(isprint(s[x])) (*putfunc)(s[x]);
        else {
            if(!stdout_redirected)
              (*printfunc)("\x1b[0;1;30;46m%02hx\x1b[0;1;36m",s[x]);
            else (*putfunc)(s[x]);
        }
    }
    (*putfunc)('\"');
    if(!stdout_redirected) {
        if(kbhit()) {
            kp = toupper(getch());
            switch(kp) {
                case ' ':
                case 'P':   pause();
                            break;
                case 'X':   exit(3);
                case 'A':   return -1;
            }
        }
    }
    return x;
}



int printtext (char *s) {

	unsigned int x;
    int          kp;


    for(x = 0; x < 8192;x++) {
		if(!s[x]) break;
        if(isprint(s[x])) (*putfunc)(s[x]);
        else if(s[x] == '\r' || !(x % 79)) {
            if(s[x] == '\r') {
                if(!stdout_redirected)
                  (*printfunc)("\x1b[0;30;47;1m%02hx\x1b[0m",s[x]);
                (*printfunc)("\r\n");
            }
            if(!stdout_redirected) {
                if(kbhit()) {
                    kp = toupper(getch());
                    switch(kp) {
                        case ' ':
                        case 'P':   pause();
                                    break;
                        case 'S':   goto BreakOut;
                        case 'X':   exit(3);
                        case 'A':   return -1;
                    }
                }
            }
        }
        else {
            if(!stdout_redirected)
              (*printfunc)("\x1b[0;30;47;1m%02hx\x1b[0m",s[x]);
            else {
                if(s[x] != '\n') (*putfunc)(s[x]);
            }
        }
    }

BreakOut:

	return x;
}



void pause (void) {

	int kp;


    if(stdout_redirected) return;
	do {
		while(kbhit()) getch();
		kp = toupper(getch());
	} while(kp == 'P');
}



void deinit (void) {

    if(!stdout_redirected) printf("\x1b[0m");
    printf("\r\n");
	fcloseall();
}



void display_product (unsigned int product,unsigned int rev_lev) {

    char          s[133],*p;
    unsigned int  prod;
    FILE          *fp;


    if(!product) {
        (*printfunc)("\r\nFido <tm> or an unregistered product rev %u",rev_lev);
        return;
    }

    p = searchpath("FTSCPROD.LST");
    if(p) {
        fp = fopen(p,"rt");
        if(!fp) {
            (*printfunc)("\r\n");
            if(!stdout_redirected) (*printfunc)("\x1b[0;1;31m");
            (*printfunc)("Couldn't open %s",p);
            if(!stdout_redirected) (*printfunc)("\x1b[0;1;33m");
            return;
        }
        while(!feof(fp)) {
            if(!fgets(s,132,fp)) break;
            if(*s != ';') {
                p = s;
                prod = (unsigned int)strtol(s,&p,16);
                if(prod == product) {
                    if(*p) {
                        p++;
                        stripcr(p);
                        (*printfunc)("\r\n%s rev %u",p,rev_lev);
                    }
                    else (*printfunc)("\r\n??? rev %u",rev_lev);
                    fclose(fp);
                    return;
                }
            }
        }
        fclose(fp);
    }
    (*printfunc)("\r\nUnknown product rev %u",rev_lev);
}


#if defined OS2
char * searchpath (char *filename) {

    static char fbuf[1027];


	if(DosSearchPath(3,"PATH",filename,fbuf,1027)) {
		return NULL;
	}
	return fbuf;
}

#elif !defined __TURBOC__

char *searchpath (char *filename) {

    static char fbuf[153];
    struct stat st;
    char        *envbuf = NULL,*p,temp;


    p = getenv("PATH");
    if(!p) return filename;
    envbuf = strdup(p);
    if(!envbuf) return filename;

    p = strtok(envbuf,";");
    do {
        strncpy(fbuf,p,128);
        fbuf[128] = 0;
        temp = fbuf[strlen(fbuf) - 1];
        if(temp != '/' && temp != '\\') strcat(fbuf,"\\");
        strcat(fbuf,filename);
        if(!stat(fbuf,&st)) {
            if(envbuf) free(envbuf);
            return fbuf;
        }
        p = strtok(0,";");
    } while(p);
    if(envbuf) free(envbuf);
    return NULL;
}

#endif



char * stripcr (char *a) {

    register int x;


    x = strlen(a);
    while (x && (a[x - 1] == '\n' || a[x - 1] == '\r')) a[--x] = 0;
    return a;

}


int is_stdout_redirected (void) {

    /* check to see if stdout is redirected.  return non-zero if so */

#ifdef OS2
    unsigned int info,devhead;
#else
    union REGS   rg;
#endif

#ifndef OS2

    rg.h.ah = 0x44;
    rg.h.al = 0x00;
    rg.x.bx = fileno(stdout);
    int86(0x21,&rg,&rg);
		if(!rg.x.cflag) {
        if(rg.x.dx & 128) {
           if(rg.x.dx & 2) return 0;
        }
    }
    return 1;

#else

    DosQHandType(fileno(stdout),&info,&devhead);
    if(((info & 255) == 1) && (devhead & 2)) return 0;
    return 1;

#endif
}



#ifdef OS2

int fake_printf (const char *szFormat,...) {

    /* print through ANSI but not necessarily stdout */

    int         len;
    static char chBuffer[9000];     /* tacky, but who cares... */
    va_list     pArguments;


    va_start(pArguments,szFormat);
    len = vsprintf(chBuffer,szFormat,pArguments);
    va_end(pArguments);
    VioWrtTTY(chBuffer,len,0);
    return len;
}


int fake_putchar (int c) {

    /* print through ANSI but not necessarily stdout */

    char cc = (char)c;


    VioWrtTTY(&cc,1,0);
    return 1;
}

#endif





#ifdef __TURBOC__


int putchar (int ch) {

		return (putc(ch,stdout));
}

#endif
