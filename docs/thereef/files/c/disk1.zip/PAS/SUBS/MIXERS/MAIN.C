/*$Author:   DCODY  $*/
/*$Date:   23 Jun 1992 16:45:22  $*/
/*$Header:   W:/sccs/mixers/main.c_v   1.1   23 Jun 1992 16:45:22   DCODY  $*/
/*$Log:   W:/sccs/mixers/main.c_v  $
 * 
 *    Rev 1.1   23 Jun 1992 16:45:22   DCODY
 * PAS2 update
 * 
 *    Rev 1.0   15 Jun 1992 09:41:26   BCRANE
 * Initial revision.
*/
/*$Logfile:   W:/sccs/mixers/main.c_v  $*/
/*$Modtimes$*/

#include <stdlib.h>

	int OurCallBackRoutine(char *);

	extern int MixerDialogInit ();
	extern int MixerDialogBox  ();
	extern int MixerGetSettings();
	extern int MixerDialogHalt ();

main(argc,argv)
	int argc;
	char *argv[];
{
char videochar = 0;

	// the only parameter is a decimal value to put up as a background character

		if (argc > 1)
			videochar = atoi (argv[1]);

	// initialize the dialog box just once

        if (!MixerDialogInit()) {

			// run the dialog box as many times has you want...

				MixerDialogBox	(videochar);

			// ask the mixer code to give us all the settings

				MixerGetSettings(&OurCallBackRoutine);

			// terminate the dialog box just once

				MixerDialogHalt ( );

        }
}


int OurCallBackRoutine(s)
	char *s;
{
	printf ("%s\n",s);
}


