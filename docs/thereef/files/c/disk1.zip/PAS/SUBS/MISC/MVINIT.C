/*$Author:   DCODY  $*/
/*$Date:   23 Jun 1992 16:33:06  $*/
/*$Header:   W:/sccs/misc/mvinit.c_v   1.1   23 Jun 1992 16:33:06   DCODY  $*/
/*$Log:   W:/sccs/misc/mvinit.c_v  $
 * 
 *    Rev 1.1   23 Jun 1992 16:33:06   DCODY
 * PAS2 update
 * 
 *    Rev 1.0   15 Jun 1992 09:39:58   BCRANE
 * Initial revision.
*/
/*$Logfile:   W:/sccs/misc/mvinit.c_v  $*/
/*$Modtimes$*/

    /*\
	|*|----====< MVINIT.C >====----
	|*|
	|*| This routine initializes the hardware to a playable state
    |*|
	\*/

main()
{
	printf ("MVINIT -- Media Vision Pro Audio Spectrum\n");
	printf ("          hardware initialization test program, 0.01.\n\n");
	printf ("          Hardware Version # = %04x\n",InitMVHardware());
}

