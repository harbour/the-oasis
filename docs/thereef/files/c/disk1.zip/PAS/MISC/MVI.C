/*$Author:   BCRANE  $*/
/*$Date:   15 Jun 1992 10:52:56  $*/
/*$Header:   W:/sccs/pastsr/mvi.c_v   1.0   15 Jun 1992 10:52:56   BCRANE  $*/
/*$Log:   W:/sccs/pastsr/mvi.c_v  $
 * 
 *    Rev 1.0   15 Jun 1992 10:52:56   BCRANE
 * Initial revision.
*/
/*$Logfile:   W:/sccs/pastsr/mvi.c_v  $*/
/*$Modtimes$*/
/*$Revision:   1.0  $*/
/*$Workfile:   mvi.c  $*/


    /*\
    |*|----====< MVI.C >====----
    |*|
    |*| This little program sends text commands to the MVPROAS DOS
    |*| device driver. After sending a command, the result is reported
    |*| back to the user.
    |*|
    \*/

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <io.h>

    /*\
    |*| global variables
    \*/

        char    buff[100],*b;
        int     proas;

    /*\
    |*|----====< Start of execution >====----
    \*/

main(argc,argv)
    int argc;
    char *argv[];
{
int n;

    /* open the device                                                  */

        if ((proas = open ("MVPROAS",O_RDWR, S_IREAD | S_IWRITE)) == -1) {
            printf ("\acannot open the MVPROAS device!\n");
            exit(0);
        }
    /* report the starting status                                       */

        ReportStatus();

    /* if there is data on the command line, process it, else stdin     */

        if (argc > 1) {

        /* build the combined string                                    */

            n = 1;
            while (n < argc ) {
                strcat (buff,argv[n++]);
                strcat (buff," ");
            }
            strcat (buff,"\n");


            b = buff;
            while (*b) b++;
            write   (proas,buff,b-buff);
            write   (proas,"\n",2);
            ReportStatus();

            close (proas);
            exit (0);
        }

    /* get text from stdin                                              */

        while (!feof(stdin)) {

            printf (">");               // give the user a prompt
            fgets (buff,100,stdin);     // get the next string
            if (buff[0] == 0x0a)        // if null, exit to DOS
                break;
            if (buff[0] != '?') {       // '?' is used to query the status
                b = buff;
                while (*b) b++;
                write   (proas,buff,b-buff);
                write   (proas,"\n",2);
            }
            ReportStatus();             // return the state
        }

        close (proas);

}


    /*\
    |*|----====< ReportStatus >====----
    |*|
    |*| This procedure reports the current text message from MVPROAS
    |*|
    \*/

ReportStatus()
{
char text[256],*t;

    /* if busy, report it till the cows come home (10 seconds max)      */

        while (1) {
            read(proas,text,256);

            t = text;
            while (*t != 0x0a)
                putch (*t++);
            putch (0xd);
            putch (0xa);

            read(proas,text,256);
            if (text[0] != 'B')
                break;
        }

}


    /*\
    |*| end of MVI.C
    \*/


