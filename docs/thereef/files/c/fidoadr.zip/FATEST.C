#include <stdio.h>

#include "fidoadr.h"

void main(int argc, char **argv)
{
    FILE *infil;
    FIDOADR fadr;
    char *p;
    word net, node;
    char addr[32], addr2[32];

    printf("FIDOADR routines test program - David H. Bennett - 3/7/92 - V 1.0\n\n");

    if (argc == 1) infil = stdin;
    else infil = fopen(argv[1], "rt");

    printf("%-32s %5s %5s %5s %5s %s\n","string","zone","net","node","point","domain");
    printf("------------------------------------------------------------------\n");
    while (!feof(infil)) {

        fgets(addr, 80, infil);
        p = &(addr[strlen(addr)-1]);
        if (*p == '\n') *p = '\0';

        fidoadr_split(addr, &fadr);

        printf("%-32s %5d %5d %5d %5d %s\n",addr,fadr.zone,fadr.net,fadr.node,fadr.point,fadr.domain);
    }
    putchar('\n');

    /*
     * Second portion
     */
    rewind(infil);

    printf("%-32s %-32s\n","in address","out address");
    printf("------------------------------------------------------------------\n");
    while (!feof(infil)) {

        fgets(addr, 80, infil);
        p = &(addr[strlen(addr)-1]);
        if (*p == '\n') *p = '\0';

        fidoadr_split(addr, &fadr);
        fidoadr_merge(addr2, &fadr);

        printf("%-32s %-32s\n", addr, addr2);
    }
    putchar('\n');

    /*
     * Test the hex functions
     */
    strcpy(addr, "01180133");
    hexadr_split(addr, &net, &node);
    printf("hexadr_split : %s -> %u %u\n", addr, net, node);

    *addr = '\0';
    hexadr_merge(addr, net, node);
    printf("hexadr_merge : %u %u -> %s\n", net, node, addr);
}

