/*		(c) R&D Associates 1992.
		All Rights Reserved.

	cmsc70.c

This file should be converted to a Clint definition library by:

	clint cmsc70.c -I/c700/include -L cmsc70 -w0
*/

#include <assert.h>
#include <bios.h>
#include <conio.h>
#include <ctype.h>
#include <direct.h>
#include <dos.h>
#include <errno.h>
#include <ext.h>
#include <fcntl.h>
#include <float.h>
#include <graph.h>
#include <io.h>
#include <limits.h>
#include <locale.h>
#include <malloc.h>
#include <math.h>
#include <memory.h>
#include <new.h>
#include <pgchart.h>
#include <process.h>
#include <readchar.h>
#include <search.h>
#include <setjmp.h>
#include <share.h>
#include <signal.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <vmemory.h>
#include <sys/types.h>
#include <sys/locking.h>
#include <sys/stat.h>
#include <sys/timeb.h>
#include <sys/utime.h>
