/*		(c) R&D Associates 1991.
		All Rights Reserved.

	cztc21.c

This file should be converted to a Clint definition library by:

	clint cztc21.c -I/tc/include -L cztc21 -w0
*/

#include <assert.h>
#include <bios.h>
#include <conio.h>
#include <ctype.h>
#include <direct.h>
#include <disp.h>
#include <dos.h>
#include <dos16.h>
#include <emm.h>
#include <errno.h>
#include <fcntl.h>
#include <fg.h>
#include <float.h>
#include <handle.h>
#include <int.h>
#include <io.h>
#include <limits.h>
#include <locale.h>
#include <math.h>
#include <msmouse.h>
#include <page.h>
#include <process.h>
#include <setjmp.h>
#include <share.h>
#include <signal.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/timeb.h>

/* End of file. */
