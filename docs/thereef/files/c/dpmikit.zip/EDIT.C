/******************************************************************************
 *
 *	Program Name:	TALK_TO.ME 
 *
 *	Filename:	EDIT.C -- 10/25/88
 *
 *	Purpose:  Displays keyboard input and enters the input in a buffer
 *
 ******************************************************************************/

#include <stdio.h>
#include <dos.h>
#include <nit.h>
#include "chat.h"

void 	Dispatcher();
void 	DisplayChar();
int 		InputChar();
void 	DeleteChar();
void 	DisplayOff();

extern int	PRINT_FLAG,
			RECEIVE_FLAG;

char	charBuffer;

int 	sendRow = TOP_SEND_ROW,
		sendCol = FIRST_TEXT_COL,
		receiveRow = TOP_RECEIVE_ROW,
		receiveCol = FIRST_TEXT_COL;


void Dispatcher(key)
char	key;
{
	int		ccode;

	if (key == TAB)
		ClearSendBox();
	
	else if (key == ENTER)
	{
		sendRow++;
		if (sendRow > LAST_SEND_ROW) 
		{
			sendRow = LAST_SEND_ROW;
			ScrollUp (1, TOP_SEND_ROW, LAST_SEND_ROW, FIRST_TEXT_COL, LAST_TEXT_COL);
		}
		sendCol = FIRST_TEXT_COL;
		SetCursor(sendRow,sendCol);
	}
	
	else if (key == BACKSPACE)
	{
		if (sendCol > FIRST_TEXT_COL)
			DeleteChar (&sendCol, &sendRow);
	}
	
	else if ( key == 0 || (key > 6 && key < 20) )
	{
		key = 2;
		DisplayChar(key);
	}
	else
		DisplayChar(key);
	
	SendPacket(&key);
}						


void DisplayChar(key)
char	key;
{
	if(sendCol == LAST_TEXT_COL)
	{
		sendCol = FIRST_TEXT_COL;
		sendRow++;
		if (sendRow > LAST_SEND_ROW) 
		{
			sendRow = LAST_SEND_ROW;
			ScrollUp (1, TOP_SEND_ROW, LAST_SEND_ROW, FIRST_TEXT_COL, LAST_TEXT_COL);
		}
	}
	SetCursor(sendRow,sendCol++);
	WriteChar(key);
	SetCursor(sendRow,sendCol);
}


void DeleteChar(col,row)
int		*col, *row;
{
	--*col;
	SetCursor(*row, *col);
	WriteChar(' ');
	SetCursor(*row, *col);
}


