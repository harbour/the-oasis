/****************************************************************************
   CHECKREG.C - Validates a key created by REG'EM
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define REGEM 99999 /* <<<<<<<<<<<<< This Number should not be changed.*/
                    /* program may not work proper if changed. */
                    /* this tells the key maker how many different   */
                    /* combination's of key seed's are possible, and to */
                    /* hide your program code you entered when you Added*/
                    /* your program to the list. That way there is */
                    /* no library to link to your source. 99999 and your*/
                    /* 5 diget key code with the Xor and Other */
                    /* calculations the maker uses make a 13 diget */
                    /* key for your program. */
                    
                    /* We recomend that you remove all comments from this*/
                    /* file before your final compile !!! More Below */

char r_name[27];
char r_full_number[20];
long r_key;
long r_number;
int checkem(void)
{
    int count=0;
    int r_counter=0;
    char temp[20];
    FILE *config_file;   /*vvvvvvvvv Enter Your Key file Name Here */
    if((config_file=fopen("regem.key","r"))==NULL)
        fclose(config_file);
    fgets(r_name,27,config_file);           
    fgets(r_full_number,20,config_file);    
    *strchr(r_name, '\n') = '\0';
    *strchr(r_full_number, '\n') = '\0';
    while(r_name[count]!='\0')
        {
        r_counter=r_counter+r_name[count];
        count++;
        }
    temp[0]='\0';
    strncpy(temp,r_full_number,6);
    r_key=atol(temp);
    temp[0]='\0';
    count=0;
    while(r_full_number[count+6]!='\0')
        {
        temp[count]=r_full_number[count+6];
        count++;
        }
    r_number=atol(temp);
    r_key=r_key^REGEM;
    if(r_number!=r_counter*r_key || r_number==0)
       {
       fclose(config_file);                          /* This re-writes the*/
       if((config_file=fopen("regem.key","w"))==NULL)/* key file if the key*/
           return(1);                                /* is invalid */
       stpcpy(r_name,"unregistered copy");           /* Put whatever you */
       r_full_number[0]='0';                       /* want for unregistered */
       r_full_number[1]='\0';                      /* here */
       fprintf(config_file,"%s\n%s",r_name,r_full_number);
       fclose(config_file);
       #include "text.c"
       return(0);
       }
    fclose(config_file);                         /* Put what ever you want */
    clrscrn2(0x1f);                              /* for registered version */
    printf("\nRegistered Copy! \n"); /* here */
    sleep(2);
    return(0);
}
