#include "extend.api"
#include "item.api"

/****
*
*    NOTE:
*
*    compile with BORLAND C++ 3.00 :
*
*    BCC -c -ml -f- -a -r -B -Z -I<your include path> bsg.c
*
*    Note 2 by Luiz Rafael Culik Guimaraes Culik@sl.conex.net (Brazil)
*    Using the CA-CLIPPER 5.3 api function, you don't got GPFs errors.
*    The replication of the other 119 __BSG functions was made by a small
*    Clipper Program
*
*    (Luiz compiled with BC++ 5.00 and got no GPFs)
*
*    the bsg.c was compiled with the follow switches:
*     -ml -c -f- -O2 -N -p- -I\clip53\include;\bc5\include
*/


/*  Internal CLASS Creation  */
typedef unsigned long CLASSID;
extern CLASSID   _mdCreate( USHORT uiCount, FARP fpName );
extern void      _mdAdd( CLASSID ulClass, FARP fpName, FARP fpFunc);
extern void      _mdAssociate( ITEM npArray, CLASSID ulClass);
extern FARP      _get_sym( BYTEP cpName );
#define QSelf()  _itemParam( 0 )


/****
*     This evaluates a passed IVar code block
*     0   parameter is self[<nVar>] --> block
*     1st parameter is self
*     2rd...12th parameter is code block arguments
*/

/*---------------------------------------------------------------------------*/
CLIPPER __BSG001( void )
/*---------------------------------------------------------------------------*/
{
    USHORT uiParam ;
    EVALINFO info  ;
    ITEM retP      ;
    ITEM iSelf  = _itemParam(0) ;           // This is the self parameter
                                            // it is hidden as the #0 PCOUNT
                                            // argument.

    ITEM iBlock = _itemArrayGet(iSelf, 1);  // The code block argument.
                                            // must match the function
                                            // number

    _evalNew( &info, iBlock ) ;             // init the eval stack with iBlock
    _evalPutParam( &info, iSelf ) ;         // and add iSelf parameter 1st

    for( uiParam = 1; uiParam <= PCOUNT; uiParam++)
    {
       _evalPutParam( &info, _itemParam(uiParam) ) ;
    }

    retP = _evalLaunch( &info ) ;
    _evalRelease( &info ) ;
    _itemReturn( retP ) ;
    _itemRelease( iBlock ) ;
    _itemRelease( iSelf ) ;
    _itemRelease( retP ) ;
    return;
}


/*---------------------------------------------------------------------------*/
CLIPPER __BSG002( void )
/*---------------------------------------------------------------------------*/
{
    USHORT uiParam ;
    EVALINFO info  ;
    ITEM retP      ;
    ITEM iSelf  = _itemParam(0) ;
    ITEM iBlock = _itemArrayGet(iSelf, 2);

    _evalNew( &info, iBlock ) ;
    _evalPutParam( &info, iSelf ) ;

    for( uiParam = 1; uiParam <= PCOUNT; uiParam++)
    {
       _evalPutParam( &info, _itemParam(uiParam) ) ;
    }

    retP = _evalLaunch( &info ) ;
    _evalRelease( &info ) ;
    _itemReturn( retP ) ;
    _itemRelease( iBlock ) ;
    _itemRelease( iSelf ) ;
    _itemRelease( retP ) ;
    return;
}



/*---------------------------------------------------------------------------*/
CLIPPER __BSG003( void )
/*---------------------------------------------------------------------------*/
{
    USHORT uiParam ;
    EVALINFO info  ;
    ITEM retP      ;
    ITEM iSelf  = _itemParam(0) ;
    ITEM iBlock = _itemArrayGet(iSelf, 3);

    _evalNew( &info, iBlock ) ;
    _evalPutParam( &info, iSelf ) ;

    for( uiParam = 1; uiParam <= PCOUNT; uiParam++)
    {
       _evalPutParam( &info, _itemParam(uiParam) ) ;
    }

    retP = _evalLaunch( &info ) ;
    _evalRelease( &info ) ;
    _itemReturn( retP ) ;
    _itemRelease( iBlock ) ;
    _itemRelease( iSelf ) ;
    _itemRelease( retP ) ;
    return;
}


/*---------------------------------------------------------------------------*/
CLIPPER __BSG004( void )
/*---------------------------------------------------------------------------*/
{
    USHORT uiParam ;
    EVALINFO info  ;
    ITEM retP      ;
    ITEM iSelf  = _itemParam(0) ;
    ITEM iBlock = _itemArrayGet(iSelf, 4);

    _evalNew( &info, iBlock ) ;
    _evalPutParam( &info, iSelf ) ;

    for( uiParam = 1; uiParam <= PCOUNT; uiParam++)
    {
       _evalPutParam( &info, _itemParam(uiParam) ) ;
    }

    retP = _evalLaunch( &info ) ;
    _evalRelease( &info ) ;
    _itemReturn( retP ) ;
    _itemRelease( iBlock ) ;
    _itemRelease( iSelf ) ;
    _itemRelease( retP ) ;
    return;
}




/*---------------------------------------------------------------------------*/
CLIPPER __BSG005( void )
/*---------------------------------------------------------------------------*/
{
    USHORT uiParam ;
    EVALINFO info  ;
    ITEM retP      ;
    ITEM iSelf  = _itemParam(0) ;
    ITEM iBlock = _itemArrayGet(iSelf, 5);

    _evalNew( &info, iBlock ) ;
    _evalPutParam( &info, iSelf ) ;

    for( uiParam = 1; uiParam <= PCOUNT; uiParam++)
    {
       _evalPutParam( &info, _itemParam(uiParam) ) ;
    }

    retP = _evalLaunch( &info ) ;
    _evalRelease( &info ) ;
    _itemReturn( retP ) ;
    _itemRelease( iBlock ) ;
    _itemRelease( iSelf ) ;
    _itemRelease( retP ) ;
    return;
}


/*---------------------------------------------------------------------------*/
CLIPPER __BSG006( void )
/*---------------------------------------------------------------------------*/
{
    USHORT uiParam ;
    EVALINFO info  ;
    ITEM retP      ;
    ITEM iSelf  = _itemParam(0) ;
    ITEM iBlock = _itemArrayGet(iSelf, 6);

    _evalNew( &info, iBlock ) ;
    _evalPutParam( &info, iSelf ) ;

    for( uiParam = 1; uiParam <= PCOUNT; uiParam++)
    {
       _evalPutParam( &info, _itemParam(uiParam) ) ;
    }

    retP = _evalLaunch( &info ) ;
    _evalRelease( &info ) ;
    _itemReturn( retP ) ;
    _itemRelease( iBlock ) ;
    _itemRelease( iSelf ) ;
    _itemRelease( retP ) ;
    return;
}


/*---------------------------------------------------------------------------*/
CLIPPER __BSG007( void )
/*---------------------------------------------------------------------------*/
{
    USHORT uiParam ;
    EVALINFO info  ;
    ITEM retP      ;
    ITEM iSelf  = _itemParam(0) ;
    ITEM iBlock = _itemArrayGet(iSelf, 7);

    _evalNew( &info, iBlock ) ;
    _evalPutParam( &info, iSelf ) ;

    for( uiParam = 1; uiParam <= PCOUNT; uiParam++)
    {
       _evalPutParam( &info, _itemParam(uiParam) ) ;
    }

    retP = _evalLaunch( &info ) ;
    _evalRelease( &info ) ;
    _itemReturn( retP ) ;
    _itemRelease( iBlock ) ;
    _itemRelease( iSelf ) ;
    _itemRelease( retP ) ;
    return;
}


/*---------------------------------------------------------------------------*/
CLIPPER __BSG008( void )
/*---------------------------------------------------------------------------*/
{
    USHORT uiParam ;
    EVALINFO info  ;
    ITEM retP      ;
    ITEM iSelf  = _itemParam(0) ;
    ITEM iBlock = _itemArrayGet(iSelf, 8);

    _evalNew( &info, iBlock ) ;
    _evalPutParam( &info, iSelf ) ;

    for( uiParam = 1; uiParam <= PCOUNT; uiParam++)
    {
       _evalPutParam( &info, _itemParam(uiParam) ) ;
    }

    retP = _evalLaunch( &info ) ;
    _evalRelease( &info ) ;
    _itemReturn( retP ) ;
    _itemRelease( iBlock ) ;
    _itemRelease( iSelf ) ;
    _itemRelease( retP ) ;
    return;
}


/*---------------------------------------------------------------------------*/
CLIPPER __BSG009( void )
/*---------------------------------------------------------------------------*/
{
    USHORT uiParam ;
    EVALINFO info  ;
    ITEM retP      ;
    ITEM iSelf  = _itemParam(0) ;
    ITEM iBlock = _itemArrayGet(iSelf, 9);

    _evalNew( &info, iBlock ) ;
    _evalPutParam( &info, iSelf ) ;

    for( uiParam = 1; uiParam <= PCOUNT; uiParam++)
    {
       _evalPutParam( &info, _itemParam(uiParam) ) ;
    }

    retP = _evalLaunch( &info ) ;
    _evalRelease( &info ) ;
    _itemReturn( retP ) ;
    _itemRelease( iBlock ) ;
    _itemRelease( iSelf ) ;
    _itemRelease( retP ) ;
    return;
}


/*---------------------------------------------------------------------------*/
CLIPPER __BSG010( void )
/*---------------------------------------------------------------------------*/
{
    USHORT uiParam ;
    EVALINFO info  ;
    ITEM retP      ;
    ITEM iSelf  = _itemParam(0) ;
    ITEM iBlock = _itemArrayGet(iSelf, 10);

    _evalNew( &info, iBlock ) ;
    _evalPutParam( &info, iSelf ) ;

    for( uiParam = 1; uiParam <= PCOUNT; uiParam++)
    {
       _evalPutParam( &info, _itemParam(uiParam) ) ;
    }

    retP = _evalLaunch( &info ) ;
    _evalRelease( &info ) ;
    _itemReturn( retP ) ;
    _itemRelease( iBlock ) ;
    _itemRelease( iSelf ) ;
    _itemRelease( retP ) ;
    return;
}


