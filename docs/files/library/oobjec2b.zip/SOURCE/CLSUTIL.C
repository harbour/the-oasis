#include "extend.api"
#include "item.api"


/****
*      ooEndIns( aIVars, oSelf )
*
*      Assign values to the new Self elements.
*      Called from o:EndInsert()
*      (Gives internal error 650)
*/

CLIPPER ooEndIns()
{   int i;
    USHORT nSize;
    ITEM o_ivars  = _itemParam(1);
    ITEM o_newobj = _itemParam(2);
    ITEM iElem, bFunc;

    nSize = _itemSize( o_ivars );
    for(i=1;i<nSize;i++)
    {
        iElem = _itemArrayGet( o_ivars, i);
        bFunc = _itemArrayGet( iElem, 2);
        if( _itemType(bFunc) == BLOCK )
        {
            _itemArrayPut( o_newobj, i, bFunc );
        }
        else
        {
            _itemArrayPut( o_newobj, i, _itemArrayGet(iElem,3) );
        }
    }
    _itemRelease( o_ivars );
    _itemRelease( o_newobj );
    _itemRelease( iElem );
    _itemRelease( bFunc );
}


