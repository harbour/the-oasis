/*
 * File......: MKDIR.C
 * Author....: Dave Pearson
 * BBS.......: The Dark Knight Returns
 * Net/Node..: 050/069
 * User Name.: Dave Pearson
 * Date......: $Date$
 * Revision..: $Revision$
 * Log file..: $Logfile$
 *
 * This is an original work by Dave Pearson and is placed in the public
 * domain.
 *
 * Modification history:
 * ---------------------
 *
 * $Log$
 *
 */

// NOTE: This code has been written for and compiled with Borland C++
//       Version 3.1
//

#include <extend.h>
#include "internal.h"

/*  $DOC$
 *  $FUNCNAME$
 *      GT_MKDIR()
 *  $CATEGORY$
 *      Disk Drive
 *  $ONELINER$
 *      Make a new directory.
 *  $SYNTAX$
 *      GT_MkDir(<cDir>,[@<nError>]) --> lMade
 *  $ARGUMENTS$
 *      <cDir> is the path of the directory to be made.
 *
 *      <nError> is an optional parameter that must be passed by reference.
 *      If the directory creation fails the DOS error code will be placed in
 *      this variable.
 *  $RETURNS$
 *      If the directory was made, GT_MkDir() returns true (.T.), if not it
 *      returns false (.F.).
 *  $DESCRIPTION$
 *      GT_MkDir() can be used to make a new directory.
 *  $EXAMPLES$
 *      // Make a new directory.
 *
 *      nError := 0
 *      if !GT_MkDir("Knight",@nError)
 *         ? "Error =",nError
 *      endif
 *  $SEEALSO$
 *      GT_CHDIR() GT_RMDIR()
 *  $END$
 */

CLIPPER GT_MkDir()
{
        _GT_Internal_Directory(0x39);
}
