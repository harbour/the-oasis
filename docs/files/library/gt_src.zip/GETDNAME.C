/*****************************************************************************
* Function: _GT_Internal_GetDriveName()                                      *
* Syntax..: char _GT_Internal_GetDriveName(int Parameter)                    *
* Usage...: Internal function to get a drive name.                           *
* By......: David A Pearson                                                  *
*****************************************************************************/

#include <extend.h>

char _GT_Internal_GetDriveName(int Parameter)
{
        char Drive = 0;

        if (ISCHAR(Parameter))
        {
                Drive = _parc(Parameter)[0];
                if (Drive >= 'a' && Drive <= 'z')
                {
                        Drive -= 0x60;
                }
                else if (Drive >= 'A' && Drive <= 'Z')
                {
                        Drive -= 0x40;
                }
                else
                {
                        Drive = 0;
                }
        }
        else if (ISNUM(Parameter))
        {
                Drive = (char)_parni(Parameter);
        }
        return(Drive);
}
