/*
 * File......: PSPSEG.C
 * Author....: Dave Pearson
 * BBS.......: The Dark Knight Returns
 * Net/Node..: 050/069
 * User Name.: Dave Pearson
 * Date......: $Date$
 * Revision..: $Revision$
 * Log file..: $Logfile$
 *
 * This is an original work by Dave Pearson and is placed in the public
 * domain.
 *
 * Modification history:
 * ---------------------
 *
 * $Log$
 *
 */

// NOTE: This code has been written for and compiled with Borland C++
//       Version 3.1
//

#include <extend.h>

/*  $DOC$
 *  $FUNCNAME$
 *      GT_PSPSEG()
 *  $CATEGORY$
 *      Environment
 *  $ONELINER$
 *      Get the location of the program's PSP.
 *  $SYNTAX$
 *      GT_PspSeg() --> nPSPSegment
 *  $ARGUMENTS$
 *      None.
 *  $RETURNS$
 *      The location of the program's PSP.
 *  $DESCRIPTION$
 *      GT_PspSeg() can be used to gain access to your programs PSP.
 *  $EXAMPLES$
 *      // Display the location of the PSP.
 *
 *      ? GT_PspSeg()
 *  $SEEALSO$
 *  $END$
 */

CLIPPER GT_PspSeg()
{
        asm     Mov     AH,0x62
        asm     Int     0x21
        _retnl(_BX);
}
