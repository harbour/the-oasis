/*
 * GT CLIPPER STANDARD HEADER
 *
 * File......: argc.c
 * Author....: Andy M Leighton
 * BBS.......: The Dark Knight Returns
 * Net/Node..: 050/069
 * User Name.: Andy Leighton
 * Date......: $Date$
 * Revision..: $Revision$
 *
 * This is an original work by Andy Leighton and is placed in the
 * public domain.
 *
 * Modification history:
 * ---------------------
 *
 * $Log$
 *
 */

/*
 *  $DOC$
 *  $FUNCNAME$
 *      GT_ARGC()
 *  $CATEGORY$
 *      Environment
 *  $ONELINER$
 *      Returns the number of parameters on the command line
 *  $SYNTAX$
 *      GT_argc() --> nCount
 *  $ARGUMENTS$
 *      None
 *  $RETURNS$
 *      nCount  - The number of command line parameters.
 *  $DESCRIPTION$
 *      Get the number of parameters passed to the Exe
 *      Reads the C startup variable to find the number of parameters
 *
 *      Note there is always 1 parameter.  In C argv[0] always equals
 *      the EXE name in non prehistoric DOSes
 *  $EXAMPLES$
 *      ? "I have been passed " + str(GT_Argc()) + " parameters."
 *  $END$
 */

#include "extend.h"

extern int __argc;

CLIPPER
GT_argc()
{
  _retni(__argc);
}
