/*
 * File......: HANG.C
 * Author....: Dave Pearson
 * BBS.......: The Dark Knight Returns
 * Net/Node..: 050/069
 * User Name.: Dave Pearson
 * Date......: $Date$
 * Revision..: $Revision$
 * Log file..: $Logfile$
 *
 * This is an original work by Dave Pearson and is placed in the public
 * domain.
 *
 * Modification history:
 * ---------------------
 *
 * $Log$
 *
 */

// NOTE: This code has been written for and compiled with Borland C++
//       Version 3.1
//

#include <extend.h>

/*  $DOC$
 *  $FUNCNAME$
 *      GT_HANG()
 *  $CATEGORY$
 *      General
 *  $ONELINER$
 *      Hang the computer.
 *  $SYNTAX$
 *      GT_Hang([<lAllowCtrlAltDel>]) --> <ThisNeverReturns!>
 *  $ARGUMENTS$
 *      <lAllowCtrlAltDel> is an optional logical value. If true (.T.)
 *      the user will be able to use Ctrl-Alt-Del to reset the machine,
 *      if false (.F.) the user will have to turn the machine off.
 *      The deafult value is .F.
 *  $RETURNS$
 *      This function should never return!
 *  $DESCRIPTION$
 *      Err.... I'm sure that one of you will find a use for this! <g>
 *  $EXAMPLES$
 *      // Get the user to log into the system, if the login is invalid
 *      // hang the machine.
 *
 *      if SysLogin()
 *         RunSystem()
 *      else
 *         GT_Hang()
 *      endif
 *  $END$
 */

CLIPPER GT_Hang()
{
        Boolean AllowCtrlAltDel = FALSE;

        if (PCOUNT >= 1 && ISLOG(1))
        {
                AllowCtrlAltDel = _parl(1);
        }
        if (!AllowCtrlAltDel)
        {
                asm     Cli
        }
HangLoop:
        asm     Jmp     HangLoop
}
