/*
 * File......: RMDIR.C
 * Author....: Dave Pearson
 * BBS.......: The Dark Knight Returns
 * Net/Node..: 050/069
 * User Name.: Dave Pearson
 * Date......: $Date$
 * Revision..: $Revision$
 * Log file..: $Logfile$
 *
 * This is an original work by Dave Pearson and is placed in the public
 * domain.
 *
 * Modification history:
 * ---------------------
 *
 * $Log$
 *
 */

// NOTE: This code has been written for and compiled with Borland C++
//       Version 3.1
//

#include <extend.h>
#include "internal.h"

/*  $DOC$
 *  $FUNCNAME$
 *      GT_RMDIR()
 *  $CATEGORY$
 *      Disk Drive
 *  $ONELINER$
 *      Remove a directory.
 *  $SYNTAX$
 *      GT_RmDir(<cDir>,[@<nError>]) --> lRemoved
 *  $ARGUMENTS$
 *      <cDir> is the path of the directory.
 *
 *      <nError> is an optional parameter that must be passed by reference.
 *      If the directory can't be removed the DOS error code will be placed
 *      in this variable.
 *  $RETURNS$
 *      If the directory was removed , GT_RmDir() returns true (.T.), if
 *      not it returns false (.F.).
 *  $DESCRIPTION$
 *      GT_RmDir() can be used to remove a directory.
 *  $EXAMPLES$
 *      // Remove a directory.
 *
 *      nError := 0
 *      if !GT_RmDir("Knight",@nError)
 *         ? "Error =",nError
 *      endif
 *  $SEEALSO$
 *      GT_MKDIR() GT_CHDIR()
 *  $END$
 */

CLIPPER GT_RmDir()
{
        _GT_Internal_Directory(0x3A);
}
