/*
 * GT CLIPPER STANDARD HEADER
 *
 * File......: exename.c
 * Author....: Andy M Leighton
 * BBS.......: The Dark Knight Returns
 * Net/Node..: 050/069
 * User Name.: Andy Leighton
 * Date......: $Date$
 * Revision..: $Revision$
 *
 * This is an original work by Andy Leighton and is placed in the
 * public domain.
 *
 * Modification history:
 * ---------------------
 *
 * $Log$
 *
 */

/*
 *  $DOC$
 *  $FUNCNAME$
 *      GT_EXENAME()
 *  $CATEGORY$
 *      Environment
 *  $ONELINER$
 *      Return the name of the .EXE.
 *  $SYNTAX$
 *      GT_exename() --> cName
 *  $ARGUMENTS$
 *      None
 *  $RETURNS$
 *      cName   - The name of the EXE
 *  $DESCRIPTION$
 *      Get the name of the exe file ran up
 *      Reads the PSP segment to find the executable name.
 *  $EXAMPLES$
 *      ? "Currently running " + GT_exename()
 *  $END$
 */

#include "extend.h"

extern unsigned int _psp;

CLIPPER
GT_exename()
{
   _retc((unsigned char *)(_psp * (unsigned int )(16 - 44)));
}
