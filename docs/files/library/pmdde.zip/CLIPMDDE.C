/*_____________________________________________________________________________
*
*           Author: Terry Carmen 
* 			Released to the Public Domain 6/17/97
*_____________________________________________________________________________
*
*
*     Program Name:   clipmdde.c   Clipper interface for PMDDE.DLL
*        $Revision:   1.0  $
*            $Date:   29 Feb 1996 18:00:26  $
*
*
*
* Revision History:
*             $Log:   D:/PROG/PAGER/VCS/CLIPMDDE.C_V  $
 * 
 *    Rev 1.0   29 Feb 1996 18:00:26
 * Initial revision.
*
*_____________________________________________________________________________
*/

#include <windows.h>
#include <string.h>
#include <commdlg.h>


#define CHARACTER    1
#define NUMERIC      2

#define FALSE      0
#define TRUE       1

#define CLIPPER   void pascal

#define MAX_PATH_LENGTH  128
#define MAX_GROUP_NAME_LENGTH  128


void far * _xalloc(unsigned int numberOfBytes);
void far * _xgrab(unsigned int numberOfBytes);
void       _xfree(void far *allocatedBlock);

void _retc(char far *);
void _retni(int);
void _retl(int);
void _ret(void);

int          _parinfo( int );
unsigned int _parclen(int, ...);
char *       _parc(int, ...);
int          _parni(int, ...);


BOOL       FAR PASCAL pmCreateGroup(LPSTR);
BOOL       FAR PASCAL pmReloadGroup(LPSTR);
BOOL       FAR PASCAL pmDeleteGroup(LPSTR);
BOOL       FAR PASCAL pmShowGroup(LPSTR);
BOOL       FAR PASCAL pmDeleteItem(LPSTR);
BOOL       FAR PASCAL pmAddItem(LPSTR);
BOOL       FAR PASCAL pmReplaceItem(LPSTR);
char far * FAR PASCAL pmBeginRequest(LPSTR);
void       FAR PASCAL pmEndRequest(void);

int Parm1OK(int, int, int);


CLIPPER DELETEGROU()  //P
{
 
 size_t size_tGroupInfoLen;
 char * cpCRLF;
 char * cpGroupInfo;
 char * found;
 
 if (Parm1OK(_parinfo(0), _parinfo(1), _parclen(1)))
    {
     
     found=_fstrstr(pmBeginRequest("GROUPS"), _parc(1));
     pmEndRequest();
     // found is non-null if group exists
     // make sure it exists before deleting it
     
     if (found == NULL)   // can't delete because it doesn't exist
        _retl(FALSE);
     else
        {
         // see if the group is empty
         size_tGroupInfoLen=strlen(pmBeginRequest(_parc(1)));
         pmEndRequest();
         
         cpGroupInfo=(char NEAR *) LocalAlloc(LMEM_FIXED, size_tGroupInfoLen);
         if (cpGroupInfo == NULL)
            _retl(FALSE);
         else
            {
             // local alloc was sucessful
             strncpy(cpGroupInfo, pmBeginRequest(_parc(1)), size_tGroupInfoLen);
             pmEndRequest();
             
             cpGroupInfo=strstr(cpGroupInfo, "\x0D\x0A");
             cpCRLF=cpGroupInfo;
             cpCRLF++;
             cpCRLF++;
             
             cpCRLF=strstr(cpCRLF, "\x0D\x0A");
             // look for a second return/linefeed
             
             if (cpCRLF==NULL)
                 // no other contents!
                _retl(pmDeleteGroup(_parc(1)));
             else
                _retl(FALSE);
             // can't delete a non-empty group
             
             LocalFree((LOCALHANDLE)cpGroupInfo);
             
            }                          
        }
    }
 else
    _retl(FALSE);
 // params not OK
 
 return;
 
}


CLIPPER CREATEGROU()  //P
{
 if (Parm1OK(_parinfo(0), _parinfo(1), _parclen(1)))
    _retl(pmCreateGroup(_parc(1)));
 else
    _retl(FALSE);
 
 return;
 
}


CLIPPER SHOWGROUP()  
{
 
 if (Parm1OK(_parinfo(0), _parinfo(1), _parclen(1)))
    _retl(pmShowGroup(_parc(1)));
 else
    _retl(FALSE);
 
 return;
 
}



CLIPPER DELETEITEM()  
{
 if (Parm1OK(_parinfo(0), _parinfo(1), _parclen(1)))
    _retl(pmDeleteItem(_parc(1)));
 else
    _retl(FALSE);
 
 return;
 
}


CLIPPER RELOADGROU()  //P
{
 if (Parm1OK(_parinfo(0), _parinfo(1), _parclen(1)))
    _retl(pmReloadGroup(_parc(1)));
 else
    _retl(FALSE);
 
 return;
 
}



CLIPPER ADDITEM()  
{
 if (Parm1OK(_parinfo(0), _parinfo(1), _parclen(1)))
    _retl(pmAddItem(_parc(1)));
 else
    _retl(FALSE);
 
 return;
 
}



CLIPPER REPLACEITE()  //M
{
 if (Parm1OK(_parinfo(0), _parinfo(1), _parclen(1)))
    _retl(pmReplaceItem(_parc(1)));
 else
    _retl(FALSE);
 
 
 return;
 
}


CLIPPER GETGROUPLI()  //ST
{
 
 _retc(pmBeginRequest("GROUPS"));
 pmEndRequest();
 
 return;
 
}


CLIPPER GETGROUPCO()   //NTENTS
{
 
 /*
 This needs more work.
 
 The existance test will give a false positive if the group name
 requested is a substring of an actual group.
 
 example: GetGroupContents("My") will cause an error if
 the group "My Group" exists, while GetGroupContents("asdfjk")
 will simply return ""
 */
                                                     
                                                     
 char *  found;
 
 if (Parm1OK(_parinfo(0), _parinfo(1), _parclen(1)))
    {
     
     found=_fstrstr(pmBeginRequest("GROUPS"), _parc(1));
     pmEndRequest();
     
     // found is non-null if group exists
     
     if (found == NULL)
        _retc("");
     else
        {
         _retc(pmBeginRequest(_parc(1)));
         pmEndRequest();
        }
    }
 else
    _retc("");
 
 return;
} 





static int Parm1OK(int iPCount, int iPType, int iPLen)
{
 
 if (iPCount != 1)  /* how many params? we only need one! */
    return 0;
 
 if (iPType != CHARACTER) /* it had better be a string! */
    return 0;
 
 if (iPLen >  (MAX_GROUP_NAME_LENGTH - 1))  /* too long! */
    return 0;
 
 if (iPLen == 0)  /* can't use null strings! */
    return 0;
 
 return 1;
 
}
