#include <windows.h>
#include <ddeml.h>
#include <string.h>
#include <ctype.h>

#define MAX_ATOM_LENGTH 256
#define MAX_TRANSACTION_TIMEOUT 5000  /* 5 second timeout for shell DDE */


HINSTANCE hInst;
HGLOBAL  hgData     = NULL;

static BOOL   SendExecCmd(LPSTR lpszCmd);
static char far * trim (char far *str);
static void   DDEError(LPSTR, char *, UINT);


/*****************************************************************************/


BOOL FAR PASCAL _export pmCreateGroup(LPSTR lpszGroup)
{
 
 char buf[MAX_ATOM_LENGTH];
 
 if ((lstrlen(lpszGroup) > MAX_ATOM_LENGTH ) || (lstrlen(lpszGroup) == 0 ))
    return 0;
 
 if (lpszGroup && lstrlen(lpszGroup))
    {
     wsprintf(buf, "[CreateGroup(%s)]", lpszGroup);
    }
 
 return SendExecCmd(buf);
}

/*****************************************************************************/


BOOL FAR PASCAL _export pmDeleteGroup(LPSTR lpszGroup)
                                      
{
 
 char buf[MAX_ATOM_LENGTH];
 
 if ((lstrlen(lpszGroup) >MAX_ATOM_LENGTH ) || (lstrlen(lpszGroup) == 0 ))
    return 0;
 
 if (lpszGroup && lstrlen(lpszGroup))
    {
     wsprintf(buf, "[DeleteGroup(%s)]", lpszGroup);
    }
 
 return SendExecCmd(buf);
}

/*****************************************************************************/


BOOL FAR PASCAL _export pmReloadGroup(LPSTR lpszGroup)
                                      
{
 char buf[MAX_ATOM_LENGTH];
 
 if ((lstrlen(lpszGroup) >MAX_ATOM_LENGTH ) || (lstrlen(lpszGroup) == 0 ))
    return 0;
 
 if (lpszGroup && lstrlen(lpszGroup)) 
    {
     wsprintf(buf, "[Reload(%s)]", lpszGroup);
    }
 
 return SendExecCmd(buf);
}


/*****************************************************************************/


BOOL FAR PASCAL _export pmShowGroup(LPSTR lpszGroup)
                                    
{
 char buf[MAX_ATOM_LENGTH];
 
 if ((lstrlen(lpszGroup) >MAX_ATOM_LENGTH ) || (lstrlen(lpszGroup) == 0 ))
    return 0;
 
 if (lpszGroup && lstrlen(lpszGroup)) 
    {
     wsprintf(buf, "[ShowGroup(%s)]", lpszGroup);
    }
 
 return SendExecCmd(buf);
}


/*****************************************************************************/


BOOL FAR PASCAL _export pmDeleteItem(LPSTR lpszItem)
                                     
{
 char buf[MAX_ATOM_LENGTH];
 
 if ((lstrlen(lpszItem) >MAX_ATOM_LENGTH ) || (lstrlen(lpszItem) == 0 ))
    return 0;
 
 if (lpszItem && lstrlen(lpszItem)) 
    {
     wsprintf(buf, "[DeleteItem(%s)]", lpszItem);
    }
 
 return SendExecCmd(buf);
}


/*****************************************************************************/


BOOL FAR PASCAL _export pmAddItem(LPSTR lpszItem)
                                  
{
 char buf[MAX_ATOM_LENGTH];
 
 if ((lstrlen(lpszItem) >MAX_ATOM_LENGTH ) || (lstrlen(lpszItem) == 0 ))
    return 0;
 
 if (lpszItem && lstrlen(lpszItem)) 
    {
     wsprintf(buf, "[AddItem(%s)]", lpszItem);
    }
 
 return SendExecCmd(buf);
}


/*****************************************************************************/


BOOL FAR PASCAL _export pmReplaceItem(LPSTR lpszItem)
                                      
{
 char buf[MAX_ATOM_LENGTH];
 
 if ((lstrlen(lpszItem) >MAX_ATOM_LENGTH ) || (lstrlen(lpszItem) == 0 ))
    return 0;
 
 if (lpszItem && lstrlen(lpszItem)) 
    {
     wsprintf(buf, "[ReplaceItem(%s)]", lpszItem);
     
    }
 
 return SendExecCmd(buf);
}


/*****************************************************************************/


BOOL FAR PASCAL LibMain(HINSTANCE hInstance, WORD wDataSeg, WORD cbHeap)
                        
{
 hInst = hInstance;  /* Save the .DLL's instance handle. */
 
 return TRUE;
}


/*****************************************************************************/


HDDEDATA CALLBACK DDECallback(UINT wType, UINT wFmt, HCONV hConv, HSZ hsz1, HSZ hsz2, HDDEDATA hDDEData,
                              DWORD dwData1, DWORD dwData2)
                              
{
 switch (wType) 
    {
     default:
        return NULL;
        break;
    }
}


/*****************************************************************************/


static BOOL SendExecCmd(LPSTR lpszCmd)
                        
{
 DWORD dwDDEInst = 0L;
 UINT ui;
 HSZ hszProgman;
 HCONV hConv;
 HDDEDATA hExecData;
 
 trim(lpszCmd);
 
 if (lstrlen(lpszCmd) == 0)
    {
     MessageBox(NULL, "SendExecCmd(): Called with empty command string", "Error", MB_ICONASTERISK | MB_OK);
     return FALSE;
    }
 
 ui = DdeInitialize(&dwDDEInst, DDECallback, CBF_FAIL_ALLSVRXACTIONS, 0L);
 if (ui != DMLERR_NO_ERROR) 
    {
     DDEError( lpszCmd, "SendExecCmd(): Can't init DDEML", ui);
     return FALSE;
    }
 
 hszProgman = DdeCreateStringHandle(dwDDEInst, "PROGMAN", CP_WINANSI);
 if (hszProgman == NULL)
    {
     DDEError( lpszCmd, "SendExecCmd(): Unable to create string handle for PROGMAN", ui);
     DdeUninitialize(dwDDEInst);
     return FALSE;
    }
 
 hConv = DdeConnect(dwDDEInst, hszProgman, hszProgman, NULL);
 if (hConv == NULL)
    {
     DDEError( lpszCmd, "SendExecCmd(): Unable to establish DDE connection with PROGMAN", ui);
     DdeFreeStringHandle(dwDDEInst, hszProgman);
     DdeUninitialize(dwDDEInst);
     return FALSE;
    }
 
 if (DdeFreeStringHandle(dwDDEInst, hszProgman) == 0)
    {
     DDEError( lpszCmd, "SendExecCmd(): Unable to free string handle for PROGMAN", ui);
     DdeDisconnect(hConv);
     DdeUninitialize(dwDDEInst);
     return FALSE;
    }
 
 
 hExecData = DdeCreateDataHandle(dwDDEInst, lpszCmd, lstrlen(lpszCmd)+1, 0, NULL, 0, 0);
 if (hExecData == NULL)
    {
     DDEError( lpszCmd, "SendExecCmd(): Unable to create data handle for command", ui);
     DdeDisconnect(hConv);
     DdeUninitialize(dwDDEInst);
     return FALSE;
    }
 
 if (!DdeClientTransaction((void FAR *)hExecData, (DWORD)-1, hConv, NULL, 0, XTYP_EXECUTE, MAX_TRANSACTION_TIMEOUT, NULL))
    {
     DDEError( lpszCmd, "SendExecCmd(): Transaction Failed", ui);
     DdeFreeDataHandle(hExecData);
     DdeDisconnect(hConv);
     DdeUninitialize(dwDDEInst);
     return FALSE;
    }
 
 if (DdeFreeDataHandle(hExecData) == 0)
    {
     DDEError( lpszCmd, "SendExecCmd(): Unable to free hExec data handle", ui);
     DdeDisconnect(hConv);
     DdeUninitialize(dwDDEInst);
     return FALSE;
    }
 
 if (DdeDisconnect(hConv) == 0)
    {
     DDEError( lpszCmd, "SendExecCmd(): Unable to disconnect DDE conversation", ui);
     DdeUninitialize(dwDDEInst);
     return FALSE;
    }
 
 if (DdeUninitialize(dwDDEInst)== 0)
    {
     DDEError( lpszCmd, "SendExecCmd(): Unable to disconnect DDE conversation", ui);
     return FALSE;
    }
 
 
 return TRUE;
}


/*****************************************************************************/


char far * FAR PASCAL _export pmBeginRequest(LPSTR lpszCmd)
                                     
{
 DWORD    dwDataLen  = 0; 
 DWORD    dwDDEInst  = 0;
 HCONV    hConv      = 0;
 char far * szData   = 0;
 HSZ      hszCmd     = 0;
 HSZ      hszProgman = 0;
 HDDEDATA hData;
 UINT     ui         = 0;
 
 trim(lpszCmd);
 if (lstrlen(lpszCmd) == 0)
    {
     MessageBox(NULL, "pmRequest(): Called with empty command string", "Error", MB_ICONASTERISK | MB_OK);
     return NULL;
    }
 
 ui = DdeInitialize(&dwDDEInst, DDECallback, CBF_FAIL_ALLSVRXACTIONS, 0L);
 if (ui != DMLERR_NO_ERROR) 
    {
     DDEError( lpszCmd, "pmRequest(): Can't init DDEML", ui);
     return NULL;
    }
 
 hszProgman = DdeCreateStringHandle(dwDDEInst, "PROGMAN", CP_WINANSI);
 if (hszProgman == NULL)
    {
     DDEError( lpszCmd, "pmRequest(): Unable to create string handle for PROGMAN", ui);
     DdeUninitialize(dwDDEInst);
     dwDDEInst=NULL;
     return NULL;
    }
 
 
 hConv = DdeConnect(dwDDEInst, hszProgman, hszProgman, NULL);
 if (hConv == NULL)
    {
     DDEError( lpszCmd, "pmRequest(): Unable to establish DDE connection with PROGMAN", ui);
     DdeFreeStringHandle(dwDDEInst, hszProgman);
     DdeUninitialize(dwDDEInst);
     dwDDEInst=NULL;
     return NULL;
    }
 
 
 if (DdeFreeStringHandle(dwDDEInst, hszProgman) == 0)
    {
     DDEError( lpszCmd, "pmRequest(): Unable to free string handle for PROGMAN", ui);
     DdeDisconnect(hConv);
     hConv=NULL;
     
     DdeUninitialize(dwDDEInst);
     dwDDEInst=NULL;
     
     return NULL;
    }
 
 hszCmd = DdeCreateStringHandle(dwDDEInst, lpszCmd, CP_WINANSI);
 if (hszCmd == NULL)
    {
     DDEError( lpszCmd, "pmRequest(): Unable to create string handle for topic", ui);
     DdeDisconnect(hConv);
     hConv=NULL;
     
     DdeUninitialize(dwDDEInst);
     dwDDEInst=NULL;
     return NULL;
    }
 
 hData= DdeClientTransaction(NULL, (DWORD)-1, hConv, hszCmd, CF_TEXT, XTYP_REQUEST, 1000, NULL);
 if (hData == FALSE)
    DDEError( lpszCmd, "Transaction Failed", ui);
 
 
 DdeAccessData(hData, &dwDataLen);
 
  hgData=GlobalAlloc(GHND, dwDataLen);
 if (hgData == NULL)
    MessageBox(NULL, "pmRequest(): Unable to allocate global memory for data", "Error", MB_ICONASTERISK | MB_OK);
 else
    {
     szData=GlobalLock(hgData);
     if (szData != NULL)
        _fstrcpy(szData, (char *)DdeAccessData(hData, &dwDataLen));
    }

 DdeUnaccessData(hData);
 DdeFreeDataHandle(hData);
 DdeFreeStringHandle(dwDDEInst, hszCmd);
 DdeDisconnect(hConv);
 DdeUninitialize(dwDDEInst);
 
 return szData;
}


/*****************************************************************************/


void FAR PASCAL _export pmEndRequest()
{
    if (hgData != NULL)
      {
     GlobalUnlock(hgData);
     GlobalFree(hgData);
     hgData = NULL;
      }
   
   return;
}


/*****************************************************************************/


/*
**  TRIM.C - Remove leading, trailing, & excess embedded spaces
**
**  public domain by Bob Stout & Michael Dehlwes
*/

static char far *trim (char far *str)
{
 char far *ibuf;
 char far *obuf;
 
 if (str)
    {
     for (ibuf = obuf = str; *ibuf; )
        {
         while (*ibuf && (isspace (*ibuf)))
            ibuf++;
         if (*ibuf && (obuf != str))
            *(obuf++) = ' ';
         while (*ibuf && (!isspace (*ibuf)))
            *(obuf++) = *(ibuf++);
        }
     *obuf = '\0';
    }
 return (str);
}

/*****************************************************************************/


static void DDEError(LPSTR lpszCmd, char * cMessage, UINT idInst)
{
 char cMsgBuff[256];
 
 strcpy(cMsgBuff, cMessage);
 strcat(cMsgBuff, ".\nError executing command: \"");
 strcat(cMsgBuff, lpszCmd);
 strcat(cMsgBuff, "\"\nError code: ");
 
 switch (DdeGetLastError(idInst))
    {
     case DMLERR_NO_ERROR:      	      strcat(cMsgBuff, "DMLERR_NO_ERROR" );
        break;
     case DMLERR_ADVACKTIMEOUT:	      strcat(cMsgBuff, "DMLERR_ADVACKTIMEOUT" );
        break;
     case DMLERR_BUSY:	               strcat(cMsgBuff, "DMLERR_BUSY" );
        break;
     case DMLERR_DATAACKTIMEOUT:	      strcat(cMsgBuff, "DMLERR_DATAACKTIMEOUT" );
        break;
     case DMLERR_DLL_NOT_INITIALIZED:	strcat(cMsgBuff, "DMLERR_DLL_NOT_INITIALIZED" );
        /*  for some reason, this error also occurs if a showgroup
        transaction is issued for a nonexistant group  */
        
        break;
     case DMLERR_DLL_USAGE:	         strcat(cMsgBuff, "DMLERR_DLL_USAGE" );
        break;
     case DMLERR_EXECACKTIMEOUT:	      strcat(cMsgBuff, "DMLERR_EXECACKTIMEOUT" );
        break;
     case DMLERR_INVALIDPARAMETER:	   strcat(cMsgBuff, "DMLERR_INVALIDPARAMETER" );
        break;
     case DMLERR_LOW_MEMORY:	         strcat(cMsgBuff, "DMLERR_LOW_MEMORY" );
        break;
     case DMLERR_MEMORY_ERROR:	      strcat(cMsgBuff, "DMLERR_MEMORY_ERROR" );
        break;
     case DMLERR_NOTPROCESSED:	      strcat(cMsgBuff, "DMLERR_NOTPROCESSED" );
        break;
     case DMLERR_NO_CONV_ESTABLISHED:	strcat(cMsgBuff, "DMLERR_NO_CONV_ESTABLISHED" );
        break;
     case DMLERR_POKEACKTIMEOUT:	      strcat(cMsgBuff, "DMLERR_POKEACKTIMEOUT" );
        break;
     case DMLERR_POSTMSG_FAILED:	      strcat(cMsgBuff, "DMLERR_POSTMSG_FAILED" );
        break;
     case DMLERR_REENTRANCY:	         strcat(cMsgBuff, "DMLERR_REENTRANCY" );
        break;
     case DMLERR_SERVER_DIED:	         strcat(cMsgBuff, "DMLERR_SERVER_DIED" );
        break;
     case DMLERR_SYS_ERROR:	         strcat(cMsgBuff, "DMLERR_SYS_ERROR" );
        break;
     case DMLERR_UNADVACKTIMEOUT:	   strcat(cMsgBuff, "DMLERR_UNADVACKTIMEOUT" );
        break;
     case DMLERR_UNFOUND_QUEUE_ID:	   strcat(cMsgBuff, "DMLERR_UNFOUND_QUEUE_ID" );
        break;
    }
 
 MessageBox(NULL, cMsgBuff, "Error", MB_ICONASTERISK | MB_OK);
 
 return;
}


/*****************************************************************************/
