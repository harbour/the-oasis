#include "clipper.api"

CLIPPER LFNSupport (void)
{
   _retl (_tlfn);
}
