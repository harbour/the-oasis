
#include <stdio.h>

void limerick (void)
{
   printf ("There was a young fellow from Microsoft\n");
}
