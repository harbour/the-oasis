void limerick (void);

void main ()
{
    limerick ();
}
