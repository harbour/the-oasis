// 12-27-91 09:15pm
// Author: David Tessitore
// Phone #: 516-351-4987
// Compuserve I.D. [70640,1355]
//
// KSG 09/94 changed the name of the function so that there are
//           no naming conflicts with other functions.
//

#include "EXTEND.H"
#define CHARACTER_ROWS 16

/****

Syntax:

 KG_Chars(nAsciiNumber,aChar)

 nAsciiNumber =  1 to 255 (charcter number to replace)
 aChar        =  array of new character in 8x14

**/

static char aNewChar[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static int nReplace = 0;


CLIPPER KG_Chars()
{
	 int x;
	 nReplace = _parni(1);                  /* Store character to replace   */

	 for (x = 0; x < CHARACTER_ROWS ; x++)  /* Fill c's array with clippers */
	 		  aNewChar[x] = _parni(2,x+1);      /* array                        */

/*
   Start in-line assebly code. MSC 6.0
*/

	 _asm
	  {
      PUSH  bp										; Save environment.
      push  es

			MOV     ax, SEG aNewChar    ; We need segment address of New Character array
      MOV     es, ax
      MOV     bp, offset aNewChar ; and offset address of New Character array.
      MOV     ax, 1100h           ; Load user font function number.
      mov     bx, 1000h           ; Set up for page 0, current crt screen.
      mov     cx, 1               ; We want 1 character
      mov     dx,nReplace         ; Character to replace in ASCII TABLE.
      int     10h                 ; Load new character.

      pop     es
      pop     bp                  ; Restore environment.
	  }

	_ret();													/* Return NIL to Clipper. */

}

