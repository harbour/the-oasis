/*
    IDE_SNUM.C - Gets an IDE hard disk serial number and returns
                 it as a character string back to Clipper.

    Copyright (c)1995 MicroTask �� Computer Services - All rights reserved
    Author.: David B. Ferguson
    Date...: Friday March 1st, 1996

    Special Notes: Will hang if used on SCSI hard drive based systems.
                   Is not compatible with Windows 32 bit disk drivers.

                                 -=*=-

 CLIPPER USAGE:

 Passed numeric int, 0 or 1  i.e. IDEHDSNUM( 0 ) or IDEHDSNUM( 1 )
 Where 0 = First Hard Drive
 Where 1 = Second Hard Drive

 Will return a "0" string if nothing is passed or int is greater that 1

 Clipper source example:

 ? IDEHDSNUM(0)     // Display serial number of first IDE Hard Drive
 ? IDEHDSNUM(1)     // Display serial number of second IDE Hard Drive
 ? IDEHDSNUM(3)     // Returns "0" Character


*/


#include "extend.h"

char *getascii (unsigned int in_data [], int off_start, int off_end);


CLIPPER idehdsnum()
{

 unsigned int dd [256];     /*  Disk Data                                    */
 unsigned int dd_off;       /*  Disk Data offset                             */
 int hd;                    /*  Hard Drive number parameter (0 or 1)         */


   if ( (PCOUNT == 1) && (ISNUM(1))  )
   {

      hd = _parni(1);      /*  Assign interger parameter from Clipper for
                               the Hard Drive to be checked                  */
      if( hd > 1 )
       {
         _retclen( "0", 1 );      /* Nothing greater that 1 allowed */
         return;
       }

      while (inp (0x1F7) != 0x50);         /*  Wait for controller not busy  */

      outp (0x1F6, ( hd == 0 ? 0xA0 : 0xB0));  /*  Get first/second drive    */

      outp (0x1F7, 0xEC);                  /*  Get drive info data           */

      while (inp (0x1F7) != 0x58);         /*  Wait for data ready           */


      for (dd_off = 0; dd_off != 256; dd_off++)          /*  Read "sector"   */
	   dd [dd_off] = inpw (0x1F0);

    /*  Return Hard Drive serial number as a string back to Clipper          */
       _retclen( getascii (dd, 10, 19), strlen(getascii (dd, 10, 19)));

   }
   else
     _retclen( "0", 1 );  /*  Send string of "0" back to indicate and error  */

   return;

}



char *getascii( unsigned int in_data [], int off_start, int off_end )
{
  static char ret_val [255];
  int loop, loop1;

  for (loop = off_start, loop1 = 0; loop <= off_end; loop++)
    {
      ret_val [loop1++] = (char) (in_data [loop] / 256);  /*  Get High byte  */
      ret_val [loop1++] = (char) (in_data [loop] % 256);  /*  Get Low byte   */
    }
  ret_val [loop1] = '\0';         /*  Make sure it ends in a NULL character  */
  return(ret_val);
}



/*** End of File IDE_SNUM.C ***/
