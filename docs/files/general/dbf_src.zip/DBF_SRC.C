/*
From philb@iag.net Thu Aug 29 21:34:13 1996
Path: news.iag.net!news.math.psu.edu!chi-news.cic.net!hookup!usenet.eel.ufl.edu!news.mathworks.com!uunet!in2.uu.net!news1.i1.net!ultra.i1.net!news.electricpages.com!usenet
From: rwbaus@avana.net@avana.net
Newsgroups: comp.databases.xbase.misc
Subject: Re: Detailed format of a simple xBase file?
Date: 27 Aug 1996 01:18:01 GMT
Organization: Avana Communications c/o Innoventures, Inc. (Electric Pages)
Lines: 316
Message-ID: <4vtic9$d41@home.electricpages.com>
References: <321B06D8.60DC@noord.bart.nl> <3223AD9A.4D62@keiland.com>
Reply-To: rwbaus@avana.net@avana.net
NNTP-Posting-Host: atl111.avana.net
X-Newsreader: IBM NewsReader/2 v1.2

In <3223AD9A.4D62@keiland.com>, Jim Roehn <jer@keiland.com> writes:
>As a long time firmware programmer (assembler and C) I need help in writing some rather 
>straight forward data to a simple flat-file dBase file.
>
>I am completing a project where a small network of microprocessors have 
>measured and gathered some real-time data. I have written a Windows application in the 
>National Instruments LabWindows/CVI environment which is similiar to Visual C++ (I'm 
>told). I have successfully received data from all of the micros into this application 
>and now as a final step must save all of this data to a dBase file.
>
>I am not very familiar with Visual C++, MFC, or any API's for handling dbase data.
>Is there a simple way that I can format data into a simple flat-file dBase format and 
>write it to disk?
>
>Does anyone have the specs on creating a dBase readable file? Or does anyone have 
>sample source code in C showing how this can be done?
>
>Thanks,
>Doug Wendelboe
>Penn Microsystems Inc.
>Scottsdale, AZ

>>> Reply-To: rwbaus@avana.net <<<

Here is some old code.  circa 1991.

Hope it helps
*/

#include "db.h"

int main( int argc, char *argv[] )
{

   register int   i;
   long           l_counter;
   int            line = 0,
                  fields_num,
                  dbf_file;   // DBF file pointer

   DBF_PTR        Hdr;
   FLD_PTR        Fld;
   FLD_PTR        Fld_start;
   char           *record_buffer;
   char           *rec_start;
   char           *field_buffer;
   char           file_name[13];

   Hdr = (HDR_PTR)malloc( sizeof( DBF_INFO )); // Allocate memory for db info
   if( !Hdr )
   {
      Err( "Memory Allocation Error");
   }

   cls();

   strcpy( file_name, argv[1] );

   /* Check for the command line parameter argv[1]. */
   if( argc == 1 )
   {
      printf( "Enter a Dbf file to examine :" );
      scanf( "%s", file_name );
   }
   if( !Stristr( file_name, ".DBF" ))
   {
      strcat( file_name , ".dbf" ) ;
   }
   if(( dbf_file = open( file_name, O_BINARY|O_RDWR )) == -1 )
   {
      printf("\n\nFile not found!\n");
   }
   else
   {
      if( read( dbf_file, (char *)Hdr, sizeof( DBF_INFO )) < sizeof( DBF_INFO ))
      {
         Err( "Error reading File\n" );
      }
      if(( Hdr->Dbf_type == 0x03 ) || ( Hdr->Dbf_type == 0x83 ))
      {
         printf("\nThis File Is A Legal .DBF File Because...\n");
         printf("The First Byte = %2.2x In Hexadecimal Notation.\n", Hdr->Dbf_type );
         if( Hdr->Dbf_type == 0x83 )
         {
            printf("This Database File Contains One Or More Memo Fields.\n");
         }
         else
         {
            printf("This Database File Does Not Contain Memo Fields.\n");
         }
      }
      else
      {
          printf("\nThis File Is Not A Legal .DBF File...\n\n");
          close( dbf_file );
          exit(0);
       }

      printf("The Date Of Last Update is %2d/%2d/%2d \n\n", (int)Hdr->Month, (int)Hdr->Day, (int)Hdr->Year);

      fields_num = ( Hdr->Hdr_bytes - 33 ) / 32;

      printf("The Number Of Records In The Data File:  %ld.\n", Hdr->Num_recs );
      printf("The Number Of Bytes In The Header:  %d.\n", Hdr->Hdr_bytes);
      printf("The Number Of Bytes In Each Record:  %d.\n", Hdr->Rec_bytes);
      printf("There Are %d Fields Per Record.\n\n", fields_num);

      Fld_start = Fld = (FLD_PTR)malloc( sizeof( FLD_INFO) * fields_num );
      if( !Fld )
      {
         Err( "Memory Allocation Error");
      }

      for( i = 0; i < fields_num; i++ )
      {
         if( read( dbf_file, (char *)Fld, sizeof( FLD_INFO )) < sizeof( FLD_INFO ))
         {
            Err( "Error reading file" );
         }
         Fld++; // move pointer to next area in memory!
      }

      printf( "Press Return Key To Continue...\n" );
      getchar();
      cls();

      Fld = Fld_start; // reset pointer!!!

      printf("FIELD NAME   T   L    D\n");
      printf("===========  =  ===  ===\n");

      for( i = 1; i <= fields_num; i++ )
      {
         printf( "%10s", Fld->Fld_name );
         printf("   %c", Fld->Fld_type );
         printf("  %3d", Fld->Fld_len );
         printf("  %3d\n", Fld->Dec_len );
         Fld++;
         line++;
         if( line > 21 )
         {
            printf("Press Return Key To Continue...");
            getchar();
            cls();
            line = 0;
         }
      }
      line = 0;
      printf("Press Return Key To Continue...\n");
      getchar();
      cls();

      // Add one for NULL termination
      rec_start = record_buffer  = (char *)malloc( Hdr->Rec_bytes + 1 ); 
      if( !record_buffer )
      {
         Err( "Record Memory Allocation Error");
      }
      field_buffer   = (char *)malloc( Hdr->Rec_bytes + 1 ); 
      if( !field_buffer )
      {
         Err( "Field Memory Allocation Error");
      }
      *field_buffer = '\0'; // Null terminate the field buffer

      lseek( dbf_file, 1L, SEEK_CUR ); // move file ptr forward 1 skip header delimiter

      for( l_counter = 0l; l_counter < Hdr->Num_recs; l_counter++ )
      {
         Fld = Fld_start; // reset field structure pointer!!!
         record_buffer = rec_start;
         if( read( dbf_file, record_buffer, Hdr->Rec_bytes ) < Hdr->Rec_bytes )
         {
            Err( "Error Reading Record" );
         }

         *(record_buffer+Hdr->Rec_bytes) = '\0'; // Null terminate the record

         printf( "Record Number : %ld\n", l_counter + 1l ); // Add 1 for looks
         printf( "Record %s Deleted\n", ( (*(record_buffer++) == '*') ? "Is" : "Is not" ));

         for( i = 0; i < fields_num; i++ )
         {
            strncpy( field_buffer, record_buffer, Fld->Fld_len );
            *(field_buffer+Fld->Fld_len) = '\0'; // Null terminate the field
            printf( "%10s : ", Fld->Fld_name );
            printf( "%s\n", field_buffer );
            record_buffer = record_buffer+Fld->Fld_len;
            Fld++;
            line++;
            if( line > 21 )
            {
               printf("Press Return Key To Continue...");
               getchar();
               cls();
               line = 0;
            }
         }
         printf("\nPress Return Key To Continue...");
         getchar();
         cls();
         line = 0;
      }

   }

   close( dbf_file );
   free( Hdr );
   free( Fld_start );
   free( record_buffer );

   return 0;
}

void cls( void )
{
   union REGS regs;

   regs.x.ax = 0x600;
   regs.h.bh = 7;
   regs.x.cx = 0;
   regs.h.dh = 24;
   regs.h.dl = 79;

   int86( 0x10 ,&regs, &regs);

   regs.h.ah = 0x02;
   regs.x.bx = 0;
   regs.x.dx = 0;

   int86( 0x10 ,&regs, &regs);


}  /* END OF cls() FUNCTION */

int Stristr( char *constant, char *search )
{
   int ret_val;
   char *to_srch = strupr( strdup( constant ));
   char *srch_for = strupr( strdup( search ));

   if( strstr( to_srch, srch_for ))
      ret_val = 1;
   else
      ret_val = 0;

   free( to_srch );
   free( srch_for );

   return ret_val;
}

void Err( char * str )
{
   cls();
   printf( str );
   exit( -1 );
   return;
}

/* Now the header */

/*

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dos.h>
#include <malloc.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <io.h>

int main( int, char ** );
void cls( void );
int Stristr( char *, char * );
void Err( char * );

#define  DBF_INFO struct Header_info
#define  DBF_PTR  DBF_INFO *

#define  HDR_INFO struct Header_info
#define  HDR_PTR  HDR_INFO *

#define  FLD_INFO struct Field_info
#define  FLD_PTR  FLD_INFO *

#define  UNS      unsigned int


DBF_INFO
{
   unsigned char  Dbf_type;
   char           Year;
   char           Month;
   char           Day;
   long           Num_recs;
   int            Hdr_bytes;
   int            Rec_bytes;
   char           Dummy[20];
};

FLD_INFO
{
   char  Fld_name[11];
   char  Fld_type;
   long  Memory_address;
   char  Fld_len;
   char  Dec_len;
   int   Lan_info;      //   char  lan_info[2];
   int   Res_1;         //   char  reserved1[2];
   char  work_area_id;
   int   Res_2;         //   char  reserved2[2];
   char  set_fields;
   char  Res_3[5];      //   Buffer ??????
};

*/


