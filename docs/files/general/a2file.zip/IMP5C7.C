#include "extend.h"

CLIPPER STOD() {
   if ( ISCHAR(1) )
      _retds( _parc(1) );
   else
      _retds("00000000");
}




