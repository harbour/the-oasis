/*****************************************************************************
   NUMIND.c

   Brian Marasca
   03/12/94
   MSC 5.1

   This function converts Clipper numerics into strings suitable for
   indexing on.

   Compile: cl /c /AL /Zl /Od /Zi /FPa /Gs /W3 /Zp1 numind.c

   With thanks to Jo French.
*****************************************************************************/

#include "\clip52\include\extend.api"
#include "\clip52\include\item.api"

/*****************************************************************************
   Undocumented internals.
*****************************************************************************/

extern void _lntoa( char *buffer, long value, int len, int dec ) ;
extern void _ntoa( double num, int len, int dec, char * buffer ) ;

/*****************************************************************************
   Function prototype.
*****************************************************************************/

CLIPPER numIndStr( void ) ;

/*****************************************************************************
   FUNCTION numIndStr()

   numIndStr( nNumber, nLength, nDecimals ) --> cIndexStr
*****************************************************************************/

CLIPPER numIndStr()
{
     ITEM num = _itemParam( 1 ) ;
     USHORT len = _parni( 2 ) ;
     USHORT dec = _parni( 3 ) ;
     BOOL neg = FALSE ;
     char buf[64] ;
     double numd ;
     long numl ;
     ITEM ret ;
     char *p ;

     switch( _itemType( num ) )
          {
          case NUMERIC:
               numl = _itemGetNL( num ) ;
               if( neg = ( numl < 0 ) )
               {
                    numl = ~numl ;
                    numl++ ;
               }
               _lntoa( buf, numl, len, dec ) ;
               break ;

          case NUMERIC | DOUBLE:
               numd = _itemGetND( num ) ;
               if( neg = ( numd < (double) 0 ) )
               {
                    p = ( (char *) &numd ) + 7 ;
                    *p ^= 0x80 ;
               }
               _ntoa( numd, len, dec, buf ) ;
               break ;

          default:
               *buf = '\0' ;
          }

     _itemRelease( num ) ;

     p = buf ;
     while( *p )
     {
          if( *p == ' ' )
               *p = '0' ;
          p++ ;
     }

     if( neg )
     {
          p = buf ;

          while( *p )
          {
               *p = (char) 0x5C - *p ;
               p++ ;
          }
     }

     ret = _itemPutC( NULL, buf ) ;
     _itemReturn( ret ) ;
     _itemRelease( ret ) ;
}

