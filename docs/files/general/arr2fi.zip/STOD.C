
#include "extend.h"
/* Convert clipper DTOS string back to date  */
CLIPPER STOD(){
   if ( ISCHAR(1) )
      _retds( _parc(1) );
   else
      _retds(0);
}

