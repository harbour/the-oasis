#include <stddef.h>      // <- if using the Watcom compiler
#include <extend.api>
#include <error.api>
#include <error.ch>

extern BYTEP _cdecl _bset(BYTEP, const SHORT, WORD); // memset()

HIDE WORD  arrayOffset;
HIDE SHORT bitOffset;

// **************************************************************************
HIDE SHORT bitCaclOffsets (WORD userOffset, WORD arrayLength)
{
    SHORT retval = TRUE;

    --userOffset;   // Clipper offsets are 1 based/C is 0 based
    --arrayLength;

    arrayOffset = userOffset / 8u;
    bitOffset   = userOffset % 8;

    if (arrayOffset > arrayLength)  // error
    {
        ERRORP  pError;

        pError = _errNew();
        _errPutDescription(pError, "bit offset is out of bounds");
        _errPutGenCode(pError, EG_BOUND);
        _errPutOperation(pError, "bit assign");
        _errPutSubCode(pError, 1133);
        _errPutSubSystem(pError, "BITS");
        _errPutSeverity(pError, ES_ERROR);
        _errLaunch(pError);
        _errRelease(pError);
        retval = FALSE;
    }

    return (retval);
}


// **************************************************************************
// pass a clipper string to be used as a bit array
//  this function will set all bits to 0
//
CLIPPER BITRESET ()
{
    BYTEP tmp;
    tmp = (BYTEP)_parc(1);
    _bset(tmp, '\0', _parclen(1));
    _retclen(tmp, _parclen(1));
}

// **************************************************************************
// this function will test if a given bit in a bit array is set
//
// Pass the bit array (character string) and which bit to test
//
//  returns .t. if the bit is set, otherwise .f.
//
CLIPPER BITTEST ()
{
    if (bitCaclOffsets(_parni(2), _parclen(1)))
        _retl(_parc(1)[ arrayOffset] & (1 << bitOffset));
    else
        _retl(FALSE);
}

// **************************************************************************
// this will set a given bit in a bit array to on or off
//
// pass a bit array (character string), the bit to set, and what to set it to
// (on or off / Clipper .t. or .f.)
//
// returns the new bit array with the given bit set
//
CLIPPER BITSET ()
{
    BYTEP tmp;

    tmp = (BYTEP)_parc(1);

    if (bitCaclOffsets(_parni(2), _parclen(1)))
    {
        if (_parl(3))
        {
            tmp[ arrayOffset] |= (1 << bitOffset);
        }
        else
        {
            tmp[ arrayOffset] = ~tmp[ arrayOffset];
            tmp[ arrayOffset] |= (1 << bitOffset);
            tmp[ arrayOffset] = ~tmp[ arrayOffset];
        }
    }

    _retclen(tmp, _parclen(1));
}
