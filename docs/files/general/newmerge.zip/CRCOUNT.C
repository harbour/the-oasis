#include <extend.h>

CLIPPER cr_count()
{
  char *string  = _parc(1);
  char *strptr  = &string[0];
  int crcounter = 0;

  for (; *strptr != '\0'; strptr++)
     if (*strptr == '\n') crcounter++;
     
  _retni(crcounter);
}
