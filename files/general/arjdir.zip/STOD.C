/*****************************************************************************
* File....: STOD.C                                                           *
* By......: David A Pearson                                                  *
* Function: Provides a function for converting a string into a Clipper date  *
* ........: variable.                                                        *
* Notes...: Compile with as Large Model, no default library checking,        *
* ........: optimise for speed.                                              *
*****************************************************************************/

#include "c:\clipper5\include\extend.h"

/*****************************************************************************
* Function: SToD()                                                           *
* Syntax..: SToD(<cDateString>) --> dClipperDate                             *
* Usage...: Converts a string date in the format of that returned from DTOS()*
* ........: into a Clipper date variable. For example:                       *
* ........:                                                                  *
* ........:             set date british                                     *
* ........:             ? stod(dtos("31/12/91"))                             *
* ........:                                                                  *
* ........: Would print the date 31/12/91.                                   *
* ........:                                                                  *
* ........: This function is most usefull if you don't know the date format  *
* ........: of your application and you wish to hard code a date. For        *
* ........: example:                                                         *
* ........:                                                                  *
* ........: dDateVar := stod("19911231")                                     *
* ........:                                                                  *
* ........: will allways evaluate to 31st December 1991 no matter what the   *
* ........: date format is.                                                  *
* By......: David A Pearson                                                  *
*****************************************************************************/

CLIPPER SToD()
{
        if (PCOUNT == 1 && ISCHAR(1))
        {
                _retds(_parc(1));
                _xunlock();
        }
        else
        {
                _retds(NULL);
        }
}
