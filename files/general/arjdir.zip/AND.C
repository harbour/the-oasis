/*****************************************************************************
* File....: AND.C                                                            *
* By......: David A Pearson                                                  *
* Function: Provides a function for carring out a bit wise and on two        *
* ........: numbers.                                                         *
* Notes...: Compile with as Large Model, no default library checking,        *
* ........: optimise for speed.                                              *
*****************************************************************************/

#include "c:\clipper5\include\extend.h"

/*****************************************************************************
* Function: And()                                                            *
* Syntax..: And(<nNum1>,<nNum2>) --> nValue                                  *
* Usage...: Carries out a bit-wise and on <nNum1> and <nNum2>.               *
* By......: David A Pearson                                                  *
*****************************************************************************/

CLIPPER And()
{
        if (PCOUNT == 2 && ISNUM(1) && ISNUM(2))
        {
                _retnl(_parnl(1) & _parnl(2));
        }
        else
        {
                _retnl(0);
        }
}
