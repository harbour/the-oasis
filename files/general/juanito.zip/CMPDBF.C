/* CmpDBF  Version 1.21   John Millington  November 4 1988 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <dos.h>
#include <io.h>

#define DIRMAX     512
#define PATHMAX    256
#define NAMELENGTH 13

char    dirlist[2][DIRMAX][NAMELENGTH];
unsigned dirnum[2];

char    path[2][PATHMAX];
char    tpath[PATHMAX];

int     f_flagg=1, d_flagg=1, m_flagg=1;

void usage(){
   puts("cmpdbf v1.21\n\0VeRsIoN=Juanito's DBF comparer v 1.21");
   puts("Usage: cmpdbf path1 path2 [flags]");
   puts("\n  flags and defaults:  (+ enables, - disables)\n");
   puts("    +f  show files (DBFs & MEMs) existing in one directory, but not the other");
   puts("    +d  show field differences between DBFs");
   puts("    +m  show memvar differences between MEMs");
}

main(argc,argv)
int argc;
char *argv[];
{
   if (argc<3) {
      usage();
      exit(1);
   } else {
      unsigned dirr;
      for (dirr=0;dirr<=1;dirr++) {

         register unsigned i;
         auto struct find_t buffer;
         auto int dirstat;

         argv++;
         i=0;
         while ((*argv)[i]) {
            tpath[i]=toupper((*argv)[i]);
            i++;
         }
         if (tpath[i-1]!='\\' && tpath[i-1]!=':')
            tpath[i++]='\\';
         tpath[i]=0;

         dirnum[dirr]=0;
         strcpy(path[dirr],tpath);
         if (f_flagg || d_flagg) {
            strcat(tpath,"*.DBF");
            dirstat=_dos_findfirst(tpath,_A_HIDDEN,&buffer);
            while (dirstat==0) {
               strcpy(dirlist[dirr][dirnum[dirr]],buffer.name);
               dirstat=_dos_findnext(&buffer);
               dirnum[dirr]++;
            }
         }
         if (f_flagg || m_flagg) {
            strcpy(tpath,path[dirr]);
            strcat(tpath,"*.MEM");
            dirstat=_dos_findfirst(tpath,_A_HIDDEN,&buffer);
            while (dirstat==0) {
               strcpy(dirlist[dirr][dirnum[dirr]],buffer.name);
               dirstat=_dos_findnext(&buffer);
               dirnum[dirr]++;
            }
         }

         for(i=0;i<NAMELENGTH;i++) dirlist[dirr][dirnum[dirr]][i]=255;
         qsort(dirlist[dirr],dirnum[dirr],sizeof(dirlist[dirr][i]),strcmp);
      }
      argc-=3;
      while(++argv,argc--) { /* Get remaining params */
         int sgn;
         if ((*argv)[0]=='-')
            sgn=0;
         else if ((*argv)[0]=='+')
            sgn=1;
         else {
            usage();
            exit(1);
         }
         if ((*argv)[1]=='f' || (*argv)[1]=='F')
            f_flagg=sgn;
         else if ((*argv)[1]=='d' || (*argv)[1]=='D')
            d_flagg=sgn;
         else if ((*argv)[1]=='m' || (*argv)[1]=='M')
            m_flagg=sgn;
         else {
            usage();
            exit(1);
         }
      }
      if (!f_flagg && !d_flagg && !m_flagg) {
         printf("All options disabled; nothing to do!\n");
         exit(0);
      }
      printf("Comparing %s and %s\n\n",path[0],path[1]);
      {
         auto int cmper;
         unsigned ndx1, ndx2;

         ndx1=ndx2=0;
         while (ndx1<dirnum[0] || ndx2<dirnum[1]) {
            cmper=strcmp(dirlist[0][ndx1],dirlist[1][ndx2]);
            if (cmper==0) {      /* Same name */
               char *point;
               point=dirlist[0][ndx1];
               while (*point && *point!='.') point++;
               if (*point) {
                  if (*++point=='D') { /* .DBF */
                     if (d_flagg) {  /* But same stru? */
                        char file1[PATHMAX], file2[PATHMAX];
                        void cmpstru();
      
                        strcpy(file1,path[0]);
                        strcat(file1,dirlist[0][ndx1]);
                        strcpy(file2,path[1]);
                        strcat(file2,dirlist[1][ndx2]);
                        cmpstru(file1,file2);
                     }
                  } else { /* .MEM */
                     if (m_flagg) {  /* But same memvars? */
                        char file1[PATHMAX], file2[PATHMAX];
                        void cmpmemv();
      
                        strcpy(file1,path[0]);
                        strcat(file1,dirlist[0][ndx1]);
                        strcpy(file2,path[1]);
                        strcat(file2,dirlist[1][ndx2]);
                        cmpmemv(file1,file2);
                     }
                  }
               }
               ndx1++; ndx2++;
            } else if (cmper>0) {
               if (f_flagg)
                  printf("%s exists only in %s\n\n",dirlist[1][ndx2],path[1]);
               ndx2++;
            } else {
               if (f_flagg)
                  printf("%s exists only in %s\n\n",dirlist[0][ndx1],path[0]);
               ndx1++;
            }
         }
      }
   }
}

#define FIELDMAX   128
struct field {
   char name[11];
   char type, width, decimals;
} fieldlist[2][FIELDMAX];
unsigned fieldnum[2];

int cmpfield(f1,f2)
struct field *f1, *f2;
{
   return(strcmp(f1->name,f2->name));
}

void cmpstru(file1, file2)
char *file1, *file2;
{
   unsigned dbf;

   for (dbf=0;dbf<2;dbf++) {
      int fil, headsize;
      unsigned i;
      char *namer;
   
      namer=dbf==0?file1:file2;
	   if ((fil=open(namer,O_RDONLY | O_BINARY))==-1) {
	      printf("Unable to open %s.\n\n",namer);
	      return;
	   }
      lseek(fil,(long)8,SEEK_CUR);
      read(fil,(char *)&headsize,2);
      lseek(fil,(long)22,SEEK_CUR);

      fieldnum[dbf]=(headsize/32)-1;
      for (i=0;i<fieldnum[dbf];i++) {
         read(fil, fieldlist[dbf][i].name,11);
         read(fil,&fieldlist[dbf][i].type,1);
         lseek(fil,(long)4,SEEK_CUR);
         read(fil,&fieldlist[dbf][i].width,1);
         read(fil,&fieldlist[dbf][i].decimals,1);
         lseek(fil,(long)14,SEEK_CUR);
      }
      close(fil);
      for(i=0;i<11;i++) fieldlist[dbf][fieldnum[dbf]].name[i]=255;
      qsort(fieldlist[dbf],fieldnum[dbf],sizeof(struct field),cmpfield);
   }
   {
      int      cmper, diffy;
      unsigned ndx1, ndx2;
      void     strusay(), hedr();
      struct   field *f1, *f2;

      ndx1=ndx2=diffy=0;
      while (ndx1<fieldnum[0] || ndx2<fieldnum[1]) {
         f1=&fieldlist[0][ndx1];
         f2=&fieldlist[1][ndx2];
         cmper=strcmp(f1->name,f2->name);
         if (cmper==0) {
            if (f1->type!=f2->type || f1->width!=f2->width || 
               (f1->type=='N' && f1->decimals!=f2->decimals)) {
               if (!diffy) {
                  diffy=1;
                  hedr(file1,file2);
               }
               strusay(f1);
               printf(" | ");
               strusay(f2);
               putchar('\n');
            }
            ndx1++; ndx2++;
         } else if (cmper>0) {
            if (!diffy) {
               diffy=1;
               hedr(file1,file2);
            }
            printf("     ----------      | ");
            strusay(f2);
            putchar('\n');
            ndx2++;
         } else {
            if (!diffy) {
               diffy=1;
               hedr(file1,file2);
            }
            strusay(f1);
            printf(" |      ----------\n");
            ndx1++;
         }
      }
      if (diffy) putchar('\n');
   }
}

void hedr(file1,file2)
char *file1, *file2;
{
   printf("Differences between %s and %s:\n",file1,file2);
   printf("==================== | ====================\n");
}

void strusay(feeld)
struct field *feeld;
{
   printf("%-10s",feeld->name);
   switch(feeld->type) {
      case 'N':  printf(" Num  "); break;
      case 'C':  printf(" Char "); break;
      case 'L':  printf(" Log  "); break;
      case 'D':  printf(" Date "); break;
      case 'M':  printf(" Memo "); break;
      default:   printf(" ?Bug?");
   }
   if (feeld->type=='N')
      printf("%2d %1d",feeld->width,feeld->decimals);
   else
      printf("%2d  ",feeld->width);
}

#define MEMVARMAX  256
struct memvar {
   char     name[11], type;
   unsigned width;
} memvarlist[2][MEMVARMAX];
unsigned memvarnum[2];

int cmpmemvar(f1,f2)
struct field *f1, *f2;
{
   return(strcmp(f1->name,f2->name));
}

void cmpmemv(file1, file2)
char *file1, *file2;
{
   unsigned mem;

   for (mem=0;mem<2;mem++) {
      int fil, headsize;
      unsigned i;
      char *namer;
      struct memvar *thisone;

      namer=mem==0?file1:file2;
	   if ((fil=open(namer,O_RDONLY | O_BINARY))==-1) {
	      printf("Unable to open %s.\n\n",namer);
	      return;
	   }
      i=0;
   	while (!eof(fil)) {
   	   thisone=&memvarlist[mem][i+1];
         read(fil,thisone->name,1); /* memvar name */
         if (!eof(fil)) {
            memvarnum[mem]++;
            read(fil,thisone->name+1,10); /* memvar name */
      	   read(fil,&thisone->type,1);
      	   thisone->type=(thisone->type)&127;
      	   if (thisone->type=='N') {
      	      lseek(fil,(long)28,SEEK_CUR);
      	   } else if (thisone->type=='D') {
      	      lseek(fil,(long)28,SEEK_CUR);
      	   } else if (thisone->type=='L') {
      	      lseek(fil,(long)21,SEEK_CUR);
      	   } else if (thisone->type=='C') {
      	      lseek(fil,(long)4,SEEK_CUR);
      	      read(fil,(char *)&thisone->width,2);
      	      lseek(fil,(long)15+(--thisone->width),SEEK_CUR);
      	   } else {
      	      puts("Invalid .MEM file");
      	      return;
      	   }
      	}
   	}
	   /* read em in */
      close(fil);
   	thisone=&memvarlist[mem][i+1];
      memvarnum[mem]=i;
      for(i=0;i<11;i++) thisone->name[i]=255;
      qsort(memvarlist[mem],memvarnum[mem],sizeof(struct memvar),cmpmemvar);
   }
   {
      int      cmper, diffy;
      unsigned ndx1, ndx2;
      void     memvsay(), hedr();
      struct   memvar *f1, *f2;

      ndx1=ndx2=diffy=0;
      while (ndx1<memvarnum[0] || ndx2<memvarnum[1]) {
         f1=&memvarlist[0][ndx1];
         f2=&memvarlist[1][ndx2];
         cmper=strcmp(f1->name,f2->name);
         if (cmper==0) {
            if (f1->type!=f2->type || (f1->type=='C' && f1->width!=f2->width)) {
               if (!diffy) {
                  diffy=1;
                  hedr(file1,file2);
               }
               memvsay(f1);
               printf(" | ");
               memvsay(f2);
               putchar('\n');
            }
            ndx1++; ndx2++;
         } else if (cmper>0) {
            if (!diffy) {
               diffy=1;
               hedr(file1,file2);
            }
            printf("     ----------      | ");
            memvsay(f2);
            putchar('\n');
            ndx2++;
         } else {
            if (!diffy) {
               diffy=1;
               hedr(file1,file2);
            }
            memvsay(f1);
            printf(" |      ----------\n");
            ndx1++;
         }
      }
      if (diffy) putchar('\n');
   }
}

void memvsay(memm)
struct memvar *memm;
{
   printf("%-10s",memm->name);
   switch(memm->type) {
      case 'N':  printf(" Num  "); break;
      case 'C':  printf(" Char "); break;
      case 'L':  printf(" Log  "); break;
      case 'D':  printf(" Date "); break;
      case 'M':  printf(" Memo "); break;
      default:   printf(" ?Bug?");
   }
   if (memm->type=='C')
      printf("%2d  ",memm->width);
   else
      printf("    ");
}
