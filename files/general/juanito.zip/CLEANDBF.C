/*    Juanito's DBF cleanup
**
**    CleanDbf looks for damage in DBF files.
**
**    Usage: CleanDBF <filename> [options]
**
**    Default extension of filename is .DBF
**
**    Options:
**
**       -c Do not correct record count            +c Correct record count
**       -d Look at all records, deleted or not    +d Ignore deleted records
**       -w Do not write ANY corrections           +w Write some kinda of corrections
** +q or -m Do not display messages                +m or -q Display messages
**
**    Examples:  cleandbf payinfo
**               cleandbf payinfo.dbf -d +w
**               cleandbf payinfo.dbf +dw 
**
**    Default switch values are:
**       +cmd-w
**    You can change the defaults by setting the CLEANDBF environment variable.
**    For example:
**       SET CLEANDBF=+d -m
**
** I can think of lots of improvements that could be made to this program,
** but there just isn't time:
**    1) Allow wildcards in the filename.
**    2) Have an option for making a log file instead of having to
**       use redirection.
**    3) Add a progress-meter for when it is scanning a large DBF.
**    4) Redo those damn awkward command line options
*/

#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <ctype.h>
#include <string.h>
#include <share.h>

#define DEFAULTSW "+cmd-w"

#undef DEBUG

const char *version="CoPyRiGhT=Juanito's DBF cleaner-upper.\0VeRsIoN=2.11";
char fname[257];  /* Name of DBF */
static char sw_c, sw_d, sw_w, sw_m;
static unsigned error=0;
static unsigned oddities=0;

struct FIELD_DEF {
   char name[11];
   char type;
   unsigned offset; /* Where in the record does this field start? */
   unsigned char width;
   unsigned char decimals;
} *fieldlist;
static unsigned nof;  /* Number of fields */

unsigned set_sw(opts)
char *opts;
/* Returns 1 if parsed OK, 0 if error */
{
   if (opts) { /* Not null */
      char setter, ch;

      setter=2;
      while (ch=*opts++) {
         ch=toupper(ch);
         if (ch==' ')
            { /* Skip it */ }
         else if (ch=='-')
            setter=0;
         else if (ch=='+')
            setter=1;
         else if (setter==2)  /* letters not allowed until a + or - encountered */
            return(1);
         else if (ch=='C')
            sw_c=setter;
         else if (ch=='D')
            sw_d=setter;
         else if (ch=='W')
            sw_w=setter;
         else if (ch=='M')
            sw_m=setter;
         else if (ch=='Q')
            sw_m=!setter;
         else                 /* Unrecognized switch */
            return(1);
      }
   }
   return(0);
}

int contained(seekme,str)
char seekme;
char *str;
{
   while (*str) {
      if (seekme == *str)
         return 1;
      str++;
   }
   return 0;
}

/* CleanDBF returns non-zero if buffer is modified */
unsigned cleandbf(buffer,size,recno)
char *buffer;
unsigned size;
unsigned long recno;
{
   int changed_record;
   unsigned char suspect;

   changed_record=0;

   suspect=buffer[0];
   if (!contained(suspect," *")) {
      oddities++;
      printf("%s: Record %lu: deleted() marker contains invalid character: %u.  ",
             fname,recno,(unsigned)suspect);
      if (sw_w) {
         buffer[0]=' ';
         printf("Corrected.\n");
         changed_record=1;
      } else
         printf("No action taken.\n");
   }

   if (sw_d==0 || buffer[0]!='*') {
      unsigned fno;
      /* Check each field for validity */
      for (fno=0;fno<nof;fno++) {
         int corrupt;
         char type;
         unsigned i,end_of_field;
         char *adjective;
   
         adjective="illegal";
         type=fieldlist[fno].type;
         corrupt=suspect=0;
         i=fieldlist[fno].offset;
         end_of_field=i+fieldlist[fno].width-1;
         
         while (i<=end_of_field && !corrupt) {
            suspect=buffer[i];
            if (type=='D')
               corrupt=!contained(suspect," 0123456789");
            else if (type=='N')
               corrupt=!contained(suspect," 0123456789.,-*");
            else if (type=='L')
               corrupt=!contained(suspect," TFYN?");
            else if (type=='C') {
               /* Technically, anything is legal inside a char field; except
                  maybe a zero.  But for our purposes, I think we should
                  call it an error if anything less than 32 or more than 127
                  appears.  This might be too strict; lets see how it goes.
                  
                  4/26 don't complain about 255s.  Word Wrapper uses these.
               */
               corrupt = (suspect<32 || (suspect>127 && suspect<255));
               if (suspect != 0)
                  adjective="suspicious";
            }
            i++;
         }
         if (corrupt) {
            oddities++;
            printf("%s: Record %lu: Field %s contains %s character %u.\n",fname,recno,&(fieldlist[fno].name),adjective,(unsigned)suspect);
         }
      }
   }
   return(changed_record);
}

void main(argc,argv)
unsigned argc;
char **argv;
{
   char *argv0;

   error=0;
   /* Initialize default switches */
   sw_c=1; sw_d=1; sw_w=0; sw_m=1;
   oddities=0;

   /* Get the name of this program and store it in argv0 */
   {
      char *p;
      p=*argv;
      while (*p) {
         if (islower(*p)) *p=tolower(*p);
         else if (*p=='.') *p=0;
         if (*p++=='\\') argv0=p;
      }
   }

   set_sw(DEFAULTSW);
   /* Get new default switches from environment */
   set_sw(getenv("CLEANDBF"));

   /* Get switches from command line */
   if (argc<2)
      error=1;
   else {
      unsigned parm;
      parm=2;
      while (parm<=argc && !error)
         error=set_sw(argv[parm++]);
   }
#ifdef DEBUG
   putchar('+');
   if (sw_c) putchar('c');
   if (sw_d) putchar('d');
   if (sw_w) putchar('w');
   if (sw_m) putchar('m');
   putchar('-');
   if (!sw_c) putchar('c');
   if (!sw_d) putchar('d');
   if (!sw_w) putchar('w');
   if (!sw_m) putchar('m');
   putchar('\n');
#endif

   if (error) {
      printf("Juanito's DBF cleaner-upper, v2.11\n\n");
      printf("usage: %s <dbfname> [options]\n",argv0);
      printf("Options:\n");
      printf("      -c Do not check record count       +c Check record count\n");
      printf("      -d SET DELETED OFF                 +d SET DELETED ON\n");
      printf("      -w Do not write ANY corrections    +w Write corrections\n");
      printf("+q or -m Do not display messages         +m or -q Display messages\n");
      printf("\nDefaults are %s\n",DEFAULTSW);
      exit(1);
   } else {
      int  dbf;         /* Handle for DBF */

      /* Get name of DBF into fname[], append extension if necessary */
      {
         register unsigned i;
         register char *arrg;
         char point;

         arrg=*(++argv);
         point=i=0;
         do {
            fname[i++]=toupper(*arrg);
            if (*(arrg)=='.')
               point=1;
            else if (*(arrg)=='\\' || *(arrg)=='/')
               point=0;     /* Reset if dot was part of path */
         } while (*arrg++);
         fname[i]=0;
         if (!point)
            strcat(fname,".DBF");
      }

      /* Open the DBF */
      if (sw_w)
         dbf=open(fname,O_RDWR   | O_BINARY);
      else
         dbf=sopen(fname,O_RDONLY | O_BINARY, SH_DENYNO);

      if (dbf==-1)
         perror(fname);
      else {
         /* File opened OK */
         unsigned long headrecs;   /* Number of records, according to header */
         unsigned long realrecs;   /* Number of records that we count */
         unsigned recsize;         /* Size of each record */
         unsigned headsize;        /* Number of bytes in header (Offset to data) */
         char     *buffer;

         /* Read in some header info */
         lseek(dbf,4L,SEEK_SET);
         read(dbf,(void *) &headrecs,4);
         read(dbf,(void *) &headsize,2);
         read(dbf,(void *) &recsize,2);
         nof=(headsize/32)-1;

         fieldlist = malloc(nof * sizeof(struct FIELD_DEF));
         if (fieldlist==NULL)
            printf("%s: DBF file %s has more fields than I can handle.\n",argv0,fname);
         else {
            lseek(dbf,20L,SEEK_CUR);  /* Skip over 20 bytes of junk */
            {
               unsigned fno, ofs;
               ofs=1;
               for (fno=0;fno<nof;fno++) {
                  char type;

                  read(dbf,&(fieldlist[fno].name),11);
                  read(dbf,&type,1);
                  fieldlist[fno].type=type;
                  lseek(dbf,4L,SEEK_CUR);  /* Skip over 4 bytes of junk */
                  read(dbf,&(fieldlist[fno].width),1);
                  read(dbf,&(fieldlist[fno].decimals),1);
                  lseek(dbf,14L,SEEK_CUR);  /* Skip over 14 bytes of junk */
                  {
                     unsigned char i;
                     fieldlist[fno].name[10]=32;
                     i=10;
                     while (i && fieldlist[fno].name[i]==32) {
                        fieldlist[fno].name[i]=0;
                        i--;
                     }
                  }
                  /* Look for a few possible field definition errors */
                  if (type!='N' && type!='C' && type!='L' && type!='D' && type!='M') {
                     /* unknown field type */
                     oddities++;
                     printf("%s: field %s has unknown type %c.  Probably corrupted header.\n",fname,&(fieldlist[fno].name),type);
                  } else if (fieldlist[fno].decimals > 0 && type=='C') {
                     /* Clipper allows Character fields to have a value in
                        the "decimals" part of the field definition, and uses
                        it as a MSB for the field length, allowing character
                        fields up to 64k in length.  But this is illegal
                        with dBase. */
                     oddities++;
                     printf("%s: field %s has 'decimals'.  Clipper and dBase will handle this field differently.  Fairly serious.\n",fname,&(fieldlist[fno].name));
                  } else if (fieldlist[fno].decimals > 0 && type!='N') {
                     /* Clipper allows Character fields to have a value in
                        the "decimals" part of the field definition, and uses
                        it as a MSB for the field length, allowing character
                        fields up to 64k in length.  But this is illegal
                        with dBase. */
                     oddities++;
                     printf("%s: field %s has 'decimals'.  Possibly corrupted header, but probably no big deal.\n",fname,&(fieldlist[fno].name));
                  } else if (type=='L' && fieldlist[fno].width!=1) {
                     oddities++;
                     printf("%s: field %s has Logical type, but width %u.  Probably corrupted header.\n",fname,&(fieldlist[fno].name),(unsigned)fieldlist[fno].width);
                  } else if (type=='D' && fieldlist[fno].width!=8) {
                     oddities++;
                     printf("%s: field %s has Date type, but width %u.  Probably corrupted header.\n",fname,&(fieldlist[fno].name),(unsigned)fieldlist[fno].width);
                  } else if (type=='M' && fieldlist[fno].width!=10) {
                     oddities++;
                     printf("%s: field %s has Memo type, but width %u.  Probably corrupted header.\n",fname,&(fieldlist[fno].name),(unsigned)fieldlist[fno].width);
                  }
                  /* I can think of a few other things we could check, but this is enough for now. */

                  fieldlist[fno].offset=ofs;
                  ofs += fieldlist[fno].width;
               }
            }
            /* Allocate a buffer that is size of a record */
            buffer=malloc(recsize);
            if (buffer==NULL)
               printf("%s: DBF file %s has record size too big for me to handle.\n",argv0,fname);
            else {
               unsigned long thisrec;

               realrecs=0L;
               while (1) {
                  /* "thisrec" is long offset to beginning of current record */
                  thisrec=((long)headsize)+(realrecs*((long)recsize));
                  lseek(dbf,thisrec,SEEK_SET); /* Move pointer to this record */

                  if (read(dbf,buffer,recsize)<recsize)
                     break;
                  realrecs++;

                  /* cleandbf() makes whatever fixes are necessary in the buffer.
                  ** It also displays whatever message are appropriate, and
                  ** returns non-zero if record was modified.  If the -w switch
                  ** was selected, record will never be modified.
                  */
                  if (cleandbf(buffer,recsize,realrecs)) {
                     if (sw_w) {
                        lseek(dbf,thisrec,SEEK_SET); /* Move pointer to this record */
                        write(dbf,buffer,recsize);
                     }
                  }
               }
               free(buffer);

               /* Data has been checked and whatever changes necessary have been
               ** made.  Now compare actual records read to number in header.
               */
               if (realrecs != headrecs)
                  if (sw_c) {
                     if (sw_m) {
                        oddities++;
                        printf("%s: Record count in header is incorrect: ",fname);
                        if (sw_w) {
                           printf("Corrected.\n");
                           /* Write corrected record count back to header */
                           lseek(dbf,4L,SEEK_SET);
                           write(dbf,(void* ) &realrecs,4);
                        } else
                           printf("No action taken.\n");
                        printf("     Header reported %lu\n",headrecs);
                        printf("     Actual count is %lu\n",realrecs);
                        printf("(This is NORMAL in DBFs that are open in shared mode by Clipper.)\n");
                     }
                  }
               if (oddities==0 && sw_m)
                  printf("%s: Nothing unusual detected.\n",fname);
            }
            free(fieldlist);
         }
      }
   }
}
