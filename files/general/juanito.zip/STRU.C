/* Juanito's DBF structure lister
**
** Usage example:
**
**       STRU PAYINFO
**
*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <share.h>
#include <ctype.h>
#include <io.h>

void main(argc,argv)
int argc;
char **argv;
{
   auto int fil,fno,nof;
   char junk[20];
   char fname[60];

   if (argc>1)
      strcpy(fname,argv[1]);
   else {
      register char *p;
      char *prgname;

      p=*argv;
      while (*p) {
         if (islower(*p)) *p=tolower(*p);
         else if (*p=='.') *p=0;
         if (*p++=='\\') prgname=p;
      }
      printf("usage: %s dbfname\n",prgname);
      exit(1);
   }
   {
      register unsigned i;
      register char *arrg;
      unsigned point;

      arrg=*(++argv);
      point=i=0;
      do {
         fname[i++]=toupper(*arrg);
         if (*(arrg)=='.')
            point=1;
         else if (*(arrg)=='\\' || *(arrg)=='/')
            point=0;     /* Reset if dot was part of path */
      } while (*arrg++);
      fname[i]=0;
      if (!point)
         strcat(fname,".DBF");
   }
   if ( (fil=sopen(fname,O_RDONLY | O_BINARY, SH_DENYNO))==-1) {
      perror(fname);
      exit(1);
   }
   {
      int headsize,recsize;
      long int norecs;

      read(fil,(void *)junk,4);
      read(fil,(void *)&norecs,4);
   
      read(fil,(void *)&headsize,2);
      read(fil,(void *)&recsize,2);
      read(fil,(void *)junk,20);
   
      nof=(headsize/32)-1;
   
      printf("Name: %s\n\0\VeRsIoN=Juanito's DBF Structure Looker Atter V1.2",fname);
      printf("%ld records of size %d plus header size %d",norecs,recsize,headsize);
      printf(" for a total of %ld bytes.\n\n",(long)headsize+norecs*(long)recsize);
   }

   printf("     Field Name  Type         Width\n\n");
   for (fno=0;fno<nof;fno++) {
      char name[11], type, width, decimals;

      read(fil,name,11);
      read(fil,&type,1);
      read(fil,junk,4);
      read(fil,&width,1);
      read(fil,&decimals,1);
      read(fil,junk,14);
      printf("%3d  %-10s",fno+1,name);
      switch(type) {
         case 'N':  printf("  Numeric  "); break;
         case 'C':  printf("  Character"); break;
         case 'L':  printf("  Logical  "); break;
         case 'D':  printf("  Date     "); break;
         case 'M':  printf("  Memo     "); break;
         default:   printf("           ");
      }
      if (type=='N')
         printf("%7d  %1d\n",width,decimals);
      else
         printf("%7d\n",width);
   }
   close(fil);
}

/* void _nullcheck(){}; void _setenvp(){}; */
