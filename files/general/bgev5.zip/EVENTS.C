/*
 Events.c
 Event routines voor CA-Clipper 5.x.
 Copyright (C) 1995-1997, Arno Tolmeijer.
*/


#include <Extend.api>
#include <Fm.api>
#include <Item.api>

#ifdef _EXTEND_API
  #undef WORD
#endif

#ifndef _CLIPDEFS_H
  #include <Clipdefs.h>
#endif

#include "Events.h"

// STATIC variabelen.
static BOOL sbEventsOn   = TRUE;
static WORD suiInHandler = 0;
static BOOL sbReentrant  = FALSE;

static ITEM     sitemEventHandler = NULL;
static EVALINFO seiHandler;


/*
 void eproc( void )
 Evalueert het event codeblok of procedure.
*/
void eproc( void )
{
  if ( sbReentrant || !suiInHandler ) {
    /*
      suiInHandler stelt de event handler ervan op de hoogte dat we al in een
      event handler zitten. Dit voorkomt een error 650: processor stack
      fault. De event handler kan anders namelijk nog worden geactiveerd
      als we nog bezig zijn met het uitvoeren van de event handler.
    */
    suiInHandler++;
    _itemRelease( _evalLaunch( &seiHandler ) );

    /* _evalRelease() verwijdert referenties naar de parameters in de
       EVALINFO structuur eiHandler, en de parameter in _evalNew(). Omdat we
       echter geen parameters hebben opgegeven, en de parameter van
       _evalNew() willen behouden, voeren we geen _evalRelease( &eiHandler )
       uit.
    */

    suiInHandler--;
  }
}


/*
 EvhSet( bEventHandler ) --> <lSuccess>
 Stelt een achtergrond event handler in.
*/
CLIPPER EvhSet( void )
{
  ITEM   itemParam;
  BOOL   bSuccess = FALSE;
  USHORT uiType;

  itemParam = _itemParam( 1 );
  uiType    = _itemType( itemParam );

  if ( ( uiType & BLOCK ) || ( uiType & CHARACTER ) ) {

    if ( sitemEventHandler ) {
      // Verwijder een vorige event-handler.
      eveRegisterStrobe( *eproc, FALSE );
      _itemRelease( sitemEventHandler );
      sitemEventHandler = NULL;
      suiInHandler = 0;

    }

    // Installeer de event handler in deze module.
    sitemEventHandler = itemParam;
    _evalNew( &seiHandler, itemParam );

    // Indien SetEvent() aan staat, nieuwe handler meteen activeren.
    if ( sbEventsOn ) {
      eveRegisterStrobe( *eproc, TRUE );
    }

    bSuccess = TRUE;
  }
  else
    _itemRelease( itemParam );

  _retl( bSuccess );
}


/*
 EvhClear() --> <lSuccess>
 Verwijdert de achtergrond event handler.
*/
CLIPPER EvhClear( void )
{
  BOOL bSuccess = FALSE;

  if ( sitemEventHandler ) {
    // Verwijder de event-handler.
    eveRegisterStrobe( *eproc, FALSE );
    _itemRelease( sitemEventHandler );
    sitemEventHandler = NULL;
    bSuccess = TRUE;
  }
  _retl( bSuccess );
}


/*
 SetEvent( [<lOn>] )  --> <lCurrentStatus>
 Aktie : Zet achtergrond event handling aan of uit. Zonder parameter blijft de
         huidige instelling ongewijzigd.
 Retour: De huidige status.
 Opm.  : Het is mogelijk ten hoogste twee handlers tegelijk aktief te hebben.
         Hiervoor moet een tweede SetEvent()-functie worden gemaakt.
*/
CLIPPER SetEvent( void )
{
  BOOL bCurrStatus;

	bCurrStatus = sbEventsOn;

  if ( ISLOG( 1 ) ) {
    sbEventsOn = _parl( 1 );

  if ( ( sitemEventHandler && sbEventsOn ) ||
                                      !( sitemEventHandler && sbEventsOn ) )
    // Indien een Event handler is gedefinieerd, meteen activeren.
    eveRegisterStrobe( *eproc, sbEventsOn );
  }
  _retl( bCurrStatus );
}


/*
 SetReentrant( [<lOn>] )  --> <lCurrentStatus>
 Aktie : Staat het meervoudig benaderen van een event handler toe.
 Retour: De huidige status.
*/
CLIPPER SetReentra( void )
{
  BOOL bCurrStatus;

	bCurrStatus = sbReentrant;

  if ( ISLOG( 1 ) )
    sbReentrant = _parl( 1 );

  _retl( bCurrStatus );
}


/*
 EvInHandler() --> <lCurrentStatus>
 Aktie : Geeft aan of de huidige event handler aktief is.
 Retour: De huidige status.
*/
CLIPPER EvInHandle( void )
{
  _retl( suiInHandler );
}
