/*
 * File......: DESCEND.C
 * Author....: Ted Means
 * CIS ID....: 73067,3332
 *
 * This function is an original work by Ted Means and is placed in the
 * public domain.
 *
 * Modification history:
 * ---------------------
 *
 *    Rev 1.1   01 May 1995 03:05:00   TED
 * Added typecast to tame compiler warning
 *
 *    Rev 1.0   01 Feb 1995 03:02:00   TED
 * Initial release
 *
 */


/*  $DOC$
 *  $FUNCNAME$
 *     FT_Descend()
 *  $CATEGORY$
 *     Conversion
 *  $ONELINER$
 *     Create a descending index key value
 *  $SYNTAX$
 *     FT_Descend( <exp> ) -> <value>
 *  $ARGUMENTS$
 *     <exp> is any expression of character, numeric, date, or logical type.
 *  $RETURNS$
 *     The inverse of <exp>
 *  $DESCRIPTION$
 *     This function is a replacement for CA-Clipper's Descend() function,
 *     which is known to produce memory corruption occassionally.
 *  $EXAMPLES$
 *     ? FT_Descend( 1 )      // Returns -1
 *  $SEEALSO$
 *     FT_XTOY()
 *  $END$
 */

#include <EXTEND.API>
#include <ITEM.API>
#include <FM.API>

void pascal FT_Descend( void )
{
   auto ITEM iP       = _itemParam( 1 );
   auto USHORT uiType = _itemType( iP );

   auto ITEM iR;
   auto USHORT uiLen, n;
   auto char * pDescend;

   if ( ( uiType & NUMERIC ) && ( uiType & DOUBLE ) )
      iR = _itemPutND( 0, 0 - _itemGetND( iP ) );

   else if ( uiType & NUMERIC )
      iR = _itemPutNL( 0, 0 - _itemGetNL( iP ) );

   else if ( uiType & DATE )
      iR = _itemPutNL( 0, 0x4FD4C0L - _itemGetNL( iP ) );

   else if ( uiType & LOGICAL )
      iR = _itemPutL( 0, ( _itemGetL( iP ) > 0 ) ? 0 : 1 );

   else if ( uiType & CHARACTER )
   {
      uiLen = _itemSize( iP );

      pDescend = _xgrab( uiLen );

      _itemCopyC( iP, pDescend, uiLen );

      for ( n = 0; n < uiLen; n++ )
         pDescend[ n ] = ( char ) 0 - pDescend[ n ];

      iR = _itemPutCL( 0, pDescend, uiLen );

      _xfree( pDescend );
   }

   _itemReturn( iR );

   _itemRelease( iP );
   _itemRelease( iR );

   return;
}