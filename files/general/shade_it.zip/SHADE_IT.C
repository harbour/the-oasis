
/*
 Written by Daniel Docekal July 1991.
 
 Retreived from FidoNet by Phil Barnett.
 
 Refined by Phil Barnett Aug 1991.

 Usage:
 RESTSCREEN(coordinates,shade_it(savescreen(coordinates)))
*/

#include <extend.h>

CLIPPER shade_it()
{
 char *str = _parc(1);
 int  l = _parclen(1);
 int  i = 1;
 for(;i<l;i+=2)
   str[i]=8;
 _retclen(str,l);
}
