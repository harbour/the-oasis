#ifndef lint
static char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)
#define YYPREFIX "yy"
#line 2 "calc.y"

#include <Windows.h>
#include <stdlib.h>
#include <string.h>

int yylex( void );
int yyparse( void );

LPSTR szIn, szOut;
WORD  wPos;

void pascal ShowMessage( LPSTR );

#define P(x) ShowMessage(x)

#line 19 "calc.y"
typedef union
{
   LPSTR String;
   long Number;
} YYSTYPE;
#line 34 "y_tab.c"
#define NUMBER 257
#define STRING 258
#define IDENTIFIER 259
#define NOT 260
#define _TRUE 261
#define _FALSE 262
#define YYERRCODE 256
static short yylhs[] = {                                        -1,
    0,    0,    0,    0,    0,    0,    0,    0,    1,    1,
    3,    3,    2,    2,    2,    2,
};
static short yylen[] = {                                         2,
    1,    1,    1,    1,    3,    3,    3,    3,    3,    4,
    1,    3,    1,    3,    5,    6,
};
static short yydefred[] = {                                      0,
    1,    2,    0,    0,    0,    3,    0,    0,    0,    0,
    0,    0,    0,    9,    0,    0,    8,    5,    6,    7,
    0,   10,    0,    0,    0,   15,    0,   16,
};
static short yydgoto[] = {                                      15,
    6,    7,   16,
};
static short yysindex[] = {                                    -34,
    0,    0,  -33,  -34,  -32,    0,  -21,  -40,  -23,  -34,
  -34,  -34, -247,    0,  -32,  -20,    0,    0,    0,    0,
   -9,    0,  -34,  -37,  -32,    0,  -18,    0,
};
static short yyrindex[] = {                                      0,
    0,    0,    2,    0,    0,    0,   14,    0,    0,    0,
    0,    0,    0,    0,  -14,    0,    0,    0,    0,    0,
    8,    0,    0,    0,  -12,    0,    0,    0,
};
static short yygindex[] = {                                      5,
    0,    0,    9,
};
#define YYTABLESIZE 225
static short yytable[] = {                                       4,
   14,   13,    4,   26,    5,    4,    8,   14,    9,   12,
   10,   21,   11,    4,   18,   19,   20,   17,   12,   10,
   22,   11,   28,   23,   13,   23,   11,   25,   12,   11,
   24,   12,   27,    0,    0,    0,    0,    0,    0,    0,
    0,    0,   13,   13,   13,   13,   13,   13,   14,   14,
   14,   14,   14,   14,    4,    4,    4,    4,    4,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    1,    2,    3,    1,
    2,    3,    1,    2,    3,
};
static short yycheck[] = {                                      40,
   41,    0,   40,   41,    0,   40,   40,    0,    4,   42,
   43,  259,   45,    0,   10,   11,   12,   41,   42,   43,
   41,   45,   41,   44,   46,   44,   41,   23,   41,   44,
   40,   44,   24,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   41,   42,   43,   44,   45,   46,   41,   42,
   43,   44,   45,   46,   41,   42,   43,   44,   45,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  257,  258,  259,  257,
  258,  259,  257,  258,  259,
};
#define YYFINAL 5
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 262
#if YYDEBUG
static char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,"'('","')'","'*'","'+'","','","'-'","'.'",0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
"NUMBER","STRING","IDENTIFIER","NOT","_TRUE","_FALSE",
};
static char *yyrule[] = {
"$accept : Expr",
"Expr : NUMBER",
"Expr : STRING",
"Expr : FunCall",
"Expr : Object",
"Expr : Expr '+' Expr",
"Expr : Expr '-' Expr",
"Expr : Expr '*' Expr",
"Expr : '(' Expr ')'",
"FunCall : IDENTIFIER '(' ')'",
"FunCall : IDENTIFIER '(' ParamList ')'",
"ParamList : Expr",
"ParamList : ParamList ',' Expr",
"Object : IDENTIFIER",
"Object : Object '.' IDENTIFIER",
"Object : Object '.' IDENTIFIER '(' ')'",
"Object : Object '.' IDENTIFIER '(' ParamList ')'",
};
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
static int yydebug;
static int yynerrs;
static int yyerrflag;
static int yychar;
static short *yyssp;
static YYSTYPE *yyvsp;
static YYSTYPE yyval;
static YYSTYPE yylval;
static short yyss[YYSTACKSIZE];
static YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 62 "calc.y"

static YYSTYPE yylval;

int yyerror( LPSTR szMsg )
{
   MessageBox( 0, szMsg, "Error", MB_ICONINFORMATION );
   return 1;
}

WORD ChrAt( BYTE byte, LPSTR szText )
{
   WORD w = 1;

   while( szText[ w - 1 ] && szText[ w - 1 ] != byte )
      w++;

   if( szText[ w - 1 ] == byte )
      return w;
   else
      return 0;
}

int yylex( void )
{
   static BYTE token[ 25 ];
   BYTE b = 0;

   if( wPos == strlen( szIn ) )
      return -1;

   while( szIn[ wPos ] == ' ' )
     wPos++;

   if( szIn[ wPos ] >= '0' && szIn[ wPos ] <= '9' )
   {
      while( szIn[ wPos ] >= '0' && szIn[ wPos ] <= '9' )
         token[ b++ ] = szIn[ wPos++ ];
      token[ b ] = 0;

      yylval.Number = atol( token );
      return NUMBER;
   }

   if( szIn[ wPos ] == '"' )
   {
      token[ b++ ] = '"';
      wPos++;

      while( szIn[ wPos ] != '"' )
      {
         token[ b++ ] = '"';
         wPos++;
      }

      token[ b++ ] = '"';
      token[ b ] = 0;
      wPos++;
      yylval.String = token;

      return STRING;
   }

   if( szIn[ wPos ] >= 'A' && szIn[ wPos ] <= 'z' )
   {
      while( szIn[ wPos ] >= 'A' && szIn[ wPos ] <= 'z' )
         token[ b++ ] = szIn[ wPos++ ];

      token[ b ] = 0;
      yylval.String = token;

      return IDENTIFIER;
   }

   if( ChrAt( szIn[ wPos ], "+-(),.*/" ) )
      return szIn[ wPos++ ];

   return -1;
}

void pascal parse( LPSTR szExpression, LPSTR szBuffer )
{
   szIn  = szExpression;
   szOut = szBuffer;
   wPos  = 0;

   yyparse();
}
#line 268 "y_tab.c"
#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 37 "calc.y"
{ P("NUMBER"); }
break;
case 2:
#line 38 "calc.y"
{ P("STRING"); }
break;
case 3:
#line 39 "calc.y"
{ P("FUNCTION");}
break;
case 5:
#line 41 "calc.y"
{ P("PLUS"); }
break;
case 6:
#line 42 "calc.y"
{ P("SUB"); }
break;
case 7:
#line 43 "calc.y"
{ P("Mult"); }
break;
case 9:
#line 47 "calc.y"
{ P(yyvsp[-2].String); }
break;
case 10:
#line 48 "calc.y"
{ P(yyvsp[-3].String); }
break;
case 13:
#line 55 "calc.y"
{ P(yyvsp[0].String); }
break;
case 14:
#line 56 "calc.y"
{ P(yyvsp[0].String); }
break;
case 15:
#line 57 "calc.y"
{ P(yyvsp[-2].String); }
break;
case 16:
#line 58 "calc.y"
{ P(yyvsp[-3].String); }
break;
#line 457 "y_tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
