#include <extend.h>

CLIPPER charonly()
{

// get pointer to first parameter
char *cMask   = _parc(1);
int  nLenMask = _parclen(1);

// get pointer to second parameter
char *cStringIn   = _parc(2);
int  nLenStringIn = _parclen(2);

// some internal variables
int  i;
int  j;

// allocate some memory with a Clipper memory interface command.
// max output length is cStringIn length.
char *cStringOut;
int  nOutPointer = 0;
cStringOut = _xgrab( nLenStringIn );

// For each character in cStringIn.
for( i = 0; i < nLenStringIn; i++ )

    // And for each character in cMask.
    for( j = 0; j < nLenMask; j++ )

        // Got a match?
        if( cMask[ j ] == cStringIn[ i ] ) {

            // If so, assign the character and increment pointer.
            cStringOut[ nOutPointer++ ] = cStringIn[ i ];

            // no need to continue checking cMask
            j = nLenMask;

        }

// Send the output back to clipper
_retclen( cStringOut, nOutPointer );

// release the memory we _xgrab'bed above.
_xfree( cStringOut );

}
