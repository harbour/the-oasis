/***
* dbmem.c
*
* Show the contents of a Clipper .MEM file.
*
* This is an original work of Peter Townsend and is hereby placed in
* the public domain.
*
* COMPILE options
*     cl dbmem.c /c /AL /Zi
*
* LINK script
*     dbmem+ 
*     \c\lib\setargv.obj 
*     dbmem.exe /noe /noi 
*     nul 
*     ;
*
**/

#include "stdio.h"
#include "string.h"
#include "math.h"
#include "fcntl.h"
#include "stdlib.h"
#include "io.h"
#include "malloc.h"
#define STARTNO 2305508     /* 1st Mar, 1600 (nominally, not actually) */
#define STARTYY 1600
#define STARTMM 3
#define STARTDD 1

typedef struct
{
    char mname[11];        /* 10 + nil */
    char mtype;
    char mfiller1[4];
    char mlen;
    char mdec;
    char mfiller[14];
} MEM_REC;


MEM_REC mem_rec;

main(argc, argv)

int argc;
char *argv[];

    {
    int mem_handle,            /* File's handle */
        cntr,                  /* Loop counter for no of files to process */
        charcntr,              /* Loop counter to uppercase string */
        nyy, nmm, ndd,         /* Number of year, month, day */
        monthcntr;             /* Loop counter for months */
    int daymonths[12];         /* Days in a month */
    char filename[67];
    char datestr[11];          /* Date string */
    char *cstr;                /* For a character memvar */
    unsigned csize;            /* A character memvar's length */
    double num;                /* For a numeric or date */
    char log;                  /* For a Logical */
    char leapyear;             /* Is the current year a leapyear? */
    double daysin400yrs,
           daysin100yrs,
           daysin4yrs,
           daysin1yr;


    /* Make sure a parameter was passed */
	if (argc < 2)
	    {
        printf("USAGE: dbmem file.mem\n\n");
        exit(1);
        }

    /* Days in a given month */
    daymonths[0]  = 31;     /* Mar - after the dreaded February 28/29 */
    daymonths[1]  = 30;     /* Apr */
    daymonths[2]  = 31;     /* May */
    daymonths[3]  = 30;     /* Jun */
    daymonths[4]  = 31;     /* Jul */
    daymonths[5]  = 31;     /* Aug */
    daymonths[6]  = 30;     /* Sep */
    daymonths[7]  = 31;     /* Oct */
    daymonths[8]  = 30;     /* Nov */
    daymonths[9]  = 31;     /* Dec */
    daymonths[10] = 31;     /* Jan */
    daymonths[11] = 28;     /* Feb */

    /* These allow quick calculations and partial avoidance of leap years */
    daysin1yr     = 365;
    daysin4yrs    = ((daysin1yr * 4) + 1);
    daysin100yrs  = ((daysin4yrs * 25) - 1);
    daysin400yrs  = ((daysin100yrs * 4) + 1);

    /* How many file names do we have? */
    for(cntr = 1; cntr < argc; cntr++)
        {
        sprintf(filename, "%s", argv[cntr]);
        if (strlen(filename) > 4)
            {
            /* If it doesn't have an extension, add ".MEM" */
            if (strstr(filename, ".") == NULL)
                sprintf(filename, "%s.mem", argv[cntr]);
            }
        else
            sprintf(filename, "%s.mem", argv[cntr]);
        for(charcntr=0;charcntr<strlen(filename);charcntr++)
            filename[charcntr] = toupper(filename[charcntr]);
        /* Attempt file open.  Note must be opened in binary mode */
        mem_handle = open(filename, O_RAW | O_RDONLY);

        /* If error, complain and exit */
        if (mem_handle == -1)
            {
            printf("Error opening file %s\n", filename);
            exit(1);
            }
       
        printf("** %s **\n", filename);

        /* For each MEM_REC */

        while (read(mem_handle, (char *) &mem_rec, sizeof(MEM_REC)) 
               == sizeof(MEM_REC))
            {
            /* display MEM_REC header */
            printf("%-10s  ", mem_rec.mname);

            /* without top bit ! */
            printf("%c  ", mem_rec.mtype & 127);

            if ((mem_rec.mtype & 127) == 'C')
                {
                printf("%3d  ", (mem_rec.mlen - 1));
                printf("%3d  ", mem_rec.mdec);
                }
            else
                {
                printf("%3d  ", mem_rec.mlen);
                printf("%3d  ", mem_rec.mdec);
                }
            /* Now display its contents, depending on its type */
            switch(mem_rec.mtype & 127)
                {
                case 'C' :
                    /* remember, the length of a character string is */
                    /* contained in two bytes */
                    csize = mem_rec.mlen + mem_rec.mdec * 256;

                    /* allocate this size */
                    cstr = malloc(csize);

                    /* now read the character string */
                    read(mem_handle, cstr, csize);

                    /* display it */
                    printf("%s\n", cstr);

                    /* return dynamic memory */
                    free(cstr);
                    break;

                case 'N' :
                    /* A numeric is simply a C double.  Read 8 bytes */
                    /* and display it */
                    read(mem_handle, (char *)&num, 8);
                    printf("%f\n", num);
                    break;
                case 'D' :
                    /* A Date is represented the same way */
                    read(mem_handle, (char *)&num, 8);
                    strcpy(datestr, "  -  -    ");

                    /* log of 100 is a blank date */
                    if (log10(num) != 100)
                        {
                        if (num >= STARTNO )
                            {
                            num -= STARTNO;
                            nyy = STARTYY;
                            nmm = STARTMM;
                            ndd = STARTDD;
                            leapyear = 'N';
                            while (num >= daysin400yrs)
                                {
                                num -= daysin400yrs;
                                nyy += 400;
                                }
                            if (num == (daysin400yrs - 1))
                                {
                                nyy += 400;
                                num = 0;
                                leapyear = 'Y';
                                }
                            while (num >= daysin100yrs)
                                {
                                num -= daysin100yrs;
                                nyy += 100;
                                leapyear = 'N';
                                }
                            while (num >= daysin4yrs)
                                {
                                num -= daysin4yrs;
                                nyy += 4;
                                }
                            if (num == (daysin4yrs - 1))
                                {
                                nyy += 4;
                                num = 0;
                                leapyear = 'Y';
                                }

                            if (leapyear == 'Y')
                                {
                                ndd = 29;
                                nmm = 2;
                                }

                            while (num >= daysin1yr)
                                {
                                num -= daysin1yr;
                                nyy++;
                                }

                            monthcntr = 0;
                            while ((monthcntr < 11) && (num >= daymonths[monthcntr]))
                                {
                                num -= daymonths[monthcntr];
                                nmm++;
                                if (nmm == 13)
                                    {
                                    nmm = 1;
                                    nyy++;
                                    }
                                monthcntr++;
                                }
                            ndd += num;
                            }
                        else
                            {
                            num = 0;
                            nyy = 0;
                            nmm = 0;
                            ndd = 0;
                            }

                        sprintf(datestr, "%02d-%02d-%04d", ndd, nmm, nyy);
                        }

                    printf("%s\n", datestr);
                    break;

                case 'L' :
                    /* A logical is a simple 1 byte character field */
                    read(mem_handle, &log, 1);
                    printf("%s\n", (log == 0) ? ".F." : ".T.");
                }
            }
        }
    }

