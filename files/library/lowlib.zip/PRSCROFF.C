// Disables Print Screen Key

#include "\clipper5\include\extend.api"
#include "\clipper5\include\cpmi.h"

#define PRSCR_SEG 0x0050
#define _FP_SEG(fp) (*((unsigned __far *)&(fp)+1))
#define MK_FP(s,o) ((void far *)((((unsigned long)(s))<<16) | \
        ((unsigned long) (o))))

CLIPPER PrScrOff()
{
  char far *p_prscr;
  
  p_prscr=MK_FP(PRSCR_SEG,0);                      // real mode pointer

  // make p.m. pointer
  p_prscr = MK_FP( cpmiProtectedPtr( p_prscr, 2) , 0 );

  *p_prscr = 0x01;                                 // set busy flag

   cpmiFreeSelector(_FP_SEG(p_prscr));              // free p.m. pointer

  _ret();
  return;
}
