// cdrom.c - various cd-rom routines
// Paul J. Bosselaers 5/20/96    MS C 7.00

#include "\clipper5\include\cpmi.h"
#include "\clipper5\include\fm.api"

#define _FP_SEG(fp) (*((unsigned __far *)&(fp)+1))
#define _FP_OFF(fp) (*((unsigned __far *)&(fp)))

// various definitions
#define CLIPPER   void pascal
#define NULL      0L
#define TRUE       1
#define FALSE      0
#define ERROR     -1
#define NUMERIC      2
#define ISNUM(n)     (_parinfo(n) & NUMERIC)
typedef unsigned char far * BYTEP;

// extend.api functions
extern int _parinfo( int );
extern int          _parni(int, ...);
extern unsigned int _parclen(int, ...);
extern void _retni(int);
extern void _retclen(char far *, unsigned int);

// function prototypes
CLIPPER NUM_CDS();
CLIPPER IS_CD();
CLIPPER CD_LIST();
static int get_num_cds(void);

// returns number of accessible cd-roms, passed parameters: none
CLIPPER NUM_CDS()   
{
   _retni( get_num_cds() );
   return;
}

// determines if a drive is a cd-rom drive
// passed parameter: zero-based drive number (A=0,B=1,...)
// returns: -1 if error, 0 if not a cd, 1 if a cd
CLIPPER IS_CD()
{
   unsigned int drive;
   int retval = 0;

   // parameter checking
  if ( !ISNUM(1) ) {
     _retni(ERROR);
     return;
   }

   drive = _parni(1);
   if (drive < 0 || drive > 25) {
     _retni(ERROR);
     return;
   }

   _asm
   {
      mov   ax,150Bh;
      mov   bx,00h;
      mov   cx,drive;
      int   2Fh;
      cmp   bx,0ADADh;
      je    NO_ERR;
      mov   retval,ERROR
      jmp   short ASM_EXIT;
    NO_ERR:
      mov   retval,ax;
    ASM_EXIT:
   }

   if (retval != 0 && retval != ERROR)
      retval = 1;

   _retni(retval);
   return;
}

// returns a list of cd-rom drives, or empty string on error
// passed parameters: none
CLIPPER CD_LIST()
{
   unsigned char i;
   unsigned int uiProtMode, uiSeg, uiOff; 
   BYTEP cd_drives = NULL;
   BYTEP rmPtr = NULL;
   CPUREGS regs, outregs;
   int nCDs = get_num_cds();

   if (nCDs == 0) {     // not ready
      _retclen(" ",1);
      return;
   }

   uiProtMode = cpmiIsProtected();     // in protected mode?

   if (uiProtMode) {
      _FP_SEG(cd_drives) = cpmiAllocateDOSMem( 26 );
      _FP_OFF(cd_drives) = 0;
      if (cd_drives == NULL) {
         _retclen(" ",1);
         return;
      }
      rmPtr = cpmiRealPtr( cd_drives );
      if (rmPtr != NULL) {
         regs.Reg.AX = 0x150D;
         regs.Reg.ES = _FP_SEG( rmPtr );
         regs.Reg.BX = _FP_OFF( rmPtr );
         cpmiInt86(0x2f,&regs,&outregs);
      }
      else {
         _retclen(" ",1);
         return;
      }
   }
   else {
      cd_drives = (char far *) _xalloc( 26 );
      if (cd_drives == NULL) {
         _retclen(" ",1);
         return;
      }
      uiSeg = _FP_SEG( cd_drives );
      uiOff = _FP_OFF( cd_drives );
      _asm
      {
         mov   ax,150Dh;
         mov   es,uiSeg;
         mov   bx,uiOff;
         int   2Fh;
      }
   }

  // cd-drives contains zero-based numbers corresponding to drive letters
  // so convert them to the appropriate letters
  for ( i = 0; i < nCDs; i++)
    cd_drives[i] = cd_drives[i] + 'A';

  _retclen(cd_drives,nCDs);
   if (uiProtMode) {
      cpmiFreeDOSMem( _FP_SEG( cd_drives ) );
   }
   else {
      _xfree( cd_drives );
   }
  return;
}

// -------------------------------------------------------------------- //
// determine number of accessible cd-roms
static int get_num_cds(void)
{
   int nCDs = 0;

   _asm
   {
      mov   ax,1500h;
      mov   bx,00h;
      int   2Fh;
      mov   nCDs,bx
   }

   return (nCDs);
}

