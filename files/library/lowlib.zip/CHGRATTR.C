#include "\clipper5\include\extend.api"
#include "\clipper5\include\gt.api"
#include "\clipper5\include\cpmi.h"

#define COLOR_SEG 0xB800
#define MONO_SEG  0xB000
#define VIDEO_INT 0x10
#define SCREENSIZE 4096

#define _FP_SEG(fp) (*((unsigned __far *)&(fp)+1))
#define MK_FP(s,o) ((void far *)((((unsigned long)(s))<<16) | \
        ((unsigned long) (o))))

CLIPPER ChgRowAttr()
{
  unsigned int srow, scol, ecol, attr;                // for parameters
  unsigned char vpage,vcols,vmode;
  unsigned char i;
  int far *p_video;

  // get and check parameters
  if (PCOUNT != 4) {
    _ret();
    return;
  }

  srow = _parni(1);                            // row to change attributes
  if (srow < 0 || srow > 24) {
    _ret();
    return;
  }
                                 
  scol = _parni(2);                            // starting column
  if (scol < 0 || scol > 79) {
    _ret();
    return;
  }

  ecol = _parni(3);                            // ending column
  if (ecol < 0 || ecol > 79 || ecol < scol) {
    _ret();
    return;
  }
 
  attr = _parni(4);                           // new screen attribute
  attr = (attr << 8);

  // get video information
  _asm {
    cli;
    mov  ah,0Fh;
    int  10h;
    sti;
    mov  vpage,bh;                           // video page
    mov  vcols,ah;                           // number of columns on screen
    mov  vmode,al;                           // video mode
  }

  // real mode video pointer
  p_video=MK_FP(vmode == 7 ? MONO_SEG : COLOR_SEG,vpage * SCREENSIZE);

  // make p.m. pointer
  p_video = MK_FP( cpmiProtectedPtr( p_video, SCREENSIZE) , 0 );

  p_video += (vcols * srow + scol);       // point to start row,col

  _gtPreExt();                     // prepare clipper for direct video access

  for (i=0;i<=(ecol-scol);i++) {              // change attributes
    // clear old attribute byte first, then set new one
    *p_video = (*p_video & 0x00FF) | attr;
    p_video++;
  }

  _gtPostExt();                   // give video control back to clipper

  cpmiFreeSelector(_FP_SEG(p_video));        // free p.m. pointer

  _ret();
  return;
}
