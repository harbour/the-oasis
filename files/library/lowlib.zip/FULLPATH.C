/*
   fullpath.c - Clipper callable function to expand a partial file spec.
   to a full spec.  Need to include LLIBCA.LIB in Clipper link script.

   Compile : cl /c /AL /FPa /Gs /Oalt /Zl /G2 fullpath.c

   Paul J. Bosselaers, 1/10/95
*/
#include <\clipper5\include\extend.api>
#include <\clipper5\include\fm.api>
#include <stdlib.h>

CLIPPER FULLPATH()
{
   char *buffer;

   if (PCOUNT == 1) {
     buffer = _xgrab(_MAX_PATH);             // allocate memory for buffer
     _retc(_fullpath(buffer,_parc(1),_MAX_PATH));  // return full path
     _xfree(buffer);                               // free allocated memory
     }
}
