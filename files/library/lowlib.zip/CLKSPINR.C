// Runs a spinning wheel off the system clock
// requires LLIBCA

#include "\clipper5\include\extend.api"
#include "\clipper5\include\cpmi.h"
#include <dos.h>
#include <stdlib.h>

#pragma check_pointer( off )

#define COLOR_SEG 0xB800
#define MONO_SEG  0xB000
#define VIDEO_INT 0x10
#define SCREENSIZE 4096
#define GOOD      1
#define BAD       0
#define ON        1
#define OFF       0

#define MK_FP(s,o) ((void far *)((((unsigned long)(s))<<16) | \
        ((unsigned long) (o))))

/* Prototypes for functions */
void (__interrupt __far *oldtimer)();
void __interrupt __far newtimer();

// Global Variables
int on_or_off = OFF;
unsigned int attr, org_c_a;
unsigned char spinner[] = "|/�\\", spin_index = 0;
int far *p_video;

CLIPPER CLK_SPIN()
{
  unsigned int srow, scol;
  unsigned char vpage = 0,vcols = 80,vmode = 3;
  unsigned int temp;

  // if no parameters passed, return status ( on or off)
  if (PCOUNT == 0) {
    _retni(on_or_off);
    return;
  }

  // get and check parameters
  temp = _parni(1);                             // on or off
  // check invalid param or duplicated command 
  if ((temp != ON && temp != OFF) || (on_or_off == temp)) {
    _retni(BAD);
    return;
  }
  else
    on_or_off = temp;

  if (on_or_off == ON) {
    if (PCOUNT != 4) {                             // ON needs 4 params
      _retni(BAD);
      return;
    }
    else {                                         // get rest of params     
      srow = _parni(2);                            // display row
      if (srow < 0 || srow > 24) {
        _retni(BAD);
        return;
      }
                                 
      scol = _parni(3);                            // display column
      if (scol < 0 || scol > 79) {
        _retni(BAD);
        return;
      }
                                 
      attr = _parni(4);                           // screen attribute
      attr = (attr << 8);

      // get video information
      _asm {
        cli;
        mov  ah,0Fh;
        int  10h;
        sti;
        mov  vpage,bh;                           // video page
        mov  vcols,ah;                           // number of columns on screen
        mov  vmode,al;                           // video mode
      }

      // real mode video pointer
      p_video = MK_FP(vmode == 7 ? MONO_SEG : COLOR_SEG,vpage * SCREENSIZE);
      // make p.m. pointer
      p_video = MK_FP( cpmiProtectedPtr( p_video, SCREENSIZE) , 0 );
      p_video += (vcols * srow + scol);        // point to start row,col
      org_c_a = *p_video;                      // save orig. char & attribute
      // replace current timer routine
      oldtimer = _dos_getvect( (unsigned)0x08 );
      _disable();
      _dos_setvect( 0x08, newtimer );
      _enable();
    }
  }
  else {                                     // OFF
    _disable();         
    _dos_setvect( 0x08, oldtimer );          // restore old interrupt
    _enable();
    *p_video = org_c_a;                      // restore old char & attribute
    cpmiFreeSelector(_FP_SEG(p_video));       // free p.m. pointer
  }

  _retni(GOOD);
  return;
}
/* -------------------------------------------------------------------- */

void __interrupt __far newtimer()
{
  (*oldtimer)();                        // execute orig. interrupt

  _disable();
  // display spinner character and advance spin_index
  *p_video = (attr | spinner[spin_index]);
  spin_index = (spin_index == 3) ? 0 : ++spin_index;  // valid range is 0 - 3
  _enable();
}
/* -------------------------------------------------------------------- */
