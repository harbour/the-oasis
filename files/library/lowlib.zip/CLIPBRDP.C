/*
   Clipper-callable C functions to access the Windows Clipboard
   Paul J. Bosselaers

   Compile 5.2: cl /c /AL /FPa /Gs /Oalt /Zl /G2 clipbrdp.c
           5.3: cl /c /AL /FPi /Gs /Oalt /Zl /G2 clipbrdp.c

   Protected Mode
*/
#include "\clipper5\include\cpmi.h"

// _bcopy is in CLIPPER.LIB and is useful for copying memory blocks.
extern void *_bcopy( void *tgt, void *src, unsigned nBytes );

// from dos.h
#define _FP_SEG(fp) (*((unsigned __far *)&(fp)+1))
#define _FP_OFF(fp) (*((unsigned __far *)&(fp)))

// various definitions, mostly from clipdefs.h
#define CLIPPER   void pascal
#define NULL      0L
#define CHARACTER    1
#define MPTR        32
#define ISCHAR(n)    (_parinfo(n) & CHARACTER)
#define ISBYREF(n)   (_parinfo(n) & MPTR)
#define MAX_CLIP_STRING     65516
#define WCLIP_TEXT          0x01
typedef unsigned char       BYTE;
typedef unsigned char far * BYTEP;
typedef void far *          FARP;
typedef unsigned int        WORD;
typedef unsigned long       DWORD;
#define MAKEDWORD(low, high) ((DWORD)(((WORD)(low)) | (((DWORD)((WORD)(high))) << 16)))

// extend.api functions
extern int _parinfo( int );
extern void _retl(int);
int _storclen(char far *, int, ...);
extern char *       _parc(int, ...);
extern unsigned int _parclen(int, ...);

// function prototypes
CLIPPER IS_CLIPBRD();
CLIPPER SEND_CLIPB();
CLIPPER GET_CLIPB();

// checks if windows clipboard is available
// parameters: none
// return: logical
CLIPPER IS_CLIPBRD()
{
  BYTE ret_al;
  WORD ret_ax;

  // Verify 386 Windows present
  _asm {
    MOV  ax,1600h;
    INT  2Fh;
    MOV  ret_al,al;
  }

if (ret_al==0 || ret_al==1 || ret_al==0x80 || ret_al==0xFF) {
    _retl(FALSE);
    return;
  }

  // verify we can use the clipboard 
  _asm {
    MOV  ax,1700h;
    INT  2Fh;
    MOV  ret_ax,ax;
  }
  // What? WINOLDAP doesn't support clipboard
  if (ret_ax==0x1700)
    _retl(FALSE);
  else
    // Everything's OK
    _retl(TRUE);
  return;
}

// open the clipboard, empty it, then copy the passed character string to it
// parameters: character string
// return: logical
CLIPPER SEND_CLIPB()
{
  WORD ret_ax;
  WORD uiSize;
  CPUREGS regs,outregs;
  auto BYTEP buffer = NULL;
  auto BYTEP rmPtr = NULL;

  // parameter checking
  if (!(ISCHAR(1) && (uiSize = _parclen(1)) > 0 )) {
    _retl(FALSE);
    return;
  }

  // open the clipboard
  _asm {
    MOV  ax,1701h;
    INT  2Fh;
    MOV  ret_ax,ax;
  }
  // if ret_ax == 0 clipboard already in use
  if (!(ret_ax)) {
    _retl(FALSE);
    return;
  }
  // empty the clipboard
  _asm {
    MOV  ax,1702h;
    INT  2Fh;
    MOV  ret_ax,ax;
  }
  // if ret_ax != 0 try to copy
  if (ret_ax) {
    _FP_SEG(buffer) = cpmiAllocateDOSMem( uiSize + 1 );
    _FP_OFF(buffer) = 0;
    if (buffer != NULL) {
      buffer[ uiSize ] = 0;
      _bcopy( buffer, _parc( 1 ), uiSize );
      rmPtr = cpmiRealPtr( buffer );
      if (rmPtr != NULL) {
        regs.Reg.ES = _FP_SEG( rmPtr );
        regs.Reg.BX = _FP_OFF( rmPtr );
        regs.Reg.AX = 0x1703;
        regs.Reg.DX = WCLIP_TEXT;
        regs.Reg.SI = 0;
        regs.Reg.CX = uiSize;
        cpmiInt86(0x2f,&regs,&outregs);
        if (outregs.Reg.AX)
          _retl(TRUE);
        else
          _retl(FALSE);
      }
      else
        _retl(FALSE);

      cpmiFreeDOSMem( _FP_SEG(buffer) );
    }
    else
      _retl(FALSE);
  }
  else
    _retl(FALSE);

  // close the clipboard
  _asm {
    MOV  ax,1708h;
    INT  2Fh;
  }
  return;
}

// open the clipboard, then copy the data to a character string 
// parameters: character string passed by reference
// return: logical true if no error, logical false if an error occurred
CLIPPER GET_CLIPB()
{
  WORD ret_ax, ret_dx;
  DWORD ulSize;
  WORD uiSize;
  CPUREGS regs, outregs;
  auto BYTEP buffer = NULL;
  auto BYTEP rmPtr = NULL;

  // parameter checking
  if (! ( ISCHAR(1) && ISBYREF(1) ) )  {
    _retl(FALSE);
    return;
  }

  // open the clipboard
  _asm {
    MOV  ax,1701h;
    INT  2Fh;
    MOV  ret_ax,ax;
  }
  // if ret_ax == 0 clipboard already in use
  if (!(ret_ax)) {
    _retl(FALSE);
    return;
  }

  // get clipboard data size
  _asm {
    MOV  ax,1704h;
    MOV  dx,WCLIP_TEXT;
    INT  2Fh;
    MOV  ret_dx,dx;
    MOV  ret_ax,ax;
  }
  ulSize = MAKEDWORD(ret_ax,ret_dx);
  // clipboard doesn't contain text
  if (ulSize == 0) {
    _storclen(" ",1,1);     // return empty string
    _retl(TRUE);
    return;
  }

  // make sure we don't bring in too much data for clipper to handle
  if (ulSize >= MAX_CLIP_STRING) {
    _retl(FALSE);
    return;
  }

  // allocate buffer for data
  uiSize = (WORD)ulSize;
  _FP_SEG(buffer) = cpmiAllocateDOSMem( uiSize + 1 );
  _FP_OFF(buffer) = 0;
  if (buffer != NULL) {
    buffer[ uiSize ] = 0;
    rmPtr = cpmiRealPtr( buffer );
    if (rmPtr != NULL) {
      regs.Reg.ES = _FP_SEG( rmPtr );
      regs.Reg.BX = _FP_OFF( rmPtr );
      regs.Reg.AX = 0x1705;
      regs.Reg.DX = WCLIP_TEXT;
      regs.Reg.SI = 0;
      regs.Reg.CX = uiSize;
      cpmiInt86(0x2f,&regs,&outregs);
      if (outregs.Reg.AX) {
        _storclen( buffer, uiSize, 1);
        _retl(TRUE);
      }
      else
        _retl(FALSE);
    }
    else 
      _retl(FALSE);

    cpmiFreeDOSMem( _FP_SEG(buffer) );
  }
  else 
    _retl(FALSE);

  // close the clipboard
  _asm {
    MOV  ax,1708h;
    INT  2Fh;
  }
 return;
}
