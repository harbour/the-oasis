/* Windows 95 long filename functions - calls std DOS functions if unable
   to use W95 interupts.  Clipper-callable, protected mode.

   Compile 5.2: cl /c /AL /FPa /Gs /Oalt /Zl /G2 longfnam.c

   Paul J. Bosselaers 10/22/97
*/
#include "\clipper5\include\cpmi.h"

// _bcopy is in CLIPPER.LIB and is useful for copying memory blocks.
extern void *_bcopy( void *tgt, void *src, unsigned nBytes );
// strlen is also in CLIPPER.LIB
extern unsigned int strlen(const char *);

// from dos.h
#define _FP_SEG(fp) (*((unsigned __far *)&(fp)+1))
#define _FP_OFF(fp) (*((unsigned __far *)&(fp)))

// various definitions, mostly from clipdefs.h
#define CLIPPER   void pascal
#define NULL      0L
#define MAX_PATH  260   // max length of W95 long filename including NULL
#define CHARACTER    1
#define MPTR        32
#define ISCHAR(n)    (_parinfo(n) & CHARACTER)
#define ISBYREF(n)   (_parinfo(n) & MPTR)
#define CARRY     0x01
typedef unsigned char       BYTE;
typedef unsigned char far * BYTEP;
typedef void far *          FARP;
typedef unsigned int        WORD;
typedef unsigned long       DWORD;

// extend.api functions
extern int          _parinfo( int );
extern void         _retl(int);
extern char *       _parc(int, ...);
extern unsigned int _parclen(int, ...);
int                 _storclen(char far *, int, ...);

// function prototypes
CLIPPER MD();
//CLIPPER CD();
//CLIPPER RD();
CLIPPER GET83NAME();

// make a directory
// gets path from Clipper
// Returns Logical True if successful, logical false if not.
CLIPPER MD()
{
  WORD uiSize;
  CPUREGS regs,outregs;
  BYTEP buffer = NULL;
  BYTEP rmPtr = NULL;

  // parameter checking
  if (!(ISCHAR(1) && (uiSize = _parclen(1)) > 0 )) {
    _retl(FALSE);
    return;
  }

  _FP_SEG(buffer) = cpmiAllocateDOSMem( uiSize + 1 );
  _FP_OFF(buffer) = 0;
  if (buffer != NULL) {
    buffer[ uiSize ] = 0;
    _bcopy( buffer, _parc( 1 ), uiSize );
    rmPtr = cpmiRealPtr( buffer );
    if (rmPtr != NULL) {
      /* get flags in ax, set carry, move to register structure */
      _asm {
         pushf;
         pop   ax;
         or    ax,1;
         mov   regs.Reg.Flags,ax;
         }
      regs.Reg.DS = _FP_SEG( rmPtr );
      regs.Reg.DX = _FP_OFF( rmPtr );
      regs.Reg.AX = 0x7139;
      cpmiInt86(0x21,&regs,&outregs);
      if (outregs.Reg.Flags & CARRY)   // carry flag set?
         {
         if (outregs.Reg.AX == 0x7100) // can't do long filenames, try std
            {
            regs.Reg.DS = _FP_SEG( rmPtr );
            regs.Reg.DX = _FP_OFF( rmPtr );
            regs.Reg.AX = 0x3900;
            cpmiInt86(0x21,&regs,&outregs);
            if (outregs.Reg.Flags & CARRY)   // carry flag set?
              _retl(FALSE);   // error creating directory
            else
              _retl(TRUE);    // created directory
            }
         else
           _retl(FALSE);
         }
      else  // carry clear = ok with long filename
        _retl(TRUE);
    }
    else
      _retl(FALSE);

    cpmiFreeDOSMem( _FP_SEG(buffer) );
  }
  else
    _retl(FALSE);

}

// gets short (8.3) filename from long filename
// parameter 1: long filename from clipper
// parameter 2 passed by reference gets short (8.3) filename with full path
// return: logical true if no error, logical false if an error occurred
CLIPPER GET83NAME()
{
  WORD uiSize;
  CPUREGS regs,outregs;
  BYTEP inbuffer = NULL;
  BYTEP rmInPtr = NULL;
  BYTEP outbuffer = NULL;
  BYTEP rmOutPtr = NULL;

  // parameter checking
  if (!(ISCHAR(1) && (uiSize = _parclen(1)) > 0 )) {
    _retl(FALSE);
    return;
  }
  if (! ( ISCHAR(2) && ISBYREF(2) ) )  {
    _retl(FALSE);
    return;
  }

  // allocate 67 bytes for return from interrupt
  _FP_SEG(outbuffer) = cpmiAllocateDOSMem( 67 );
  _FP_OFF(outbuffer) = 0;
  if (outbuffer == NULL) {
    _retl(FALSE);
    return;
  }

  outbuffer[66] = 0;    // just in case...
  rmOutPtr = cpmiRealPtr( outbuffer );
  if (rmOutPtr != NULL) {

     // buffer to hold parameter
     _FP_SEG(inbuffer) = cpmiAllocateDOSMem( uiSize + 1 );
     _FP_OFF(inbuffer) = 0;

     if (inbuffer != NULL) {
       inbuffer[ uiSize ] = 0;
       _bcopy( inbuffer, _parc( 1 ), uiSize );
       rmInPtr = cpmiRealPtr( inbuffer );
       if (rmInPtr != NULL) {
         regs.Reg.DS = _FP_SEG( rmInPtr );
         regs.Reg.SI = _FP_OFF( rmInPtr );
         regs.Reg.ES = _FP_SEG( rmOutPtr );
         regs.Reg.DI = _FP_OFF( rmOutPtr );
         regs.Reg.CX = 0x0001;
         regs.Reg.AX = 0x7160;
         cpmiInt86(0x21,&regs,&outregs);
         if (outregs.Reg.Flags & CARRY)   // carry flag set?  yes on error
            {
            _retl(FALSE);
            }
         else  // good to go...
            {
            _storclen( outbuffer, strlen(outbuffer), 2);
            _retl(TRUE);
            }
       }
       else             // rmInPtr is NULL
         _retl(FALSE);
   
       cpmiFreeDOSMem( _FP_SEG(inbuffer) );
     }
     else             // inbuffer is NULL
       _retl(FALSE);
  }
  else             // rmOutPtr is NULL
    _retl(FALSE);
   
  cpmiFreeDOSMem( _FP_SEG(outbuffer) );
}
   
