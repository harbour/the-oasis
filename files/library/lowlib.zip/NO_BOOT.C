// no_boot.c - prevents Ctrl-Alt-Del reboot
// requires LLIBCA

#include <dos.h>

#define KEYBOARD_INTR 0x09
#define KEYBOARD_PORT 0x60
#define DELETE_KEY    0x53
#define TRUE         1
#define FALSE        0
#define CLIPPER   void pascal

#pragma check_pointer( off )

// Prototypes for functions
extern void _ret(void);
void (__interrupt __far *oldkeyb)();
void __interrupt __far newkeyb();
CLIPPER REBOOT_OFF();
CLIPPER REBOOT_ON();

// global variables 
int hooked_intr = FALSE;

CLIPPER REBOOT_OFF()
{
    // replace current keyboard routine
    if (!hooked_intr) {
      oldkeyb = _dos_getvect( (unsigned)KEYBOARD_INTR );
      _disable();
      _dos_setvect( KEYBOARD_INTR, newkeyb );
      _enable();
      // don't allow to call more than once w/o resetting
      hooked_intr = TRUE;
    }
    _ret();
}

CLIPPER REBOOT_ON()
{
    // restore old keyboard routine
    if (hooked_intr) {
      _disable();         
      _dos_setvect( KEYBOARD_INTR, oldkeyb );
      _enable();
      hooked_intr = FALSE;                             // reset flag  
    }
    _ret();
}
/* -------------------------------------------------------------------- */

void __interrupt __far newkeyb()
{
  unsigned char scancode;
  unsigned int do_old = TRUE;

  _disable();

  scancode = _inp(KEYBOARD_PORT);   // read scan code
  if (scancode == DELETE_KEY) {
    // get shift status
    _asm {
         PUSH  AX
         PUSH  DS
         MOV   AX,0040h    ; point to BIOS data segment
         MOV   DS,AX
         MOV   AL, DS:[017h]  ; keyboard status flag
         POP   DS
         TEST  AL,8         ; check for ctrl-alt
         JZ    SHORT NOREBOOT
         TEST  AL,4
         JZ    SHORT NOREBOOT

         ; If detected a ^ALT-DEL then eat it
         IN     AL,61H
         MOV    AH,AL
         OR     AL,80H
         OUT    61H,AL
         MOV    AL,AH
         OUT    61H,AL
         MOV    AL,20H
         OUT    20H,AL
         MOV    do_old,FALSE  // don't execute original interrupt
      NOREBOOT:
         POP    AX
    }
  }
  _enable();

  if (do_old)
    (*oldkeyb)();                        // execute orig. interrupt
}
/* -------------------------------------------------------------------- */
