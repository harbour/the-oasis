/* Clipper callable function to determine if running in a DOS box under
   Windows - by Paul J. Bosselaers 10/9/97
*/

// various definitions
#define CLIPPER   void pascal
#define TRUE                1
#define FALSE               0
typedef unsigned char       BYTE;
typedef unsigned int        WORD;

// extend.api functions
extern void _retl(int);

// function prototypes
CLIPPER ISWIN();

// parameters: none
// return: logical
CLIPPER ISWIN()
{
  BYTE ret_al;

  // Verify Windows present
  _asm {
    MOV  ax,1600h;
    INT  2Fh;
    MOV  ret_al,al;
  }

  if (ret_al==0 || ret_al==1 || ret_al==0x80 || ret_al==0xFF)
    // not under Windows or under Windows 2.x
    _retl(FALSE);
  else
    // Everything's OK
    _retl(TRUE);
  return;
}

