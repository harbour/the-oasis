

#include <extend.h>
#include <gt.api>
#include <filesys.api>
#include <fm.api>
#include <blx286.h>



#define SEG(fp) (*((unsigned _far *)&(fp)+1))
#define OFF(fp) (*((unsigned _far *)&(fp)))

CLIPPER loadfont()
{
   FHANDLE f ;
   char far * buf ;
   char size[2] ;
   unsigned char siz = 0 ;
   unsigned int fpOff ;
   unsigned int fpSeg ;
   Boolean RetVal = FALSE ;
   SEL selector ;

   if (_parinfo(0) > 0)
      {
         if (_parinfo(1) == CHARACTER)
            {
               if ((f = _fsOpen(_parc(1),FO_READ)) != NULL)
                  {
                     _fsRead(f,size,1) ;
                     siz = size[0]  ;

                     if ((buf = _xgrab(siz*256)) != NULL)
                        {
                           fpOff = OFF(buf) ;
                           fpSeg = SEG(buf) ;

                           _fsRead(f,buf,siz * 256) ;

                           _asm {
                                    push es
                                    push bp
                                    mov  dx, word ptr buf
                                    push dx
                                    mov  dx, word ptr buf + 2
                                    push dx
                                    mov  al, 10h
                                    mov  bh, siz
                                    mov  bl, 0
                                    mov  cx, 256
                                    mov  dx, 0
                                    pop  es
                                    pop  bp
                                    mov  ah, 11h
                                    int  10h
                                    pop  bp
                                    pop  es
                                }
                           RetVal = TRUE ;

                           _xfree(buf) ;
                        }
                     _fsClose(f) ;
                  }
            }
      }

   _retl( RetVal ) ;
}
