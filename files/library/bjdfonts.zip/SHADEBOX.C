

#include <extend.h>
#include <gt.api>
#include <vm.api>


HIDE void near ReverseAtrrib( USHORT uiTRow,
                              USHORT uiLCol,
                              USHORT uiBRow,
                              USHORT uiRCol );



CLIPPER ShadeBox()
{
   int t = _parni(1) ;
   int l = _parni(2) ;
   int b = _parni(3) ;
   int r = _parni(4) ;

   if (t < 0)
      t = 0 ;
   if (l < 0)
      l = 0 ;
   if (b > _gtMaxRow())
      b = _gtMaxRow() ;
   if (r > _gtMaxCol())
      r = _gtMaxCol() ;

   ReverseAtrrib( t, l, b, r );

}

 
 
 
 
 
 
 
/***
*   Reverse text Attribute for
*   passed coordinates
*/

HIDE void near ReverseAtrrib( USHORT uiTRow,
                             USHORT uiLCol,
                             USHORT uiBRow,
                             USHORT uiRCol )
{
   char far * vlpScreen;
   HANDLE hVM;
   USHORT uiBuffSize;

   USHORT uiRow;
   USHORT uiCol;
   USHORT i;
   unsigned char c ;

   _gtRectSize( uiTRow, uiLCol, uiBRow, uiRCol, &uiBuffSize );

   if (( hVM = _xvalloc( uiBuffSize, 0 ) ) == 0)
      return;

   vlpScreen = _xvlock( hVM );

   _gtSave( uiTRow, uiLCol, uiBRow, uiRCol, vlpScreen );

   for ( uiRow = uiTRow; uiRow <= uiBRow; ++uiRow )
      {
         i = ( (uiRow - uiTRow) * (uiRCol - uiLCol + 1)
               * 2 ) + 1;
         for ( uiCol = uiLCol; uiCol <= uiRCol; ++uiCol, i += 2 )
            {
               c = vlpScreen[i] << 1 ;
               c = c >> 1 ;

               if (c == vlpScreen[i])
                  {
                     c = c << 4 ;
                     c = c >> 4 ;
                  }

               if (c & 0x08)
                  c -= 0x08 ;

               if (c == 0)
                  c = 0x0008;

               vlpScreen[i] = c ;
            }
      }
   _gtRest( uiTRow, uiLCol, uiBRow, uiRCol, vlpScreen );

   while (_xvlockcount( hVM))
      _xvunlock( hVM ) ;

   _xvfree( hVM ) ;
}
 











