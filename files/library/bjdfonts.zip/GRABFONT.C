/*****************************************************************************
* Program.: GRABFONT.C                                                       *
* By......: David A Pearson                                                  *
*   Modified By Brian Dukes                                                  *
* Function: Utility extract a font definition from a FontEdit .COM file into *
* ........: a font file.                                                     *
* Notes...: Compile with Turbo C  or Microsoft C                             *
*****************************************************************************/

/*****************************************************************************
*
*  Changes Made By Brian Dukes :
*     The original work contained within was written by Dave Pearson, who 
*     released it originally onto The Dark Knight Returns BBS, a Clipper
*     orientated bulletin board system.
*
*    Dave gave me personal authority to modify this code and to release it
*    into the world freely either into PD or under a GPL license.
*
*    The changes that I actually made to this code are VERY minor, all I did
*    was to make the code sniff the font.com file to determine the dimension
*    of the character set.  The number of scan lines per character is important
*    and this is now written as the FIRST BYTE of th output.fnt file that this
*    program will generate.
*
*    My thanks obviously go to Dave Pearson for giving me the original version
*    to allow my creative thoughts to go to work on.
*
*    You are free to copy this code and modify it anyway you like, obviously
*    Brian Dukes & Dave Pearson take NO RESPONSIBILITY OR LIABILTY for this
*    code in any way ... However we do request that you keep this header 
*    intact in any future versions.
*
*    If you have any comments to make about this code or any suggestions or
*    changes you would like to see in any future versions of this code then
*    please feel free to email either of us.
*
*    email to :   bdukes@crox.demon.co.uk         
*          or :   davep@hagbard.demon.co.uk
*
*****************************************************************************/

#include <stdio.h>

#define BYTES_IN_CHAR_SET   256
#define MAX_CHAR_SCAN_LINES 16

#define CHAR_TABLE_SIZE (MAX_CHAR_SCAN_LINES * BYTES_IN_CHAR_SET)

char buffer[CHAR_TABLE_SIZE];

/*****************************************************************************
* Function: main()                                                           *
* Syntax..: int main(int argc, char *argv[])                                 *
* Usage...: Main entry functions.                                            *
* By......: David A Pearson                                                  *
*****************************************************************************/

int main(int argc, char *argv[])
{
        FILE *OutFile;
        FILE *InFile;
        int size = 0 ;

        fprintf(stderr,"\nGrabFont - By David A Pearson  &  Brian Dukes\n");
        if (argc == 3)
        {
                if ((InFile = fopen(argv[1],"rb")) != NULL)
                {
                        if ((OutFile = fopen(argv[2],"wb")) != NULL)
                        {
                                fprintf(stderr,"\n%s --> %s\n",argv[1],argv[2]);
                                fseek(InFile,0x32,SEEK_SET) ;
                                fread(buffer,sizeof(char),1,InFile) ;
                                size = buffer[0] ;
                                fprintf(stderr,"\n%dx8 Font Size Detected\n",size) ;
                                size = size * BYTES_IN_CHAR_SET ;
                                fseek(InFile,99,SEEK_SET);
                                fread(buffer,sizeof(char),size,InFile);
                                fwrite(buffer,sizeof(char),size,OutFile);
                                fclose(OutFile);
                        }
                        else
                        {
                                fprintf(stderr,"%c\nError: Can't create font file `%s'\n",7,argv[2]);
                        }
                        fclose(InFile);
                }
                else
                {
                        fprintf(stderr,"%c\nError: Can't open file `%s' for reading.\n",7,argv[1]);
                }
        }
        else
        {
                fprintf(stderr,"%c\nSyntax: GrabFont <FontEditComFile> <FontFile>\n",7);
                fprintf(stderr,"\nFor example:  GrabFont MyFont.Com MyFont.Fnt\n");
        }
        exit(0);
}
