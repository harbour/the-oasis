#include <extend.h>


CLIPPER MAXCOL()
{

    unsigned int far * cols ;

    (long)cols = (long)0x0000044AL ;

    _retni((unsigned char)(*cols)-1) ;

}



CLIPPER MAXROW()
{

    unsigned int far * rows ;
    (long)rows = (long)0x00000484L ;

    _retni((unsigned char)(*rows)) ;

}
