#include <blx286.h>
#include <extend.h>

#define FP_SEG(fp) (*((unsigned _far *)&(fp)+1))
#define FP_OFF(fp) (*((unsigned _far *)&(fp)))



CLIPPER MAXCOL()
{

  SEL  low_mem ;
  char far * ptr ;
  char buf[2] ;
  unsigned int * np ;
  unsigned int num ;

  buf[0] = '\0' ;
  buf[1] = '\0' ;

  if ( DosMapRealSeg(0,0x500,&low_mem) != 0 ) 
  {
    _retni(79) ;
  }
  FP_SEG(ptr) = low_mem ;
  FP_OFF(ptr) = 0x0000 ;

  (char *)np = (char *)buf ;

  buf[0] = ptr[0x44a] ;

  num = *np - 1;

  DosFreeSelector(low_mem) ;
  _retni(num) ;
}



CLIPPER MAXROW()
{

  SEL  low_mem ;
  char far * ptr ;
  char buf[2] ;
  unsigned int * np ;

  buf[0] = '\0' ;
  buf[1] = '\0' ;

  if ( DosMapRealSeg(0,0x500,&low_mem) != 0 ) 
  {
    _retni(24) ;
  }
  FP_SEG(ptr) = low_mem ;
  FP_OFF(ptr) = 0x0000 ;

  (char *)np = (char *)buf ;

  buf[0] = ptr[0x484] ;

  DosFreeSelector(low_mem) ;
  _retni(*np) ;
}
