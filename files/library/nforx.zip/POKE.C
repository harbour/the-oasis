/*
 * File......: POKE.C
 * Author....: Ted Means
 * Date......: $Date:   15 Jul 1993 22:46:50  $
 * Revision..: $Revision:   1.0  $
 * Log file..: $Logfile:   C:/nanfor/src/exo/poke.c_v  $
 * 
 * This is an original work by Ted Means and is placed in the
 * public domain.
 *
 * Modification history:
 * ---------------------
 *
 * $Log:   C:/nanfor/src/exo/poke.c_v  $
 * 
 *    Rev 1.0   15 Jul 1993 22:46:50   GLENN
 * Initial revision.
 *
 */

/* Librarian's note:
 *
 * This source code is for a special version of ft_poke(), compatible
 * with the ExoSpace (tm) DOS Extender from SofDesign, International.
 * It is ExoSpace-specific and is maintained separately from the real
 * mode version.
 *
 * The documentation can be found in the real-mode POKE.C as
 * distributed with the regular Nanforum Toolkit.
 *
 */ 


#include "extend.h"

void *      ExoProtectedPtr(void *rmptr, unsigned int sizebytes);

CLIPPER FT_POKE(void)
{
   auto unsigned char * byteptr;
   auto unsigned char * pmptr;

   if ( (PCOUNT >= 3) && (ISNUM(1)) && (ISNUM(2)) && (ISNUM(3)) )
   {
      * ((unsigned int *) &byteptr)     = _parni(2);
      * ((unsigned int *) &byteptr + 1) = _parni(1);
	  pmptr = ExoProtectedPtr(byteptr, 8);
	  *pmptr = ((unsigned char) _parni(3));
      _retl( TRUE );
   }
   else
      _retl( FALSE );
   return;
}
