/* Luis Carreira / Eduardo Fernandes
/* Using Borlandc 3.1 */
/* Compile : BCC -c -ml idle.c */

#pragma inline
#pragma warn -asm

#define TEST 0

int idlekey(void)
{
    asm xor  al, al
    asm mov  ah, 1
    asm int  16h

    asm jz   nokey

    asm or   ax, ax
    asm jnz  keydone

nokey:
    asm xor  ax, ax

keydone:
    return _AX;
}

void pascal idlefunc(void)
{
    while(idlekey() == 0);
}

#if TEST
void main(void) {
    idlefunc();
}
#endif
